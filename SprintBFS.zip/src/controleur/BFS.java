package controleur;



import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;
import controleur.Case;
import modele.Deplacement;
import modele.Personnage;



public class BFS extends Deplacement{

	public static int[][] mapDistance;
	private int[][] map2;
	
	public BFS(int[][] plt, Case caseMonstre, ArrayList<Personnage> listePerso){
		super(caseMonstre, mapDistance, listePerso);
		BFS.mapDistance=plt;
	}
		
	
	public boolean getCollisionBFS(int c, int l){
		boolean obstacle=false;
		if( this.map2[l][c]!=0)
			obstacle=true;
		return obstacle;
	}
	
					
					
public int[][] deplaceBFS(Case CaseDeb, int[][] carteObjet){
		
		this.map2=carteObjet;

		Queue<Case> queue = new LinkedList<>();
		Set<Case> visited = new HashSet<>();

		queue.add(CaseDeb);
		
		mapDistance[CaseDeb.getY()][CaseDeb.getX()]=1;
		
		visited.add(CaseDeb);

		while(!queue.isEmpty()){
			System.out.println("On rentre dans le while");
			Case actuel = queue.poll(); // poll = prend une case de la queue, la retourne dans Case et la supprime de queue
			
			System.out.println("queue " + queue);
			
			for(int i=0 ;i<actuel.getVoisin(mapDistance).size();i++){
				System.out.println("On entre dans le for");
				Case nouvelleCase = new Case(actuel.getVoisin(mapDistance).get(i).getX(),actuel.getVoisin(mapDistance).get(i).getY());	
					// liste d'obsctacle ou je stock mes case ou ya des obstacle avec un booleen 
			if ( getCollisionBFS( nouvelleCase.getX(), nouvelleCase.getY()) == true ){
					
					System.out.println("On entre dans le if obstacle");
					
					mapDistance[nouvelleCase.getY()][nouvelleCase.getX()]=-1;
				
					System.out.println("Met -1 a la case");
					System.out.println(" Case X = " + nouvelleCase.getX() + " Y = " + nouvelleCase.getY());
					
					visited.add(nouvelleCase);
					
					System.out.println(" visited : " + visited);
				
				}else{
					System.out.println("On entre dans else");
					
					if( visited.contains(actuel) && !queue.contains(nouvelleCase) &&  nouvelleCase.getX() <= 40 && nouvelleCase.getY() <= 60 ) {       
						System.out.println("Entrée if BFS ");
						
						System.out.println("Nouvelle Case Y : " + nouvelleCase.getY() + " X : " + nouvelleCase.getX());
						//System.out.println("longueur tab : Y " + mapDistance.length + " longueur X tab " + mapDistance[0].length); 60 40
						mapDistance[nouvelleCase.getY()][nouvelleCase.getX()]=mapDistance[actuel.getY()][actuel.getX()]+1;
						
						System.out.println("queue" +queue);
						queue.add(nouvelleCase);
						System.out.println("queue " + queue);
							
					}				
				}
			i++;
			}
			visited.add(actuel);
			System.out.println("visited " + visited);	
		}		
	//	affiche();
		System.out.println("On sort du while");
		return BFS.mapDistance;		
	}

	public void affiche(){
		for(int i=0; i<BFS.mapDistance.length; i++){
			for(int j=0; j<BFS.mapDistance[0].length;j++){
				System.out.print(mapDistance[i][j]);
			}
			System.out.println();
		}
	}


	

	
	
}
/*

		

 */



















