package controleur;

import java.util.ArrayList;

import modele.Objets;

public class DetecteurRamasserObjet {

	private ArrayList<Objets> listeObj;
	
	public DetecteurRamasserObjet(ArrayList<Objets> o) {
		this.listeObj=o;
	}
	
	public void setListe(ArrayList<Objets> o) {
		this.listeObj=o;
	}

}
