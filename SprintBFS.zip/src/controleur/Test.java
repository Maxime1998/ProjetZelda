package controleur;

public class Test {

	public static void main(String[] args) {
		int[][] mapBFS= new int[60][40];

		Case caseD= new Case(15,15); // positoin du premier archer 
		Case caseF= new Case(4,6); // position de link

		BFS bfs = new BFS(mapBFS,caseD, null);

		int[][] carteObjet= new int[60][40];
		for(int i=0; i<carteObjet.length;i++){
			for(int j=0; j<carteObjet[0].length; j++){
				carteObjet[i][j]=0;
			}
		}
		
		
		bfs.deplaceBFS(caseF, carteObjet );

	}

}
