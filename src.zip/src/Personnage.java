import javafx.beans.property.IntegerProperty;
import javafx.scene.image.ImageView;


public class Personnage {

	private IntegerProperty posX,posY;
	private IntegerProperty posXMax,posYMax;
	private ImageView viewperso;
	private int pdv;
	private DetecteurCollision collision;
	private int[][] map;
	
	public Personnage(ImageView vueperso,int abs, int ord,int pv,int[][] m) {
		this.viewperso=vueperso;
		this.posX.set(abs);
		this.posY.set(ord);
		this.pdv=pv;
		this.posXMax.set(this.posX.get()+30);
		this.posYMax.set(this.posY.get()+31);
		this.map=m;
		this.collision=new DetecteurCollision(map,posX.get(),posY.get(),posXMax.get(),posYMax.get());
	}
	
	/*public int getPosX() {
		return posX;
	}
	
	public int getPosY() {
		return posY;
	}
	
	public int getPosXMax() {
		return posXMax;
	}
	
	public int getPosYMax() {
		return posYMax;
	}*/
	
	public int getPDV() {
		return this.pdv;
	}
	
	public void setPDV(int pv) {
		this.pdv=pv;
	}
	
	public void perdrePV() {
		this.pdv--;
	}
	
	public void gagnerPV() {
		this.pdv++;
	}
	
	public void setPosX(int x) {
		this.posX.set(x);
	}
	
	public void setPosY(int y) {
		this.posY.set(y);
	}
	
	public void setPosXMax(int xMax) {
		this.posXMax.set(xMax);
	}
	
	public void setPosYMax(int yMax) {
		this.posYMax.set(yMax);
	}
	
	public void monter() {
		if(collision.testCollisionHaut()==true) {
			this.posY.set(posY.get()-1);
			collision.setPosY(posY.get());
			collision.setPosYMax(posYMax.get());
		}
	}
	
	public void descendre() {
		this.posY=posY+2;
		collision.setPosY(posY);
		collision.setPosYMax(posYMax);
	}
	
	public void droite() {
		this.posX=posX+2;
		collision.setPosX(posX);
		collision.setPosYMax(posXMax);
	}
	
	public void gauche() {
		this.posX=posX-2;
		collision.setPosX(posX);
		collision.setPosYMax(posXMax);
	}
}
