import java.io.File;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Personnage {

	private  double x,y;
	private ImageView viewperso;
	
	public Personnage(ImageView vueperso,double abs, double ord) {
		this.viewperso=vueperso;
		this.x=abs;
		this.y=ord;
	}
	
	public void placerPerso() {
		viewperso.relocate(x, y);
	}
	
	public void avancer() {
		this.y++;
		placerPerso();
	}
	
	public void reculer() {
		this.y--;
		placerPerso();
	}
	
	public void droite() {
		this.x++;
		placerPerso();
	}
	
	public void gauche() {
		this.x--;
		placerPerso();
	}
}
