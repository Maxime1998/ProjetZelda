import javafx.scene.image.ImageView;


public class Personnage {

	private  double posX,posY;
	private ImageView viewperso;
	private int pdv;
	
	public Personnage(ImageView vueperso,double abs, double ord,int pv) {
		this.viewperso=vueperso;
		this.posX=abs;
		this.posY=ord;
		this.pdv=pv;
	}
	
	public double getPosX() {
		return posX;
	}
	
	public double getPosY() {
		return posY;
	}
	
	public int getPDV() {
		return this.pdv;
	}
	
	public void setPDV(int pv) {
		this.pdv=pv;
	}
	
	public void perdrePV() {
		this.pdv--;
	}
	
	public void gagnerPV() {
		this.pdv++;
	}
	
	public void setPosX(double x) {
		this.posX=x;
	}
	
	public void setPosY(double y) {
		this.posY=y;
	}
	
	public void placerPerso() {
		viewperso.relocate(posX, posY);
	}
	
	public void monter() {
		this.posY=posY-2;
		placerPerso();
	}
	
	public void descendre() {
		this.posY=posY+2;
		placerPerso();
	}
	
	public void droite() {
		this.posX=posX+2;
		placerPerso();
	}
	
	public void gauche() {
		this.posX=posX-2;
		placerPerso();
	}
}
