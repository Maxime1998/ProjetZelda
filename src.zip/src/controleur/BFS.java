package controleur;

import java.util.ArrayList;
import java.util.LinkedList;

import controleur.Case;
import modele.Deplacement;

public class BFS extends Deplacement{

	private Case[][] plateau;
	private Case caseDepart;
	private Case caseFin;
	private LinkedList<Case> queue;
	
	
	
	public BFS(Case[][] plt, Case caseDep, Case caseF,int [][]m,ArrayList<Case> listePos){
		super(caseF,m,listePos);
		this.plateau=plt;
		this.caseDepart=caseDep;
		this.caseFin=caseF;
		this.queue=new LinkedList<>();
		
	}
	
	
	
/*	public BFS(BFS bfs){
		this.plateau = bfs.plateau;
		this.caseDepart = bfs.caseDepart;
		this.caseFin = bfs.caseFin;
		this.queue = bfs.queue;
	}*/
	
	
	
	public LinkedList<Case> deplaceBFS(){
        queue.add(caseDepart);
        
        
        if (this.caseDepart.equals(caseFin)){
			System.out.println("CaseFin trouve !");
			queue.add(caseFin);
		}
        
        while (!queue.contains(caseFin)){
        	if (queue.getLast().getX()+1 < this.plateau.length && queue.getLast().getY() < this.plateau[0].length){
        		if (plateau[queue.getLast().getX()+1][queue.getLast().getY()] != caseFin && !queue.contains(plateau[queue.getLast().getX()+1][queue.getLast().getY()])){
        			queue.add(plateau[queue.getLast().getX()+1][queue.getLast().getY()]);
        				System.out.println("entrer 1 er boucle");
        		}
        	}
        	
        	if (queue.getLast().getX()-1 > 0 && queue.getLast().getY() < this.plateau[0].length){
        		if (plateau[queue.getLast().getX()-1][queue.getLast().getY()] != caseFin && !queue.contains(plateau[queue.getLast().getX()-1][queue.getLast().getY()])){
        			queue.add(plateau[queue.getLast().getX()-1][queue.getLast().getY()]);
        			System.out.println("entrer 2 e boucle");
        		}
        	}
        	
        	if (queue.getLast().getX() < this.plateau.length && queue.getLast().getY()+1 < this.plateau[0].length){
        		if (plateau[queue.getLast().getX()][queue.getLast().getY()+1] != caseFin && !queue.contains(plateau[queue.getLast().getX()][queue.getLast().getY()+1])){
        			queue.add(plateau[queue.getLast().getX()][queue.getLast().getY()+1]);
        			System.out.println("entrer 3 e boucle");
        		}
        	}
        	
        	if (queue.getLast().getX() < this.plateau.length && queue.getLast().getY()-1 > 0){
        		if (plateau[queue.getLast().getX()][queue.getLast().getY()-1] != caseFin && !queue.contains(plateau[queue.getLast().getX()][queue.getLast().getY()-1])){
        			queue.add(plateau[queue.getLast().getX()][queue.getLast().getY()-1]);
        			System.out.println("entrer 4 e boucle");
        		}
        	}
        }
        return queue;
        
	}
	
	public LinkedList<Case> getQueue(){
		return this.queue;
	}

        	
        	
        	
     
	
	
}










