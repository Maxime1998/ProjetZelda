package controleur;

import java.util.ArrayList;

public class BFSS {

	
	private Case caseDeLink;
	private ArrayList<Case> liste;
	private ArrayList<Case> listeMarqueur;
	
	public BFSS(Case caselink) {
		this.caseDeLink=caselink;
	}
	
	
	
	
}
