package controleur;

import java.util.ArrayList;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import modele.BFS;

public class Case {
		
		private IntegerProperty x;
		private IntegerProperty y;
		
		public Case(int x, int y) {
			this.x = new SimpleIntegerProperty();
			this.y = new SimpleIntegerProperty();
			this.x.set(x);
			this.y.set(y);
		}

		public int getX() {
			return this.x.get();
		}

		public int getY() {
			return this.y.get();
		}
		public IntegerProperty getXProperty() {
			return this.x;
		}

		public IntegerProperty getYProperty() {
			return this.y;
		}

		public void setX(int x0) {
			this.x.set(x0);;
		}

		public void setY(int y0) {
			this.y.set(y0);;
		}
		
public ArrayList<Case> getVoisin(int[][] m){
			
		    ArrayList<Case> maliste = new ArrayList<>();
		    
		    // droite
		    if(x.get()<(m.length -1) && x.get()>= 0 )
		        maliste.add(new Case(x.get()+1,y.get()));		    
		    // gauche
		    if(x.get()>0 && x.get()<m.length-1)
		        maliste.add(new Case(x.get()-1,y.get()));
		    
		    // monter
		    if(y.get()>0 && y.get()<m[0].length-1)
		        maliste.add(new Case(x.get(),y.get()-1));
		    
		    // en bas
		    if(y.get()<(m[0].length -1) && y.get() >= 0)
		        maliste.add(new Case(x.get(),y.get()+1));
		    
		    return maliste;
		}
		
		public Case caseSuivante(Case caseD){
	    	Case c = caseD;
	    	ArrayList<Case> maliste = new ArrayList<>();
	    	maliste = c.getVoisin(BFS.mapDistance);
	    	for(int i=0 ; i<maliste.size();){
	    		if(BFS.mapDistance[maliste.get(i).getY()][maliste.get(i).getX()] == (BFS.mapDistance[c.getY()][c.getX()] -1)     )  
	    			c = maliste.get(i);
	    			return maliste.get(i);
	    	}
	    	System.out.println("maliste est " + maliste);
	    	return c;
	    }
		
		

	/*	@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + x;
			result = prime * result + y;
			return result;
		}
	*/
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Case other = (Case) obj;
			if (x != other.x)
				return false;
			if (y != other.y)
				return false;
			return true;
		}
}