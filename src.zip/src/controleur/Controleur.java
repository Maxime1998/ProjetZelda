package controleur;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import modele.Arc;
import modele.Archer;
import modele.Deplacement;
import modele.DeplacementAleatoire;
import modele.DeplacementHorizontale;
import modele.Environnement;
import modele.Epee;
import modele.Fleche;
import modele.Link;
import modele.Map;
import modele.Objets;
import modele.PNJ;
import modele.Personnage;
import modele.PotionVie;
import vue.AffichageMap;
import vue.Vues;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.TextAlignment;
import javafx.util.Duration;

public class Controleur implements Initializable {
	
	private Timeline gameLoop;
	
	private int temps;
	private int vie_link;
	private Case vie;
	
	private AffichageMap aff;
	
	private ArrayList<Evenement> event;
	
	private Environnement env;
	
	private Vues vue;
	
	private IntegerProperty mvt=new SimpleIntegerProperty(0);
	
	//Liste avec les imageview des personnages
	ArrayList<ImageView> listeVuePerso = new ArrayList<ImageView>();
	
	//Boolean pour atraper un objet poussable
		private boolean attraperObjetPoussable=false;
		private int indiceObjet;
		
		//Boolean pour les attaques
		private boolean attaquePossible=false;
		private int indicePerso;
		
		//boolean pour déplacements
		private boolean monterOK=false;
		private boolean descendreOK=false;
		private boolean droiteOK=false;
		private boolean gaucheOK=false;
		
		
		//Fleches
		private Fleche fleche;
		private boolean attaqueArcPossible=false;
	    
	    //liste inventaire vu des objets 
	    ArrayList<ImageView> listeVue;
	    
	    
	    
	@FXML
    private Pane affichage;

    @FXML
    private Pane terrain;

    @FXML
    private Pane objets;
    
    @FXML
    private Pane menu;
    
    @FXML
    private Pane scrolling;
  
    @FXML
    private Pane invent;
    @FXML
    private Label texte;
    @FXML
    private Pane gameover;
    @FXML
    private Pane arme;


	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		this.env= new Environnement() ;
		this.aff= new AffichageMap(env);
		this.vue= new Vues();
		
		aff.afficher(objets);
		
		
		//affichaf=ge switch arme
		arme.getChildren().add(vue.getVueArme());
		vue.getVueArme().relocate(0, 568);
		//pane fin 
		gameover.getChildren().add(vue.getVueGameOver());
		gameover.setVisible(false);
		
	
		
				//initialisation label pour les dialogues
			
				texte.setText(((PNJ)env.getListePers().get(1)).getText());
				//texte.setTextAlignment(TextAlignment.CENTER);
		
				texte.setVisible(false);
				
				
				
				//initialisation vue inv
				listeVue= new ArrayList<>();
				listeVue.add(vue.getVuePotionMap());
				
				
		//link
		objets.getChildren().add(vue.getVuePerso());
		vue.getVuePerso().translateXProperty().bind(env.getLink().getDeplacement().getPosX());
		vue.getVuePerso().translateYProperty().bind(env.getLink().getDeplacement().getPosY());
		vue.getVuePerso().setImage(vue.getPersFace());
		
		//deplacement et affichage monstres
		
		//archer1

		objets.getChildren().add(vue.getVueMonstre1());
		vue.getVueMonstre1().translateXProperty().bind(env.getMonstre1().getDeplacement().getPosX());
		vue.getVueMonstre1().translateYProperty().bind(env.getMonstre1().getDeplacement().getPosY());
		
	//	vue.getVueMonstre2().setImage(vue.getPersFace());
		objets.getChildren().add(vue.getVueMonstre2());
		vue.getVueMonstre2().translateXProperty().bind(env.getMonstre2().getDeplacement().getPosX());
		vue.getVueMonstre2().translateYProperty().bind(env.getMonstre2().getDeplacement().getPosY());
		
	//	vue.getVueMonstre3().setImage(vue.getPersFace());
		objets.getChildren().add(vue.getVueMonstre3());
		vue.getVueMonstre3().translateXProperty().bind(env.getMonstre3().getDeplacement().getPosX());
		vue.getVueMonstre3().translateYProperty().bind(env.getMonstre3().getDeplacement().getPosY());
		
	//	vue.getVueMonstre4().setImage(vue.getPersFace());
		objets.getChildren().add(vue.getVueMonstre4());
		vue.getVueMonstre4().translateXProperty().bind(env.getMonstre4().getDeplacement().getPosX());
		vue.getVueMonstre4().translateYProperty().bind(env.getMonstre4().getDeplacement().getPosY());
		
	//	vue.getVueMonstre5().setImage(vue.getPersFace());
		objets.getChildren().add(vue.getVueMonstre5());
		vue.getVueMonstre5().translateXProperty().bind(env.getMonstre5().getDeplacement().getPosX());
		vue.getVueMonstre5().translateYProperty().bind(env.getMonstre5().getDeplacement().getPosY());
		
		//vue.getVueMonstre6().setImage(vue.getPersFace());
		objets.getChildren().add(vue.getVueMonstre6());
		vue.getVueMonstre6().translateXProperty().bind(env.getMonstre6().getDeplacement().getPosX());
		vue.getVueMonstre6().translateYProperty().bind(env.getMonstre6().getDeplacement().getPosY());
		
	//	vue.getVueMonstre7().setImage(vue.getPersFace());
		objets.getChildren().add(vue.getVueMonstre7());
		vue.getVueMonstre7().translateXProperty().bind(env.getMonstre7().getDeplacement().getPosX());
		vue.getVueMonstre7().translateYProperty().bind(env.getMonstre7().getDeplacement().getPosY());
		
	//	vue.getVueMonstre8().setImage(vue.getPersFace());
		objets.getChildren().add(vue.getVueMonstre8());
		vue.getVueMonstre8().translateXProperty().bind(env.getMonstre8().getDeplacement().getPosX());
		vue.getVueMonstre8().translateYProperty().bind(env.getMonstre8().getDeplacement().getPosY());
		
	//	vue.getVueMonstre9().setImage(vue.getPersFace());
		objets.getChildren().add(vue.getVueMonstre9());
		vue.getVueMonstre9().translateXProperty().bind(env.getMonstre9().getDeplacement().getPosX());
		vue.getVueMonstre9().translateYProperty().bind(env.getMonstre9().getDeplacement().getPosY());
		
	//	vue.getVueMonstre10().setImage(vue.getPersFace());
		objets.getChildren().add(vue.getVueMonstre10());
		vue.getVueMonstre10().translateXProperty().bind(env.getMonstre10().getDeplacement().getPosX());
		vue.getVueMonstre10().translateYProperty().bind(env.getMonstre10().getDeplacement().getPosY());
		
		//personnage qui parle
		vue.getVueVieux().setImage(vue.getVieux());
		objets.getChildren().add(vue.getVueVieux());
		vue.getVueVieux().translateXProperty().bind(env.getListePers().get(1).getDeplacement().getPosX());
		vue.getVueVieux().translateYProperty().bind(env.getListePers().get(1).getDeplacement().getPosY());
		


		//Test deplacement boite
		objets.getChildren().add(vue.getVueBoite());
		objets.getChildren().add(vue.getVueBoite2());
		vue.getVueBoite().translateXProperty().bind(env.getListeObjetsPoussables().get(0).getCase().getXProperty());
		vue.getVueBoite().translateYProperty().bind(env.getListeObjetsPoussables().get(0).getCase().getYProperty());
		vue.getVueBoite2().translateXProperty().bind(env.getListeObjetsPoussables().get(1).getCase().getXProperty());
		vue.getVueBoite2().translateYProperty().bind(env.getListeObjetsPoussables().get(1).getCase().getYProperty());
		
		
		objets.getChildren().add(vue.getVueFleche());
		
		//objet sur map
		listeVue.get(0).setImage(vue.getPotion());
		objets.getChildren().add(listeVue.get(0));
		listeVue.get(0).relocate(env.getListeObj().get(0).getCase().getX(), env.getListeObj().get(0).getCase().getY());
		
		
		initAnimation();
		gameLoop.play();
		
		
		//inventaire
		
				invent.getChildren().add(vue.getVueInv());
				invent.getChildren().add(vue.getVueCarre());
				vue.getVueCarre().relocate(env.getCoordCarre().getX(), env.getCoordCarre().getY());
				
				vue.getVuePotion().setFitHeight(60);
				vue.getVuePotion().setFitWidth(60);
				vue.getVuePotion().relocate(env.getListeCoord().get(0).getX(), env.getListeCoord().get(0).getY());
				invent.getChildren().add(vue.getVuePotion());
				//tant que dans map faux, quand link ramasse alors vrai
				vue.getVuePotion().setVisible(false);
				
				
				invent.setVisible(false);
				
				/*//affichage dans l'inventaire des objets
				for(int i=0; i<env.getLink().getListeObj().size(); i++) {
					vuepotion.relocate(env.getLink().getListeObj().get(i).getCase().getX(), env.getLink().getListeObj().get(i).getCase().getY());
				
				}*/
				
				
				
		
		//afichage vie
		vie = new Case(0,0);
		menu.getChildren().add(vue.getVueCoeur());
		menu.translateXProperty().bind(vie.getXProperty());
		menu.translateYProperty().bind(vie.getYProperty());
		vie_link=env.getLink().getPDV();
			        
		
			        env.getLink().getPV().addListener(new ChangeListener<Number>() {

			            @Override
			            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
			                if(env.getLink().getPDV()<vie_link && env.getLink().getPDV()>0) {
			                	while(vie_link>env.getLink().getPDV()) {
			                	vie.setX(vie.getX()-32);
			                	vie_link--;
			                	}
			        
			                }
			                else if(env.getLink().getPDV()>=vie_link && vie.getX()<0) {
			                	while(vie_link<env.getLink().getPDV()) {
			                		vie.setX(vie.getX()+32);
			                		vie_link++;
			                	}
			                		
			                	
			                }
			            	vie_link=env.getLink().getPDV();
			                
			            }
			            
			        });

		
		// pour pouvoir changer l'image du personnage, mouvement 
		mvt.addListener(new ChangeListener<Number>() {

			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				
				switch(env.getLink().getDeplacement().getOrientation().get()) {
					case 0:
						vue.getVuePerso().setImage(vue.getPersDos());
						env.getLink().getDeplacement().incrementerCompteurPas();
						System.out.println(env.getLink().getDeplacement().getCompteurPas());
						if(env.getLink().getDeplacement().getCompteurPas()%6==0 || env.getLink().getDeplacement().getCompteurPas()%6==1 || env.getLink().getDeplacement().getCompteurPas()%6==2){
	                		vue.getVuePerso().setImage(vue.getPersFaceMarche1());
	                	}
	                	else{
	                		vue.getVuePerso().setImage(vue.getPersFaceMarche2());
	                	}
		
						
					break;
					case 1:
						vue.getVuePerso().setImage(vue.getPersFace());
						env.getLink().getDeplacement().incrementerCompteurPas();
						if(env.getLink().getDeplacement().getCompteurPas()%6==0 || env.getLink().getDeplacement().getCompteurPas()%6==1|| env.getLink().getDeplacement().getCompteurPas()%6==2){
	                		vue.getVuePerso().setImage(vue.getPersDosMarche1());
	                	}
	                	else{
	                		vue.getVuePerso().setImage(vue.getPersDosMarche2());
	                	}
					break;
					case 2 :
						vue.getVuePerso().setImage(vue.getPersDroite());
						env.getLink().getDeplacement().incrementerCompteurPas();
	                     if(env.getLink().getDeplacement().getCompteurPas()%6==0 || env.getLink().getDeplacement().getCompteurPas()%6==1|| env.getLink().getDeplacement().getCompteurPas()%6==2){
	                 		vue.getVuePerso().setImage(vue.getPersDroiteMarche1());
	                 	}
	                 	else{
	                 		vue.getVuePerso().setImage(vue.getPersDroiteMarche2());
	                 	}
	                  break;
					case 3:
						vue.getVuePerso().setImage(vue.getPersGauche());
						env.getLink().getDeplacement().incrementerCompteurPas();
						if(env.getLink().getDeplacement().getCompteurPas()%6==0 || env.getLink().getDeplacement().getCompteurPas()%6==1 || env.getLink().getDeplacement().getCompteurPas()%6==2){
							vue.getVuePerso().setImage(vue.getPersGaucheMarche1());
		            	}
		            	else{
		            		vue.getVuePerso().setImage(vue.getPersGaucheMarche2());
		            	}
	            
	                 break;
						
				}
			}
			
		}
				);
		//viewperso.translateXProperty().addListener();
		
	}
	
    public void deplacement(KeyEvent key) {
		KeyCode codeDeLaTouche = key.getCode();
		
		if(!invent.isVisible()) {
		switch (codeDeLaTouche) 
        {
		
		case Z:
        case UP:
        	monterOK=true;
            break;
        case Q:
        case LEFT:
        	gaucheOK=true;
            break;
        case D:
        case RIGHT:
        	droiteOK=true;
            break;
        case S:
        case DOWN:
        	descendreOK=true;
            break;
            //ouvrir l'inventaire  
            case I:
        		invent.setVisible(true);
        		break;
        	//attaquer
            case SPACE:
            	   if(env.getLink().getArme().getNom()=="epee") {
   	            	if(env.getLink().getDeplacement().getDetecteurPerso().testCollisionBas(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx())!=-1 && this.attaquePossible==false){
   	            		this.attaquePossible=true;
   	            		indicePerso=env.getLink().getDeplacement().getDetecteurPerso().testCollisionBas(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx());
   	            	}
   	            	else if(env.getLink().getDeplacement().getDetecteurPerso().testCollisionHaut(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx())!=-1 && this.attaquePossible==false){
   	            		this.attaquePossible=true;
   	            		indicePerso=env.getLink().getDeplacement().getDetecteurPerso().testCollisionHaut(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx());
   	            	}
   	            	else if(env.getLink().getDeplacement().getDetecteurPerso().testCollisionDroit(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx())!=-1 && this.attaquePossible==false){
   	            		this.attaquePossible=true;
   	            		indicePerso=env.getLink().getDeplacement().getDetecteurPerso().testCollisionDroit(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx());
   	            	}
   	            	else if(env.getLink().getDeplacement().getDetecteurPerso().testCollisionGauche(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx())!=-1 && this.attaquePossible==false){
   	            		this.attaquePossible=true;
   	            		indicePerso=env.getLink().getDeplacement().getDetecteurPerso().testCollisionGauche(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx());
   	            	}
   	            	else{
   	            		this.attaquePossible=false;
   	            	}
           	   }
               	
               	//Attaque arc
               	if(env.getLink().getArme().getNom()=="arc") {
               		if(this.attaqueArcPossible==false) {
               			this.attaqueArcPossible=true;
               			vue.getVueFleche().relocate(env.getLink().getDeplacement().getPosx(), env.getLink().getDeplacement().getPosy());
               			fleche = new Fleche(env.getLink().getDeplacement().getPosx(), env.getLink().getDeplacement().getPosy(),env.getLink().getArme(),env.getLink().getDeplacement().getOrientation().get(),env.getListePers(),env.getMap2());
               			if(env.getLink().getDeplacement().getOrientation().get()==0) {//descendre
               				vue.getVueFleche().setImage(vue.getimgflechebas());
               			}
               			if(env.getLink().getDeplacement().getOrientation().get()==1) {//monter
               				vue.getVueFleche().setImage(vue.getimgflechehaut());
               			}
               			if(env.getLink().getDeplacement().getOrientation().get()==2) {//droite
               				vue.getVueFleche().setImage(vue.getimgflechedroit());
               			}
               			if(env.getLink().getDeplacement().getOrientation().get()==3) {//gauche
               				vue.getVueFleche().setImage(vue.getimgflechegauche());
               			}
               		}
               		
               	}
               	
            	break;
           
            case ENTER :
            	//parler a un pnj
            	//verifier collision avec pnj
            	if(texte.isVisible()) {
            		texte.setVisible(false);
        		}
            	
            	else if (env.getLink().getDeplacement().getDetecteur().testCollisionBas(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx())==1 || 
            			env.getLink().getDeplacement().getDetecteur().testCollisionHaut(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx())==1 ||
            			env.getLink().getDeplacement().getDetecteur().testCollisionGauche(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx())==1 ||
            			env.getLink().getDeplacement().getDetecteur().testCollisionDroit(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx())==1) {
            		texte.setVisible(true);
            	}
            	
            	//ramasser objet
            	if (env.getLink().getDeplacement().getObj()!=null) {
            		env.getLink().ajouterObjet(env.getLink().getDeplacement().getObj());
            		for(int i=0; i<env.getListeObj().size(); i++) {
            			if(env.getLink().getDeplacement().getObj().equals(env.getListeObj().get(i))) {
            				System.out.println(i);
            				env.getListeObj().get(i).getCase().setX(1278);
            				env.getListeObj().get(i).getCase().setY(1918);
            				listeVue.get(i).setVisible(false);
            				vue.getVuePotion().setVisible(true);
            			}
            		}
            		
            	}	
            break;
            case A:
            	if(env.getLink().getArme().getNom().equals("arc")) {
            		System.out.println("jai un arc");
            		env.getLink().setArme(new Epee());
            	}
            	else {
            		System.out.println("jai une épéé");
            		env.getLink().setArme(new Arc());
            	}
            break;
        
          
            
            
		}
		}
		else {
			switch(codeDeLaTouche) {
			
			//affichage de linventaire
            case I:
            	//setvisiblefalse -> rendre invisible le pane 
            	//creer un pane et lenlever a la pression de la touche remove
            	//pane new pane 
            	if (invent.isVisible()) {
            		invent.setVisible(false);
            	}
            	else {
            		invent.setVisible(true);
            	}
            	
            	
            	break;
            case Z:
            case UP:
            	if(env.getCoordCarre().getY()>40) {
            	env.setCoordCarre(env.getCoordCarre().getX(), env.getCoordCarre().getY()-180);
            	vue.getVueCarre().relocate(env.getCoordCarre().getX(), env.getCoordCarre().getY());
            	}
                break;
            case Q:
            case LEFT:
            	if(env.getCoordCarre().getX()>40) {
            	env.setCoordCarre(env.getCoordCarre().getX()-180, env.getCoordCarre().getY());
            	vue.getVueCarre().relocate(env.getCoordCarre().getX(), env.getCoordCarre().getY());
            	}
                break;
            case D:
            case RIGHT:
            	if(env.getCoordCarre().getX()<400) {
            	env.setCoordCarre(env.getCoordCarre().getX()+180, env.getCoordCarre().getY());
            	vue.getVueCarre().relocate(env.getCoordCarre().getX(), env.getCoordCarre().getY());
            	}
                break;
            case S :
            case DOWN:
            	if(env.getCoordCarre().getY()<400) {
            	env.setCoordCarre(env.getCoordCarre().getX(), env.getCoordCarre().getY()+180);
            	vue.getVueCarre().relocate(env.getCoordCarre().getX(), env.getCoordCarre().getY());
            	}
                break;
            case ENTER :
            	//verifiaction objet selectionner
            	for(int i=0; i<env.getListeCoord().size();i++) {
            		if(env.getListeCoord().get(i).getX()>env.getCoordCarre().getX() && env.getListeCoord().get(i).getX()+60<env.getCoordCarre().getX()+160) {
            			if(env.getListeCoord().get(i).getY()>env.getCoordCarre().getY() && env.getListeCoord().get(i).getY()+60<env.getCoordCarre().getY()+160) {
            				//System.out.println("objet!!!");
            				env.getLink().boirePotion(env.getListeObj().get(i).getNom());
            				vue.getVuePotion().setVisible(false);
            				//enlev� de linv
            				env.getListeCoord().get(i).setX(70);
            				env.getListeCoord().get(i).setY(700);
            			}
            		}
            	}
            	
				break;
			

			}
			
			
		}
		
    }
    
    private void initAnimation() {
    	gameLoop = new Timeline();
    	temps=0;
    	gameLoop.setCycleCount(Timeline.INDEFINITE);
    	KeyFrame kf = new KeyFrame(
				Duration.seconds(0.01),(ev ->{
					if(env.getLink().getPDV()==0) {
						System.out.println("WASTED");
						gameover.setVisible(true);
						gameLoop.stop();
					}
					else {
						for(int i=0; i<listeVuePerso.size();i++) {
							env.getMortMonstres().monstreMort(i, listeVuePerso);
						}
						if(temps%5==0){
							for(int i=2;i<env.getListePers().size();i++) {
								if(env.getListePers().get(i).getDeplacement()!=null) {
									env.getListePers().get(i).getDeplacement().agir();
									if(env.getListePers().get(i).getDeplacement().getDetecteurPerso().testCollisionBas(env.getListePers().get(i).getDeplacement().getPosy(), env.getListePers().get(i).getDeplacement().getPosx())==0){
										env.getListePers().get(i).attaque(env.getLink());
									}
									if(env.getListePers().get(i).getDeplacement().getDetecteurPerso().testCollisionHaut(env.getListePers().get(i).getDeplacement().getPosy(), env.getListePers().get(i).getDeplacement().getPosx())==0){
										env.getListePers().get(i).attaque(env.getLink());
									}
									if(env.getListePers().get(i).getDeplacement().getDetecteurPerso().testCollisionDroit(env.getListePers().get(i).getDeplacement().getPosy(), env.getListePers().get(i).getDeplacement().getPosx())==0){
										env.getListePers().get(i).attaque(env.getLink());
									}
									if(env.getListePers().get(i).getDeplacement().getDetecteurPerso().testCollisionGauche(env.getListePers().get(i).getDeplacement().getPosy(), env.getListePers().get(i).getDeplacement().getPosx())==0){
										env.getListePers().get(i).attaque(env.getLink());
									}
								}
							}
						}
						if(temps%3==0 && monterOK==true){
							if(env.getLink().getDeplacement().monter()==true) {
			            		env.getScroll().setPosYFenetre();
			            		scrolling.relocate(-env.getScroll().getPosXFenetre(), -env.getScroll().getPosYFenetre());
			            		mvt.set(mvt.get()+1);
			        		}
						}
						if(temps%3==0 && descendreOK==true){
							if(env.getLink().getDeplacement().descendre()==true) {
			            		env.getScroll().setPosYFenetre();
			            		scrolling.relocate(-env.getScroll().getPosXFenetre(), -env.getScroll().getPosYFenetre());
			            		mvt.set(mvt.get()+1);
			        		}
						}
						if(temps%3==0 && droiteOK==true){
								if(env.getLink().getDeplacement().droite()==true) {
			            		env.getScroll().setPosXFenetre();
			            		scrolling.relocate(-env.getScroll().getPosXFenetre(), -env.getScroll().getPosYFenetre());
			            		mvt.set(mvt.get()+1);
			            	}
			            }
						if(temps%3==0 && gaucheOK==true){
							if(env.getLink().getDeplacement().gauche()==true) {
			            		env.getScroll().setPosXFenetre();
			            		scrolling.relocate(-env.getScroll().getPosXFenetre(), -env.getScroll().getPosYFenetre());
			            		mvt.set(mvt.get()+1); 
			        		}
						}
						if(temps%3==0 && this.attraperObjetPoussable==true){
							env.getLink().attraperObjetPoussable(indiceObjet);
						}
						if(temps%2==0 && this.attaquePossible==true) {
							vue.getVuePerso().setImage(null);
						}
						if(temps%2==1 && this.attaquePossible==true) {
							vue.getVuePerso().setImage(vue.getPersFace());
						}
						if(temps%4==0 && this.attaquePossible==true) {
							env.getLink().attaque(env.getListePers().get(indicePerso));
						}
						if(this.attaqueArcPossible==true && fleche.getPortee()>0) {
            				fleche.agir();
            				vue.getVueFleche().relocate(fleche.getX(), fleche.getY());
            				if(fleche.getPortee()<=0) {
            					this.attaqueArcPossible=false;
            					vue.getVueFleche().setImage(null);
            				}
            			}
						//Potion invincibilité mdr
						/*if(temps%2==0) {
							viewperso.setImage(null);
						}
						if(temps%2==1) {
							viewperso.setImage(pers_face);
						}*/
					}
					temps++;
				})
				);
    	gameLoop.getKeyFrames().add(kf);
    }
    
  //quand le personage ne bouge plus 
  	public void touheRelache(KeyEvent event) {
  		switch(env.getLink().getDeplacement().getOrientation().get()) {
  		case 0:
  			vue.getVuePerso().setImage(vue.getPersFace());
  			break;
  		case 1:
  			vue.getVuePerso().setImage(vue.getPersDos());
  			break;
  		case 2:
  			vue.getVuePerso().setImage(vue.getPersDroite());
  			break;
  		case 3 :
  			vue.getVuePerso().setImage(vue.getPersGauche());
  			break;
  			
  		}
  		
  		KeyCode codeDeLaTouche2 = event.getCode();
		
		switch (codeDeLaTouche2) {
		case Z:
		case UP:
			monterOK=false;
			System.out.println(monterOK);
			break;
		case S:
		case DOWN:
			descendreOK=false;
			break;
		case D:
		case RIGHT:
			droiteOK=false;
			break;
		case Q:
		case LEFT:
			gaucheOK=false;
			break;
		case SPACE:
			attaquePossible=false;
		}
  		
  	}
}
