package controleur;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import org.omg.CORBA.Environment;

import modele.Archer;
import modele.Deplacement;
import modele.DeplacementAleatoire;
import modele.DeplacementHorizontale;
import modele.Environnement;
import modele.Link;
import modele.Map;
import modele.Objets;
import modele.PNJ;
import modele.Personnage;
import modele.PotionVie;
import vue.AffichageMap;
import vue.Vues;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.TextAlignment;
import javafx.util.Duration;

public class Controleur implements Initializable {
	
	private Timeline gameLoop;
	
	private int temps;
	private int vie_link;
	private Case vie ;
	
	private AffichageMap aff;
	
	private ArrayList<Evenement> event;
	
	private Environnement env;
	
	private Vues vue;
	
	//private Archer archer2;
	//private Archer boite;
	private BFS bfs;
	
	
	
	/*//vue test
	private ImageView viewtest = new ImageView();*/
	
	//Test deplacement monstre avec gameloop
	private ImageView viewmonstre = new ImageView();
	private ImageView viewmonstre2 = new ImageView();

	
	private IntegerProperty mvt=new SimpleIntegerProperty(0);
	
	//imgs
	    
	    
	    //liste inventaire vu des objets 
	    ArrayList<ImageView> listeVue;
	    
	    
	    
	@FXML
    private Pane affichage;

    @FXML
    private Pane terrain;

    @FXML
    private Pane objets;
    
    @FXML
    private Pane menu;
    
    @FXML
    private Pane scrolling;
  
    @FXML
    private Pane invent;
    @FXML
    private Label texte;
    @FXML
    private Pane gameover;


	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		this.env= new Environnement() ;
		this.aff= new AffichageMap(env);
		this.vue= new Vues();
		
		aff.afficher(objets);
		
		//pane fin 
		gameover.getChildren().add(vue.getVueGameOver());
		gameover.setVisible(false);
		
	
		
				//initialisation label pour les dialogues
			
				texte.setText(((PNJ)env.getListePers().get(3)).getText());
				//texte.setTextAlignment(TextAlignment.CENTER);
		
				texte.setVisible(false);
				
				
				
				//initialisation vue inv
				listeVue= new ArrayList<>();
				listeVue.add(vue.getVuePotionMap());
				
				
		//link
		objets.getChildren().add(vue.getVuePerso());
		vue.getVuePerso().translateXProperty().bind(env.getLink().getDeplacement().getPosX());
		vue.getVuePerso().translateYProperty().bind(env.getLink().getDeplacement().getPosY());
		vue.getVuePerso().setImage(vue.getPersFace());
		
		
		/*//test affichage menu
		viewtest.setImage(pers_dos);
		menu.getChildren().add(viewtest);*/
		
		//deplacement et affichage monstres
		
		//archer1
		viewmonstre.setImage(vue.getPersFace());
		objets.getChildren().add(viewmonstre);
		viewmonstre.translateXProperty().bind(env.getListePers().get(1).getDeplacement().getPosX());
		viewmonstre.translateYProperty().bind(env.getListePers().get(1).getDeplacement().getPosY());
		
		
		Case[][] plateau= new Case[5][10];
		Case caseD= new Case(80,100);
		Case caseF= new Case(10,10);
		bfs = new BFS(plateau,caseD,caseF,env.getMap2(),env.getListePers(), env.getListeObj());

		//archer2
		viewmonstre2.setImage(vue.getPersFace());
		objets.getChildren().add(viewmonstre2);
		viewmonstre2.translateXProperty().bind(env.getListePers().get(2).getDeplacement().getPosX());
		viewmonstre2.translateYProperty().bind(env.getListePers().get(2).getDeplacement().getPosY());
		
		//personnage qui parle
		vue.getVueVieux().setImage(vue.getVieux());
		objets.getChildren().add(vue.getVueVieux());
		vue.getVueVieux().translateXProperty().bind(env.getListePers().get(3).getDeplacement().getPosX());
		vue.getVueVieux().translateYProperty().bind(env.getListePers().get(3).getDeplacement().getPosY());
		
		//viewvieux.relocate(((PNJ) env.getListePers().get(3)).getPos().getX(), ((PNJ) env.getListePers().get(3)).getPos().getY());
		
		/*
		Deplacement dboite = new Deplacement(new Case(100,100),map2,listePers);
		boite = new Archer(dboite);
		vueboite.setImage(pers_face);
		objets.getChildren().add(vueboite);
		
		
		vueboite.translateXProperty().bind(boite.getDeplacement().getPosX());
		vueboite.translateYProperty().bind(boite.getDeplacement().getPosY());
		*/
		
		//objet sur map
		listeVue.get(0).setImage(vue.getPotion());
		objets.getChildren().add(listeVue.get(0));
		listeVue.get(0).relocate(env.getListeObj().get(0).getCase().getX(), env.getListeObj().get(0).getCase().getY());
		
		
		initAnimation();
		gameLoop.play();
		
		
		//inventaire
		
				invent.getChildren().add(vue.getVueInv());
				invent.getChildren().add(vue.getVueCarre());
				vue.getVueCarre().relocate(env.getCoordCarre().getX(), env.getCoordCarre().getY());
				
				vue.getVuePotion().setFitHeight(60);
				vue.getVuePotion().setFitWidth(60);
				vue.getVuePotion().relocate(env.getListeCoord().get(0).getX(), env.getListeCoord().get(0).getY());
				invent.getChildren().add(vue.getVuePotion());
				//tant que dans map faux, quand link ramasse alors vrai
				vue.getVuePotion().setVisible(false);
				
				
				invent.setVisible(false);
				
				/*//affichage dans l'inventaire des objets
				for(int i=0; i<env.getLink().getListeObj().size(); i++) {
					vuepotion.relocate(env.getLink().getListeObj().get(i).getCase().getX(), env.getLink().getListeObj().get(i).getCase().getY());
				
				}*/
				
				
				
		
		//afichage vie
		vie = new Case(0,0);
		menu.getChildren().add(vue.getVueCoeur());
		menu.translateXProperty().bind(vie.getXProperty());
		menu.translateYProperty().bind(vie.getYProperty());
		vie_link=env.getLink().getPDV();
			        
		
			        env.getLink().getPV().addListener(new ChangeListener<Number>() {

			            @Override
			            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
			                if(env.getLink().getPDV()<vie_link && env.getLink().getPDV()>0) {
			                	while(vie_link>env.getLink().getPDV()) {
			                	vie.setX(vie.getX()-32);
			                	vie_link--;
			                	}
			        
			                }
			                else if(env.getLink().getPDV()>=vie_link && vie.getX()<0) {
			                	while(vie_link<env.getLink().getPDV()) {
			                		vie.setX(vie.getX()+32);
			                		vie_link++;
			                	}
			                		
			                	
			                }
			            	vie_link=env.getLink().getPDV();
			                
			            }
			            
			        });

		
		// pour pouvoir changer l'image du personnage, mouvement 
		mvt.addListener(new ChangeListener<Number>() {

			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				
				switch(env.getLink().getDeplacement().getOrientation().get()) {
					case 0:
						vue.getVuePerso().setImage(vue.getPersDos());
						env.getLink().getDeplacement().incrementerCompteurPas();
						System.out.println(env.getLink().getDeplacement().getCompteurPas());
						if(env.getLink().getDeplacement().getCompteurPas()%6==0 || env.getLink().getDeplacement().getCompteurPas()%6==1 || env.getLink().getDeplacement().getCompteurPas()%6==2){
	                		vue.getVuePerso().setImage(vue.getPersFaceMarche1());
	                	}
	                	else{
	                		vue.getVuePerso().setImage(vue.getPersFaceMarche2());
	                	}
		
						
					break;
					case 1:
						vue.getVuePerso().setImage(vue.getPersFace());
						env.getLink().getDeplacement().incrementerCompteurPas();
						if(env.getLink().getDeplacement().getCompteurPas()%6==0 || env.getLink().getDeplacement().getCompteurPas()%6==1|| env.getLink().getDeplacement().getCompteurPas()%6==2){
	                		vue.getVuePerso().setImage(vue.getPersDosMarche1());
	                	}
	                	else{
	                		vue.getVuePerso().setImage(vue.getPersDosMarche2());
	                	}
					break;
					case 2 :
						vue.getVuePerso().setImage(vue.getPersDroite());
						env.getLink().getDeplacement().incrementerCompteurPas();
	                     if(env.getLink().getDeplacement().getCompteurPas()%6==0 || env.getLink().getDeplacement().getCompteurPas()%6==1|| env.getLink().getDeplacement().getCompteurPas()%6==2){
	                 		vue.getVuePerso().setImage(vue.getPersDroiteMarche1());
	                 	}
	                 	else{
	                 		vue.getVuePerso().setImage(vue.getPersDroiteMarche2());
	                 	}
	                  break;
					case 3:
						vue.getVuePerso().setImage(vue.getPersGauche());
						env.getLink().getDeplacement().incrementerCompteurPas();
						if(env.getLink().getDeplacement().getCompteurPas()%6==0 || env.getLink().getDeplacement().getCompteurPas()%6==1 || env.getLink().getDeplacement().getCompteurPas()%6==2){
							vue.getVuePerso().setImage(vue.getPersGaucheMarche1());
		            	}
		            	else{
		            		vue.getVuePerso().setImage(vue.getPersGaucheMarche2());
		            	}
	            
	                 break;
						
				}
			}
			
		}
				);
		//viewperso.translateXProperty().addListener();
		
	}
	
    public void deplacement(KeyEvent key) {
		KeyCode codeDeLaTouche = key.getCode();
		
		if(!invent.isVisible()) {
		switch (codeDeLaTouche) 
        {
		
			case Z:
            case UP:
        		if(env.getLink().getDeplacement().monter()==true) {
            		env.getScroll().setPosYFenetre();
            		scrolling.relocate(-env.getScroll().getPosXFenetre(), -env.getScroll().getPosYFenetre());
            		mvt.set(mvt.get()+1);
        		}
                break;
            case Q:
            case LEFT:
        		if(env.getLink().getDeplacement().gauche()==true) {
        			//env.getLink().gagnerPV(env.getLink().getPDV()+1);
            		env.getScroll().setPosXFenetre();
            		scrolling.relocate(-env.getScroll().getPosXFenetre(), -env.getScroll().getPosYFenetre());
            		mvt.set(mvt.get()+1); 
	               
        		}
                
                break;
            case D:
            case RIGHT:
        		if(env.getLink().getDeplacement().droite()==true) {
        			//env.getLink().perdrePV();
            		env.getScroll().setPosXFenetre();
            		scrolling.relocate(-env.getScroll().getPosXFenetre(), -env.getScroll().getPosYFenetre());
            		mvt.set(mvt.get()+1);
            	}
               
                break;
            case S :
            case DOWN:
        		if(env.getLink().getDeplacement().descendre()==true) {
            		env.getScroll().setPosYFenetre();
            		scrolling.relocate(-env.getScroll().getPosXFenetre(), -env.getScroll().getPosYFenetre());
            		mvt.set(mvt.get()+1);
        		}
                
                break;
            //ouvrir l'inventaire  
            case I:
        		invent.setVisible(true);
        		break;
        	//attaquer
            case SPACE:
            	event.add(new Evenement("Attaque de link",2,0));
            	break;
           
            case ENTER :
            	//parler a un pnj
            	//verifier collision avec pnj
            	if(texte.isVisible()) {
            		texte.setVisible(false);
        		}
            	
            	else if (env.getLink().getDeplacement().getDetecteur().testCollisionBas(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx()) || 
            			env.getLink().getDeplacement().getDetecteur().testCollisionHaut(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx()) ||
            			env.getLink().getDeplacement().getDetecteur().testCollisionGauche(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx()) ||
            			env.getLink().getDeplacement().getDetecteur().testCollisionDroit(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx())) {
            		texte.setVisible(true);
            	}
            	
            	//ramasser objet
            	if (env.getLink().getDeplacement().getObj()!=null) {
            		env.getLink().ajouterObjet(env.getLink().getDeplacement().getObj());
            		for(int i=0; i<env.getListeObj().size(); i++) {
            			if(env.getLink().getDeplacement().getObj().equals(env.getListeObj().get(i))) {
            				System.out.println(i);
            				env.getListeObj().get(i).getCase().setX(1278);
            				env.getListeObj().get(i).getCase().setY(1918);
            				listeVue.get(i).setVisible(false);
            				vue.getVuePotion().setVisible(true);
            			}
            		}
            		
            	}
            	
            	
            break;
            
            
		}
		}
		else {
			switch(codeDeLaTouche) {
			
			//affichage de linventaire
            case I:
            	//setvisiblefalse -> rendre invisible le pane 
            	//creer un pane et lenlever a la pression de la touche remove
            	//pane new pane 
            	if (invent.isVisible()) {
            		invent.setVisible(false);
            	}
            	else {
            		invent.setVisible(true);
            	}
            	
            	
            	break;
            case Z:
            case UP:
            	if(env.getCoordCarre().getY()>40) {
            	env.setCoordCarre(env.getCoordCarre().getX(), env.getCoordCarre().getY()-180);
            	vue.getVueCarre().relocate(env.getCoordCarre().getX(), env.getCoordCarre().getY());
            	}
                break;
            case Q:
            case LEFT:
            	if(env.getCoordCarre().getX()>40) {
            	env.setCoordCarre(env.getCoordCarre().getX()-180, env.getCoordCarre().getY());
            	vue.getVueCarre().relocate(env.getCoordCarre().getX(), env.getCoordCarre().getY());
            	}
                break;
            case D:
            case RIGHT:
            	if(env.getCoordCarre().getX()<400) {
            	env.setCoordCarre(env.getCoordCarre().getX()+180, env.getCoordCarre().getY());
            	vue.getVueCarre().relocate(env.getCoordCarre().getX(), env.getCoordCarre().getY());
            	}
                break;
            case S :
            case DOWN:
            	if(env.getCoordCarre().getY()<400) {
            	env.setCoordCarre(env.getCoordCarre().getX(), env.getCoordCarre().getY()+180);
            	vue.getVueCarre().relocate(env.getCoordCarre().getX(), env.getCoordCarre().getY());
            	env.getLink().perdrePV();
            	}
                break;
            case ENTER :
            	//verifiaction objet selectionner
            	for(int i=0; i<env.getListeCoord().size();i++) {
            		if(env.getListeCoord().get(i).getX()>env.getCoordCarre().getX() && env.getListeCoord().get(i).getX()+60<env.getCoordCarre().getX()+160) {
            			if(env.getListeCoord().get(i).getY()>env.getCoordCarre().getY() && env.getListeCoord().get(i).getY()+60<env.getCoordCarre().getY()+160) {
            				//System.out.println("objet!!!");
            				env.getLink().boirePotion(env.getListeObj().get(i).getNom());
            				vue.getVuePotion().setVisible(false);
            				//enlev� de linv
            				env.getListeCoord().get(i).setX(70);
            				env.getListeCoord().get(i).setY(700);
            				//System.out.println(env.getLink().getPDV());
            			}
            		}
            	}
            	
				break;
			

			}
			
			
		}
		
    }
    
    private void initAnimation() {
    	gameLoop = new Timeline();
    	temps=0;
    	gameLoop.setCycleCount(Timeline.INDEFINITE);
    	KeyFrame kf = new KeyFrame(
				Duration.seconds(0.05),(ev ->{
					if(env.getLink().getPDV()==0) {
						System.out.println("WASTED");
						gameover.setVisible(true);
						gameLoop.stop();
					}
					else {
						/*for(int i=0;i<event.size();i++){
							if(event.get(i).getBloqueAction()==false){
								
							}
						}*/
						((Archer)env.getListePers().get(1)).getDeplacement().agir();
						((Archer)env.getListePers().get(2)).getDeplacement().agir();
						//bfs.deplaceBFS();
					}
					temps++;
				})
				);
    	gameLoop.getKeyFrames().add(kf);
    }
    
  //quand le personage ne bouge plus 
  	public void touheRelache(KeyEvent event) {
  		switch(env.getLink().getDeplacement().getOrientation().get()) {
  		case 0:
  			vue.getVuePerso().setImage(vue.getPersFace());
  			break;
  		case 1:
  			vue.getVuePerso().setImage(vue.getPersDos());
  			break;
  		case 2:
  			vue.getVuePerso().setImage(vue.getPersDroite());
  		break;
  		case 3 :
  			vue.getVuePerso().setImage(vue.getPersGauche());
  			break;
  			
  		}
  	}
}
