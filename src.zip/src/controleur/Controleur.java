package controleur;

import modele.Personnage;
import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import modele.Link;
import modele.Map;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;

public class Controleur implements Initializable {
	
	private Link link;
	private Scrolling sc;
	
	@FXML
    private Pane affichage;

    @FXML
    private Pane terrain;

    @FXML
    private Pane objets;
	
    

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		Map mapLogique = new Map("src/modele/map.txt");
		mapLogique.initMapLogique();
		int[][] map = mapLogique.getMapLogique();
		
		Map map2ecouche = new Map("src/modele/map2.txt");
		map2ecouche.initMapLogique();
		int[][] map2 = map2ecouche.getMapLogique();
		
		for ( int x = 0 ; x < map.length ; x++ ) {
			for ( int y = 0 ; y < map[x].length ; y ++) {
				if (map[x][y]==2){
				
					File f=new File("src/img/herbe.png");
					Image herbe = new Image(f.toURI().toString(),32,32,false,false);
					ImageView viewHerbe = new ImageView();
					viewHerbe.setImage(herbe);
					terrain.getChildren().add(viewHerbe);
					viewHerbe.relocate(y*32, x*32);
					
				}
				else if(map[x][y]==3){
					File g=new File("src/img/chemin.png");
					Image chemin = new Image(g.toURI().toString(),32,32,false,false);
					ImageView viewchemin = new ImageView();
					viewchemin.setImage(chemin);
					terrain.getChildren().add(viewchemin);
					viewchemin.relocate(y*32, x*32);
				}
			}
		}
		for ( int x = 0 ; x < map2.length ; x++ ) {
			for ( int y = 0 ; y < map2[x].length ; y ++) {
				
				 if(map2[x][y]==1){
					File h=new File("src/img/hautes_herbes.png");
					Image hautes_herbes = new Image(h.toURI().toString(),32,32,false,false);
					ImageView viewhautes_herbes = new ImageView();
					viewhautes_herbes.setImage(hautes_herbes);
					objets.getChildren().add(viewhautes_herbes);
					viewhautes_herbes.relocate(y*32, x*32);
				 }
				
				
			}
		}
		
		File image=new File("src/img/link.png");
		Image pers = new Image(image.toURI().toString(),32,32,false,false);
		ImageView viewperso = new ImageView();
		viewperso.setImage(pers);
		objets.getChildren().add(viewperso);
		link = new Link(160,160,map2);
		sc=new Scrolling(link);
		
		
		viewperso.translateXProperty().bind(link.getPosX());
		viewperso.translateYProperty().bind(link.getPosY());
		
	}
	
    public void deplacement(KeyEvent key) {
		KeyCode codeDeLaTouche = key.getCode();
        
		switch (codeDeLaTouche) 
        {
            case UP:
            	if(link.monter()==true) {
            		sc.setPosYFenetre();
            		System.out.println(sc.getPosYFenetre());
            	}
                break;
            case LEFT:
                if(link.gauche()==true) {
            		sc.setPosXFenetre();
            		System.out.println(sc.getPosXFenetre());
            	}
                break;
            case RIGHT:
                if(link.droite()==true) {
            		sc.setPosXFenetre();
            		System.out.println(sc.getPosXFenetre());
            	}
                break;
            case DOWN:
                if(link.descendre()==true) {
            		sc.setPosYFenetre();
            		System.out.println(sc.getPosYFenetre());
            	}
                break;
            default:
            	break;
        }
		
    }
}
