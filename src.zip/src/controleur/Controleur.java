package controleur;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import modele.Archer;
import modele.Deplacement;
import modele.DeplacementAleatoire;
import modele.DeplacementHorizontale;
import modele.Link;
import modele.Map;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.util.Duration;

public class Controleur implements Initializable {
	
	private Timeline gameLoop;
	
	private int temps;
	
	private ArrayList<Evenement> event;
	
	private Link link;
	private Archer archer1;
	private Archer archer2;
	//private BFS bfs;
	
	private Scrolling sc;
	private ImageView viewperso = new ImageView();
	
	//viue test
	private ImageView viewtest = new ImageView();
	
	//Test deplacement monstre avec gameloop
	private ImageView viewmonstre = new ImageView();
	private ImageView viewmonstre2 = new ImageView();
	
	private IntegerProperty mvt=new SimpleIntegerProperty(0);
	
	//monte
	File image_link_dos=new File("src/link/link_dos.png");
	Image pers_dos= new Image(image_link_dos.toURI().toString(),32,32,false,false);
	File image_link_dos_marche1=new File("src/link/link_dos_marche1.png");
	Image pers_dos_marche1= new Image(image_link_dos_marche1.toURI().toString(),32,32,false,false);
	File image_link_dos_marche2=new File("src/link/link_dos_marche2.png");
	Image pers_dos_marche2= new Image(image_link_dos_marche2.toURI().toString(),32,32,false,false);
	
	//gauche
	File image_link_gauche=new File("src/link/link_profil_gauche.png");
	Image pers_gauche= new Image(image_link_gauche.toURI().toString(),32,32,false,false);
	File image_link_gauche_marche1=new File("src/link/link_profil_gauche_marche1.png");
	Image pers_gauche_marche1= new Image(image_link_gauche_marche1.toURI().toString(),32,32,false,false);
	File image_link_gauche_marche2=new File("src/link/link_profil_gauche_marche2.png");
	Image pers_gauche_marche2= new Image(image_link_gauche_marche2.toURI().toString(),32,32,false,false);
	//droite
	File image_link_droite=new File("src/link/link_profil_doite.png");
	Image pers_droite= new Image(image_link_droite.toURI().toString(),32,32,false,false);
	File image_link_droite_marche1=new File("src/link/link_profil_doite_marche1.png");
	Image pers_droite_marche1= new Image(image_link_droite_marche1.toURI().toString(),32,32,false,false);
	File image_link_droite_marche2=new File("src/link/link_profil_doite_marche2.png");
	Image pers_droite_marche2= new Image(image_link_droite_marche2.toURI().toString(),32,32,false,false);
	//descend
	File image_link_face=new File("src/link/link_face.png");
	Image pers_face = new Image(image_link_face.toURI().toString(),32,32,false,false);
	File image_link_face_marche1=new File("src/link/link_face_marche1.png");
	Image pers_face_marche1 = new Image(image_link_face_marche1.toURI().toString(),32,32,false,false);
	File image_link_face_marche2=new File("src/link/link_face_marche2.png");
	Image pers_face_marche2 = new Image(image_link_face_marche2.toURI().toString(),32,32,false,false);
	
	@FXML
    private Pane affichage;

    @FXML
    private Pane terrain;

    @FXML
    private Pane objets;
    
    @FXML
    private Pane menu;
    
    @FXML
    private Pane scrolling;
    
    private DetecteurCollisionPersonnage detColPerso;
    
    private ArrayList<Case> liste;


	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		//creation premiere couche map
		Map mapLogique = new Map("src/modele/map.txt");
		mapLogique.initMapLogique();
		int[][] map = mapLogique.getMapLogique();
		
		//creation deuxieme couche map
		Map map2ecouche = new Map("src/modele/map2.txt");
		map2ecouche.initMapLogique();
		int[][] map2 = map2ecouche.getMapLogique();
		
		for ( int x = 0 ; x < map.length ; x++ ) {
			for ( int y = 0 ; y < map[x].length ; y ++) {
				if (map[x][y]==2){
					//stocker dans une map ? tableau avec indice en string 
					//methode speciale dans une classe ?
					File f=new File("src/img/herbe.png");
					Image herbe = new Image(f.toURI().toString(),32,32,false,false);
					ImageView viewHerbe = new ImageView();
					viewHerbe.setImage(herbe);
					terrain.getChildren().add(viewHerbe);
					viewHerbe.relocate(y*32, x*32);
					
				}
				else if(map[x][y]==3){
					File g=new File("src/img/chemin.png");
					Image chemin = new Image(g.toURI().toString(),32,32,false,false);
					ImageView viewchemin = new ImageView();
					viewchemin.setImage(chemin);
					terrain.getChildren().add(viewchemin);
					viewchemin.relocate(y*32, x*32);
				}
			}
		}
		for ( int x = 0 ; x < map2.length ; x++ ) {
			for ( int y = 0 ; y < map2[x].length ; y ++) {
				
				 if(map2[x][y]==1){
					File h=new File("src/img/hautes_herbes.png");
					Image hautes_herbes = new Image(h.toURI().toString(),32,32,false,false);
					ImageView viewhautes_herbes = new ImageView();
					viewhautes_herbes.setImage(hautes_herbes);
					objets.getChildren().add(viewhautes_herbes);
					viewhautes_herbes.relocate(y*32, x*32);
				 }
			}
		}
		
		liste= new ArrayList<Case>();
		
		
		
		
		
		detColPerso=new DetecteurCollisionPersonnage(liste);
		
		//initialisation link 
		Deplacement l = new Deplacement(new Case(50,50), map2, liste);
		link = new Link(l,detColPerso);
		sc=new Scrolling(link);
		
		objets.getChildren().add(viewperso);
 		viewperso.translateXProperty().bind(link.getDeplacement().getPosX());
		viewperso.translateYProperty().bind(link.getDeplacement().getPosY());
		viewperso.setImage(pers_face);
		
		
		/*//test affichage menu
		viewtest.setImage(pers_dos);
		menu.getChildren().add(viewtest);*/
		
		//deplacement et affichage monstres
		
		Deplacement d1 = new DeplacementHorizontale(new Case(60,60),map2, liste);
		archer1 = new Archer(d1);
		viewmonstre.setImage(pers_dos);
		objets.getChildren().add(viewmonstre);
		
		System.out.println(archer1);
		liste.add(archer1.getDeplacement().getCase());
		//liste.get(0).getXProperty().bind(archer1.getDeplacement().getPosX());
		//liste.get(0).getYProperty().bind(archer1.getDeplacement().getPosY());
		
		viewmonstre.translateXProperty().bind(archer1.getDeplacement().getPosX());
		viewmonstre.translateYProperty().bind(archer1.getDeplacement().getPosY());
		
		
		Case[][] plateau= new Case[5][10];
		Case caseD= new Case(80,100);
		Case caseF= new Case(10,10);
		//bfs = new BFS(plateau,caseD,caseF,map2);
		Deplacement d2 = new DeplacementAleatoire(new Case(80,100),map2,liste);
		archer2 = new Archer(d2);
		viewmonstre2.setImage(pers_droite_marche2);
		objets.getChildren().add(viewmonstre2);
		
		viewmonstre2.translateXProperty().bind(archer2.getDeplacement().getPosX());
		viewmonstre2.translateYProperty().bind(archer2.getDeplacement().getPosY());
		
		initAnimation();
		gameLoop.play();
		
		

		
		// pour pouvoir changer l'image du personnage, mouvement 
		mvt.addListener(new ChangeListener<Number>() {

			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				
				
				switch(link.getDeplacement().getOrientation().get()) {
					case 0:
						viewperso.setImage(pers_dos);
						link.getDeplacement().incrementerCompteurPas();
						System.out.println(link.getDeplacement().getCompteurPas());
						if(link.getDeplacement().getCompteurPas()%6==0 || link.getDeplacement().getCompteurPas()%6==1 || link.getDeplacement().getCompteurPas()%6==2){
	                		viewperso.setImage(pers_face_marche1);
	                	}
	                	else{
	                		viewperso.setImage(pers_face_marche2);
	                	}
		
						
					break;
					case 1:
						viewperso.setImage(pers_face);
						link.getDeplacement().incrementerCompteurPas();
						if(link.getDeplacement().getCompteurPas()%6==0 || link.getDeplacement().getCompteurPas()%6==1|| link.getDeplacement().getCompteurPas()%6==2){
	                		viewperso.setImage(pers_dos_marche1);
	                	}
	                	else{
	                		viewperso.setImage(pers_dos_marche2);
	                	}
					break;
					case 2 :
						viewperso.setImage(pers_droite);
						link.getDeplacement().incrementerCompteurPas();
	                     if(link.getDeplacement().getCompteurPas()%6==0 || link.getDeplacement().getCompteurPas()%6==1|| link.getDeplacement().getCompteurPas()%6==2){
	                 		viewperso.setImage(pers_droite_marche1);
	                 	}
	                 	else{
	                 		viewperso.setImage(pers_droite_marche2);
	                 	}
	                  break;
					case 3:
						viewperso.setImage(pers_gauche);
						link.getDeplacement().incrementerCompteurPas();
						if(link.getDeplacement().getCompteurPas()%6==0 || link.getDeplacement().getCompteurPas()%6==1 || link.getDeplacement().getCompteurPas()%6==2){
		            		viewperso.setImage(pers_gauche_marche1);
		            	}
		            	else{
		            		viewperso.setImage(pers_gauche_marche2);
		            	}
	            
	                 break;
						
				}
			}
			
		}
				);
		//viewperso.translateXProperty().addListener();
	
		System.out.println("fin initit");
	}
	
    public void deplacement(KeyEvent key) {
		KeyCode codeDeLaTouche = key.getCode();
		
		switch (codeDeLaTouche) 
        {
            case UP:
        		if(link.getDeplacement().monter()==true) {
            		sc.setPosYFenetre();
            		scrolling.relocate(-sc.getPosXFenetre(), -sc.getPosYFenetre());
            		mvt.set(mvt.get()+1);
            		
        		}
                break;
            case LEFT:
        		if(link.getDeplacement().gauche()==true) {
            		sc.setPosXFenetre();
            		scrolling.relocate(-sc.getPosXFenetre(), -sc.getPosYFenetre());
            		mvt.set(mvt.get()+1); 
	               
        		}
                
                break;
            case RIGHT:
        		if(link.getDeplacement().droite()==true) {
            		sc.setPosXFenetre();
            		scrolling.relocate(-sc.getPosXFenetre(), -sc.getPosYFenetre());
            		mvt.set(mvt.get()+1);
            	}
               
                break;
            case DOWN:
        		if(link.getDeplacement().descendre()==true) {
            		sc.setPosYFenetre();
            		scrolling.relocate(-sc.getPosXFenetre(), -sc.getPosYFenetre());
            		mvt.set(mvt.get()+1);
        		}
                
                break;
            case ENTER:
            	event.add(new Evenement("Attaque de link",2,0));
            	break;
        }
		
    }
    
    private void initAnimation() {
    	gameLoop = new Timeline();
    	temps=0;
    	gameLoop.setCycleCount(Timeline.INDEFINITE);
    	KeyFrame kf = new KeyFrame(
				Duration.seconds(0.05),(ev ->{
					if(link.getPDV()==0) {
						System.out.println("WASTED");
						gameLoop.stop();
					}
					else {
						System.out.println("gameloop");
						/*for(int i=0;i<event.size();i++){
							if(event.get(i).getBloqueAction()==false){
								
							}
						}*/
						//archer1.getDeplacement().agir();
						//archer2.getDeplacement().agir();
						//bfs.deplaceBFS();
					}
					temps++;
				})
				);
    	gameLoop.getKeyFrames().add(kf);
    }
    //voir plus tard 
   /* public void arretdeplacement(KeyEvent key) {
    	
    }*/
}
