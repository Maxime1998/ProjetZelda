package controleur;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import org.omg.CORBA.Environment;

import modele.Arc;
import modele.Archer;
import modele.Deplacement;
import modele.DeplacementAleatoire;
import modele.DeplacementHorizontale;
import modele.Environnement;
import modele.Epee;
import modele.Fleche;
import modele.Link;
import modele.Map;
import modele.Objets;
import modele.Personnage;
import modele.PotionVie;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.util.Duration;

public class Controleur implements Initializable {
	
	private Timeline gameLoop;
	
	private int temps;
	private int vie_link;
	private Case vie ;
	
	private ArrayList<Evenement> event;
	
	private Environnement env;
	
	private BFS bfs;
	
	private ImageView viewperso = new ImageView();
	
	
	//Test deplacement monstre avec gameloop
	private ImageView viewmonstre = new ImageView();
	private ImageView viewmonstre2 = new ImageView();
	private ImageView vueboite = new ImageView();
	private ImageView vueboite2 = new ImageView();
	
	private IntegerProperty mvt=new SimpleIntegerProperty(0);
	
	//Boolean pour atraper un objet poussable
	private boolean attraperObjetPoussable=false;
	private int indiceObjet;
	
	//Boolean pour les attaques
	private boolean attaquePossible=false;
	private int indicePerso;
	
	//boolean pour déplacements
	private boolean monterOK=false;
	private boolean descendreOK=false;
	private boolean droiteOK=false;
	private boolean gaucheOK=false;
	
	//Code pour les flèches
	private File fileflechedroit=new File("src/img/Flèche-bombe.png");
	private Image imgflechedroit = new Image(fileflechedroit.toURI().toString(),32,10,false,false);
	private File fileflechegauche=new File("src/img/Flèche-bombe-gauche.png");
	private Image imgflechegauche = new Image(fileflechegauche.toURI().toString(),32,10,false,false);
	private File fileflechehaut=new File("src/img/Flèche-bombe-haut.png");
	private Image imgflechehaut = new Image(fileflechehaut.toURI().toString(),10,32,false,false);
	private File fileflechebas=new File("src/img/Flèche-bombe-bas.png");
	private Image imgflechebas = new Image(fileflechebas.toURI().toString(),10,32,false,false);
	private Fleche fleche;
	private ImageView viewfleche = new ImageView();
	private boolean attaqueArcPossible=false;
	
	
	//monte
		File image_link_dos=new File("src/link/link_dos.png");
		Image pers_dos= new Image(image_link_dos.toURI().toString(),32,32,false,false);
		File image_link_dos_marche1=new File("src/link/link_dos_marche1.png");
		Image pers_dos_marche1= new Image(image_link_dos_marche1.toURI().toString(),32,32,false,false);
		File image_link_dos_marche2=new File("src/link/link_dos_marche2.png");
		Image pers_dos_marche2= new Image(image_link_dos_marche2.toURI().toString(),32,32,false,false);
		
		//gauche
		File image_link_gauche=new File("src/link/link_profil_gauche.png");
		Image pers_gauche= new Image(image_link_gauche.toURI().toString(),32,32,false,false);
		File image_link_gauche_marche1=new File("src/link/link_profil_gauche_marche1.png");
		Image pers_gauche_marche1= new Image(image_link_gauche_marche1.toURI().toString(),32,32,false,false);
		File image_link_gauche_marche2=new File("src/link/link_profil_gauche_marche2.png");
		Image pers_gauche_marche2= new Image(image_link_gauche_marche2.toURI().toString(),32,32,false,false);
		//droite
		File image_link_droite=new File("src/link/link_profil_doite.png");
		Image pers_droite= new Image(image_link_droite.toURI().toString(),32,32,false,false);
		File image_link_droite_marche1=new File("src/link/link_profil_doite_marche1.png");
		Image pers_droite_marche1= new Image(image_link_droite_marche1.toURI().toString(),32,32,false,false);
		File image_link_droite_marche2=new File("src/link/link_profil_doite_marche2.png");
		Image pers_droite_marche2= new Image(image_link_droite_marche2.toURI().toString(),32,32,false,false);
		//descend
		File image_link_face=new File("src/link/link_face.png");
		Image pers_face = new Image(image_link_face.toURI().toString(),32,32,false,false);
		File image_link_face_marche1=new File("src/link/link_face_marche1.png");
		Image pers_face_marche1 = new Image(image_link_face_marche1.toURI().toString(),32,32,false,false);
		File image_link_face_marche2=new File("src/link/link_face_marche2.png");
		Image pers_face_marche2 = new Image(image_link_face_marche2.toURI().toString(),32,32,false,false);
		
		//image coeur pour les points de vie
	    File image_coeur=new File("src/img/barre_vie.png");
	    Image coeur = new Image(image_coeur.toURI().toString(),160,32,false,false);
	    ImageView viewcoeur=new ImageView(coeur);
	    
	    
	    //vue test pour inventaire 
	    File image_inv=new File("src/img/MenuDistributeur.png");
	    Image inv = new Image(image_inv.toURI().toString(),600,600,false,false);
	    ImageView vueinv = new ImageView(inv);
	    
	    //potion vie
	    File image_potion= new File("src/img/potion.png");
	    Image potion= new Image(image_potion.toURI().toString(),64,64,false,false);
	    ImageView vuepotion = new ImageView(potion);
	
	@FXML
    private Pane affichage;

    @FXML
    private Pane terrain;

    @FXML
    private Pane objets;
    
    @FXML
    private Pane scrolling;
    
    @FXML
    private Pane menu;
    
    @FXML
    private Pane invent;


	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		this.env= new Environnement() ;
		
		
		//boucle affichage premiere couche
				for ( int x = 0 ; x < env.getMap().length ; x++ ) {
					for ( int y = 0 ; y < env.getMap()[x].length ; y ++) {
						switch(env.getMap()[x][y]) {
						case 14 :
							File h=new File("src/img/herbe2.png");
							Image herbe = new Image(h.toURI().toString(),32,32,false,false);
							ImageView viewherbe = new ImageView();
							viewherbe.setImage(herbe);
							objets.getChildren().add(viewherbe);
							viewherbe.relocate(y*32, x*32);
						break;
						case 15 :
							File g=new File("src/img/bordure_chemin_gauche.png");
							Image bordure_chemin_gauche = new Image(g.toURI().toString(),32,32,false,false);
							ImageView viewbordure_chemin_gauche = new ImageView();
							viewbordure_chemin_gauche.setImage(bordure_chemin_gauche);
							objets.getChildren().add(viewbordure_chemin_gauche);
							viewbordure_chemin_gauche.relocate(y*32, x*32);
						break;
						case 13 :
							File e=new File("src/img/chemin_milieu.png");
							Image chemin_milieu = new Image(e.toURI().toString(),32,32,false,false);
							ImageView viewchemin_milieu = new ImageView();
							viewchemin_milieu.setImage(chemin_milieu);
							objets.getChildren().add(viewchemin_milieu);
							viewchemin_milieu.relocate(y*32, x*32);
						break;
						case 12:
							File f=new File("src/img/bordure_chemin_droite.png");
							Image bordure_chemin_droite = new Image(f.toURI().toString(),32,32,false,false);
							ImageView viewbordure_chemin_droite = new ImageView();
							viewbordure_chemin_droite.setImage(bordure_chemin_droite);
							objets.getChildren().add(viewbordure_chemin_droite);
							viewbordure_chemin_droite.relocate(y*32, x*32);
						break;
						case 20:
							File b3=new File("src/img/bordure_chemin_bas.png");
							Image bordure_chemin_bas = new Image(b3.toURI().toString(),32,32,false,false);
							ImageView viewbordure_chemin_bas = new ImageView();
							viewbordure_chemin_bas.setImage(bordure_chemin_bas);
							objets.getChildren().add(viewbordure_chemin_bas);
							viewbordure_chemin_bas.relocate(y*32, x*32);
						break;
						case 18:
							File b4=new File("src/img/bordure_chemin_haut.png");
							Image bordure_chemin_haut = new Image(b4.toURI().toString(),32,32,false,false);
							ImageView viewbordure_chemin_haut = new ImageView();
							viewbordure_chemin_haut.setImage(bordure_chemin_haut);
							objets.getChildren().add(viewbordure_chemin_haut);
							viewbordure_chemin_haut.relocate(y*32, x*32);
						break;
						//tournants chemin
						case 23:
							File b2=new File("src/img/angle-chemin_ext_bg.png");
							Image angle_chemin_ext_bg = new Image(b2.toURI().toString(),32,32,false,false);
							ImageView viewangle_chemin_ext_bg = new ImageView();
							viewangle_chemin_ext_bg.setImage(angle_chemin_ext_bg);
							objets.getChildren().add(viewangle_chemin_ext_bg);
							viewangle_chemin_ext_bg.relocate(y*32, x*32);
						break;
						case 22:
							File c1=new File("src/img/angle-chemin_bg.png");
							Image angle_chemin_bg = new Image(c1.toURI().toString(),32,32,false,false);
							ImageView viewangle_chemin_bg = new ImageView();
							viewangle_chemin_bg.setImage(angle_chemin_bg);
							objets.getChildren().add(viewangle_chemin_bg);
							viewangle_chemin_bg.relocate(y*32, x*32);
						break;
						case 21:
							File c2=new File("src/img/angle-chemin_ext_hd.png");
							Image angle_chemin_ext_hd = new Image(c2.toURI().toString(),32,32,false,false);
							ImageView viewangle_chemin_ext_hd = new ImageView();
							viewangle_chemin_ext_hd.setImage(angle_chemin_ext_hd);
							objets.getChildren().add(viewangle_chemin_ext_hd);
							viewangle_chemin_ext_hd.relocate(y*32, x*32);
						break;
						case 17:
							File c4=new File("src/img/angle-chemin_hd.png");
							Image angle_chemin_hd = new Image(c4.toURI().toString(),32,32,false,false);
							ImageView viewangle_chemin_hd = new ImageView();
							viewangle_chemin_hd.setImage(angle_chemin_hd);
							objets.getChildren().add(viewangle_chemin_hd);
							viewangle_chemin_hd.relocate(y*32, x*32);
						break;
						case 31:
							File c5=new File("src/img/angle-chemin_ext_hg.png");
							Image angle_chemin_ext_hg = new Image(c5.toURI().toString(),32,32,false,false);
							ImageView viewangle_chemin_ext_hg = new ImageView();
							viewangle_chemin_ext_hg.setImage(angle_chemin_ext_hg);
							objets.getChildren().add(viewangle_chemin_ext_hg);
							viewangle_chemin_ext_hg.relocate(y*32, x*32);
						break;
						case 30:
							File c6=new File("src/img/angle-chemin_hg.png");
							Image angle_chemin_hg = new Image(c6.toURI().toString(),32,32,false,false);
							ImageView viewangle_chemin_hg = new ImageView();
							viewangle_chemin_hg.setImage(angle_chemin_hg);
							objets.getChildren().add(viewangle_chemin_hg);
							viewangle_chemin_hg.relocate(y*32, x*32);
						break;
						case 32:
							File c7=new File("src/img/angle-chemin_bd.png");
							Image angle_chemin_bd = new Image(c7.toURI().toString(),32,32,false,false);
							ImageView viewangle_chemin_bd = new ImageView();
							viewangle_chemin_bd.setImage(angle_chemin_bd);
							objets.getChildren().add(viewangle_chemin_bd);
							viewangle_chemin_bd.relocate(y*32, x*32);
						break;
						
						
						
						case 60:
							File f1=new File("src/img/fleurs_bleue.png");
							Image fleurs_bleue = new Image(f1.toURI().toString(),32,32,false,false);
							ImageView viewfleurs_bleue = new ImageView();
							viewfleurs_bleue.setImage(fleurs_bleue);
							objets.getChildren().add(viewfleurs_bleue);
							viewfleurs_bleue.relocate(y*32, x*32);
						break;
						case 61:
							File f2=new File("src/img/fleurs_rouge.png");
							Image fleurs_rouge = new Image(f2.toURI().toString(),32,32,false,false);
							ImageView viewfleurs_rouge = new ImageView();
							viewfleurs_rouge.setImage(fleurs_rouge);
							objets.getChildren().add(viewfleurs_rouge);
							viewfleurs_rouge.relocate(y*32, x*32);
						break;
						
						//pont
						case 41 :
							File p1=new File("src/pont/pont_1x1.png");
							Image pont1= new Image(p1.toURI().toString(),32,32,false,false);
							ImageView viewpont1 = new ImageView();
							viewpont1.setImage(pont1);
							objets.getChildren().add(viewpont1);
							viewpont1.relocate(y*32, x*32);
						break;
						case 42 :
							File p2=new File("src/pont/pont_1x2.png");
							Image pont2= new Image(p2.toURI().toString(),32,32,false,false);
							ImageView viewpont2 = new ImageView();
							viewpont2.setImage(pont2);
							objets.getChildren().add(viewpont2);
							viewpont2.relocate(y*32, x*32);
						break;
						case 43 :
							File p3=new File("src/pont/pont_1x3.png");
							Image pont3= new Image(p3.toURI().toString(),32,32,false,false);
							ImageView viewpont3 = new ImageView();
							viewpont3.setImage(pont3);
							objets.getChildren().add(viewpont3);
							viewpont3.relocate(y*32, x*32);
						break;
						
						}
					}
				}
				
				//boucle affichage deuxieme couche
				for ( int x = 0 ; x < env.getMap2().length ; x++ ) {
					for ( int y = 0 ; y < env.getMap2()[x].length ; y ++) {
						
						switch(env.getMap2()[x][y]) {
						//arbre
						case 8 :
							File a=new File("src/img/arbre/1x1.png");
							Image arbre= new Image(a.toURI().toString(),32,32,false,false);
							ImageView viewarbre = new ImageView();
							viewarbre.setImage(arbre);
							objets.getChildren().add(viewarbre);
							viewarbre.relocate(y*32, x*32);
						break;
						case 9 :
							File b=new File("src/img/arbre/1x2.png");
							Image arbre1= new Image(b.toURI().toString(),32,32,false,false);
							ImageView viewarbre1 = new ImageView();
							viewarbre1.setImage(arbre1);
							objets.getChildren().add(viewarbre1);
							viewarbre1.relocate(y*32, x*32);
						break;
						case 10 :
							File c=new File("src/img/arbre/2x1.png");
							Image arbre2= new Image(c.toURI().toString(),32,32,false,false);
							ImageView viewarbre2 = new ImageView();
							viewarbre2.setImage(arbre2);
							objets.getChildren().add(viewarbre2);
							viewarbre2.relocate(y*32, x*32);
						break;
						case 11 :
							File d=new File("src/img/arbre/2x2.png");
							Image arbre3= new Image(d.toURI().toString(),32,32,false,false);
							ImageView viewarbre3 = new ImageView();
							viewarbre3.setImage(arbre3);
							objets.getChildren().add(viewarbre3);
							viewarbre3.relocate(y*32, x*32);
						break;
						
						//arbre2
						case 12 :
							File a4=new File("src/img/arbre2/1x1.png");
							Image arbre4= new Image(a4.toURI().toString(),32,32,false,false);
							ImageView viewarbre4 = new ImageView();
							viewarbre4.setImage(arbre4);
							objets.getChildren().add(viewarbre4);
							viewarbre4.relocate(y*32, x*32);
						break;
						case 13 :
							File a5=new File("src/img/arbre2/1x2.png");
							Image arbre5= new Image(a5.toURI().toString(),32,32,false,false);
							ImageView viewarbre5 = new ImageView();
							viewarbre5.setImage(arbre5);
							objets.getChildren().add(viewarbre5);
							viewarbre5.relocate(y*32, x*32);
						break;
						case 14 :
							File a6=new File("src/img/arbre2/2x1.png");
							Image arbre6= new Image(a6.toURI().toString(),32,32,false,false);
							ImageView viewarbre6 = new ImageView();
							viewarbre6.setImage(arbre6);
							objets.getChildren().add(viewarbre6);
							viewarbre6.relocate(y*32, x*32);
						break;
						case 15 :
							File a7=new File("src/img/arbre2/2x2.png");
							Image arbre7= new Image(a7.toURI().toString(),32,32,false,false);
							ImageView viewarbre7 = new ImageView();
							viewarbre7.setImage(arbre7);
							objets.getChildren().add(viewarbre7);
							viewarbre7.relocate(y*32, x*32);
						break;
						
						
						//maison rouge
						case 2 :
							File m=new File("src/img/maison_rouge/1x1.png");
							Image maison= new Image(m.toURI().toString(),32,32,false,false);
							ImageView viewmaison = new ImageView();
							viewmaison.setImage(maison);
							objets.getChildren().add(viewmaison);
							viewmaison.relocate(y*32, x*32);
						break;
						case 3 :
							File m2=new File("src/img/maison_rouge/1x2.png");
							Image maison2= new Image(m2.toURI().toString(),32,32,false,false);
							ImageView viewmaison2 = new ImageView();
							viewmaison2.setImage(maison2);
							objets.getChildren().add(viewmaison2);
							viewmaison2.relocate(y*32, x*32);
						break;
						case 4:
							File m3=new File("src/img/maison_rouge/2x1.png");
							Image maison3= new Image(m3.toURI().toString(),32,32,false,false);
							ImageView viewmaison3 = new ImageView();
							viewmaison3.setImage(maison3);
							objets.getChildren().add(viewmaison3);
							viewmaison3.relocate(y*32, x*32);
						break;
						case 5 :
							File m4=new File("src/img/maison_rouge/2x2.png");
							Image maison4= new Image(m4.toURI().toString(),32,32,false,false);
							ImageView viewmaison4 = new ImageView();
							viewmaison4.setImage(maison4);
							objets.getChildren().add(viewmaison4);
							viewmaison4.relocate(y*32, x*32);
						break;
						case 6 :
							File m5=new File("src/img/maison_rouge/3x1.png");
							Image maison5= new Image(m5.toURI().toString(),32,32,false,false);
							ImageView viewmaison5 = new ImageView();
							viewmaison5.setImage(maison5);
							objets.getChildren().add(viewmaison5);
							viewmaison5.relocate(y*32, x*32);
						break;
						case 7 :
							File m6=new File("src/img/maison_rouge/3x2.png");
							Image maison6= new Image(m6.toURI().toString(),32,32,false,false);
							ImageView viewmaison6 = new ImageView();
							viewmaison6.setImage(maison6);
							objets.getChildren().add(viewmaison6);
							viewmaison6.relocate(y*32, x*32);
						break;
						
						//maison jaune 1
						case 30 :
							File mm1=new File("src/maison_jaune1/1x1.png");
							Image maison_jaune1= new Image(mm1.toURI().toString(),32,32,false,false);
							ImageView viewmaison_jaune1 = new ImageView();
							viewmaison_jaune1.setImage(maison_jaune1);
							objets.getChildren().add(viewmaison_jaune1);
							viewmaison_jaune1.relocate(y*32, x*32);
						break;
						case 31 :
							File mm2=new File("src/maison_jaune1/1x2.png");
							Image maison_jaune2= new Image(mm2.toURI().toString(),32,32,false,false);
							ImageView viewmaison_jaune2 = new ImageView();
							viewmaison_jaune2.setImage(maison_jaune2);
							objets.getChildren().add(viewmaison_jaune2);
							viewmaison_jaune2.relocate(y*32, x*32);
						break;
						case 32 :
							File mm3=new File("src/maison_jaune1/2x1.png");
							Image maison_jaune3= new Image(mm3.toURI().toString(),32,32,false,false);
							ImageView viewmaison_jaune3 = new ImageView();
							viewmaison_jaune3.setImage(maison_jaune3);
							objets.getChildren().add(viewmaison_jaune3);
							viewmaison_jaune3.relocate(y*32, x*32);
						break;
						case 33:
							File mm4=new File("src/maison_jaune1/2x2.png");
							Image maison_jaune4= new Image(mm4.toURI().toString(),32,32,false,false);
							ImageView viewmaison_jaune4 = new ImageView();
							viewmaison_jaune4.setImage(maison_jaune4);
							objets.getChildren().add(viewmaison_jaune4);
							viewmaison_jaune4.relocate(y*32, x*32);
						break;
						
						
						
						
						
						//grotte
						case 40 :
							File g1=new File("src/img/grotte/mur_rocher.png");
							Image mur_rocher= new Image(g1.toURI().toString(),32,32,false,false);
							ImageView viewmur_rocher = new ImageView();
							viewmur_rocher.setImage(mur_rocher);
							objets.getChildren().add(viewmur_rocher);
							viewmur_rocher.relocate(y*32, x*32);
						break;
						case 41 :
							File g2=new File("src/img/grotte/cote_rocher.png");
							Image cote_rocher= new Image(g2.toURI().toString(),32,32,false,false);
							ImageView viewcote_rocher = new ImageView();
							viewcote_rocher.setImage(cote_rocher);
							objets.getChildren().add(viewcote_rocher);
							viewcote_rocher.relocate(y*32, x*32);
						break;
						case 42 :
							File g3=new File("src/img/grotte/fi_rocher.png");
							Image fi_rocher= new Image(g3.toURI().toString(),32,32,false,false);
							ImageView viewfi_rocher = new ImageView();
							viewfi_rocher.setImage(fi_rocher);
							objets.getChildren().add(viewfi_rocher);
							viewfi_rocher.relocate(y*32, x*32);
						break;
						case 43 :
							File g4=new File("src/img/grotte/haut_rocher.png");
							Image haut_rocher= new Image(g4.toURI().toString(),32,32,false,false);
							ImageView viewhaut_rocher = new ImageView();
							viewhaut_rocher.setImage(haut_rocher);
							objets.getChildren().add(viewhaut_rocher);
							viewhaut_rocher.relocate(y*32, x*32);
						break;
						case 44 :
							File g5=new File("src/img/grotte/bordure_rocher_bd.png");
							Image bordure_rocher_bd= new Image(g5.toURI().toString(),32,32,false,false);
							ImageView viewbordure_rocher_bd = new ImageView();
							viewbordure_rocher_bd.setImage(bordure_rocher_bd);
							objets.getChildren().add(viewbordure_rocher_bd);
							viewbordure_rocher_bd.relocate(y*32, x*32);
						break;
						case 45 :
							File g6=new File("src/img/grotte/bordure_rocher_bg.png");
							Image bordure_rocher_bg= new Image(g6.toURI().toString(),32,32,false,false);
							ImageView viewbordure_rocher_bg = new ImageView();
							viewbordure_rocher_bg.setImage(bordure_rocher_bg);
							objets.getChildren().add(viewbordure_rocher_bg);
							viewbordure_rocher_bg.relocate(y*32, x*32);
						break;
						case 46 :
							File g7=new File("src/img/grotte/bordure_rocher_hd.png");
							Image bordure_rocher_hd= new Image(g7.toURI().toString(),32,32,false,false);
							ImageView viewbordure_rocher_hd = new ImageView();
							viewbordure_rocher_hd.setImage(bordure_rocher_hd);
							objets.getChildren().add(viewbordure_rocher_hd);
							viewbordure_rocher_hd.relocate(y*32, x*32);
						break;
						case 47 :
							File g8=new File("src/img/grotte/bordure_rocher_hg.png");
							Image bordure_rocher_hg= new Image(g8.toURI().toString(),32,32,false,false);
							ImageView viewbordure_rocher_hg = new ImageView();
							viewbordure_rocher_hg.setImage(bordure_rocher_hg);
							objets.getChildren().add(viewbordure_rocher_hg);
							viewbordure_rocher_hg.relocate(y*32, x*32);
						break;
						case 48 :
							File g9=new File("src/img/grotte/cote_rocher2.png");
							Image cote_rocher2 = new Image(g9.toURI().toString(),32,32,false,false);
							ImageView viewcote_rocher2 = new ImageView();
							viewcote_rocher2.setImage(cote_rocher2);
							objets.getChildren().add(viewcote_rocher2);
							viewcote_rocher2.relocate(y*32, x*32);
						break;
						case 49 :
							File g10=new File("src/img/grotte/entree_grotte.png");
							Image entree_grotte = new Image(g10.toURI().toString(),32,32,false,false);
							ImageView viewentree_grotte = new ImageView();
							viewentree_grotte.setImage(entree_grotte);
							objets.getChildren().add(viewentree_grotte);
							viewentree_grotte.relocate(y*32, x*32);
						break;
						
						//eau riviere
						case 21:
							File e1=new File("src/img/coin_eau_hg.png");
							Image coin_eau_hg = new Image(e1.toURI().toString(),32,32,false,false);
							ImageView viewcoin_eau_hg = new ImageView();
							viewcoin_eau_hg.setImage(coin_eau_hg);
							objets.getChildren().add(viewcoin_eau_hg);
							viewcoin_eau_hg.relocate(y*32, x*32);
						break;
						case 22:
							File e2=new File("src/img/coin_eau_bg.png");
							Image coin_eau_bg = new Image(e2.toURI().toString(),32,32,false,false);
							ImageView viewcoin_eau_bg = new ImageView();
							viewcoin_eau_bg.setImage(coin_eau_bg);
							objets.getChildren().add(viewcoin_eau_bg);
							viewcoin_eau_bg.relocate(y*32, x*32);
						break;
						case 23:
							File e3=new File("src/img/bordure_eau.png");
							Image bordure_eau= new Image(e3.toURI().toString(),32,32,false,false);
							ImageView viewbordure_eau = new ImageView();
							viewbordure_eau.setImage(bordure_eau);
							objets.getChildren().add(viewbordure_eau);
							viewbordure_eau.relocate(y*32, x*32);
						break;
						case 24:
							File e4=new File("src/img/bordure_eau2.png");
							Image bordure_eau2 = new Image(e4.toURI().toString(),32,32,false,false);
							ImageView viewbordure_eau2 = new ImageView();
							viewbordure_eau2.setImage(bordure_eau2);
							objets.getChildren().add(viewbordure_eau2);
							viewbordure_eau2.relocate(y*32, x*32);
						break;
						
						
						}
						
					}
				}
				
		
		
	
		
		objets.getChildren().add(viewperso);
 		viewperso.translateXProperty().bind(env.getLink().getDeplacement().getPosX());
		viewperso.translateYProperty().bind(env.getLink().getDeplacement().getPosY());
		viewperso.setImage(pers_face);
		
		
		//deplacement et affichage monstres
		
		
		viewmonstre.setImage(pers_face);
		objets.getChildren().add(viewmonstre);
		
		viewmonstre.translateXProperty().bind(env.getListePers().get(1).getDeplacement().getPosX());
		viewmonstre.translateYProperty().bind(env.getListePers().get(1).getDeplacement().getPosY());
		
		
		Case[][] plateau= new Case[5][10];
		Case caseD= new Case(80,100);
		Case caseF= new Case(10,10);
		bfs = new BFS(plateau,caseD,caseF,env.getMap2(),env.getListePers(),env.getListeObjetsPoussables());

		viewmonstre2.setImage(pers_face);
		objets.getChildren().add(viewmonstre2);
		viewmonstre2.translateXProperty().bind(env.getListePers().get(2).getDeplacement().getPosX());
		viewmonstre2.translateYProperty().bind(env.getListePers().get(2).getDeplacement().getPosY());
		
		//Test deplacement boite
		File g9=new File("src/img/grotte/cote_rocher2.png");
		Image cote_rocher2 = new Image(g9.toURI().toString(),32,32,false,false);
		vueboite.setImage(cote_rocher2);
		objets.getChildren().add(vueboite);
		vueboite2.setImage(cote_rocher2);
		objets.getChildren().add(vueboite2);
		
		
		vueboite.translateXProperty().bind(env.getListeObjetsPoussables().get(0).getCase().getXProperty());
		vueboite.translateYProperty().bind(env.getListeObjetsPoussables().get(0).getCase().getYProperty());
		vueboite2.translateXProperty().bind(env.getListeObjetsPoussables().get(1).getCase().getXProperty());
		vueboite2.translateYProperty().bind(env.getListeObjetsPoussables().get(1).getCase().getYProperty());
		
		
		objets.getChildren().add(viewfleche);
		
		
		
		initAnimation();
		gameLoop.play();
		
		
		//inventaire
				invent.getChildren().add(vueinv);
				invent.getChildren().add(vuepotion);
				env.getLink().ajouterObjet(env.getListeObj().get(0));
				
				invent.setVisible(false);
				
				//affichage dans l'inventaire des objets
				for(int i=0; i<env.getLink().getListeObj().size(); i++) {
					vuepotion.relocate(env.getLink().getListeObj().get(i).getCase().getX(), env.getLink().getListeObj().get(i).getCase().getY());
				
				}
				
				
				
		
		//afichage vie
		vie = new Case(0,0);
		menu.getChildren().add(viewcoeur);
		menu.translateXProperty().bind(vie.getXProperty());
		menu.translateYProperty().bind(vie.getYProperty());
		vie_link=env.getLink().getPDV();
			        
		
			        env.getLink().getPV().addListener(new ChangeListener<Number>() {

			            @Override
			            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
			                if(env.getLink().getPDV()<vie_link && env.getLink().getPDV()>0) {
			                	vie.setX(vie.getX()-32);
			        
			                }
			                else if(env.getLink().getPDV()>=vie_link && vie.getX()<0) {
			                		vie.setX(vie.getX()+32);
			                	
			                }
			            	vie_link=env.getLink().getPDV();
			                
			            }
			            
			        });

		
		// pour pouvoir changer l'image du personnage, mouvement 
		mvt.addListener(new ChangeListener<Number>() {

			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				
				switch(env.getLink().getDeplacement().getOrientation().get()) {
					case 0:
						viewperso.setImage(pers_dos);
						env.getLink().getDeplacement().incrementerCompteurPas();
						if(env.getLink().getDeplacement().getCompteurPas()%6==0 || env.getLink().getDeplacement().getCompteurPas()%6==1 || env.getLink().getDeplacement().getCompteurPas()%6==2){
	                		viewperso.setImage(pers_face_marche1);
	                	}
	                	else{
	                		viewperso.setImage(pers_face_marche2);
	                	}
		
						
					break;
					case 1:
						viewperso.setImage(pers_face);
						env.getLink().getDeplacement().incrementerCompteurPas();
						if(env.getLink().getDeplacement().getCompteurPas()%6==0 || env.getLink().getDeplacement().getCompteurPas()%6==1|| env.getLink().getDeplacement().getCompteurPas()%6==2){
	                		viewperso.setImage(pers_dos_marche1);
	                	}
	                	else{
	                		viewperso.setImage(pers_dos_marche2);
	                	}
					break;
					case 2 :
						viewperso.setImage(pers_droite);
						env.getLink().getDeplacement().incrementerCompteurPas();
	                     if(env.getLink().getDeplacement().getCompteurPas()%6==0 || env.getLink().getDeplacement().getCompteurPas()%6==1|| env.getLink().getDeplacement().getCompteurPas()%6==2){
	                 		viewperso.setImage(pers_droite_marche1);
	                 	}
	                 	else{
	                 		viewperso.setImage(pers_droite_marche2);
	                 	}
	                  break;
					case 3:
						viewperso.setImage(pers_gauche);
						env.getLink().getDeplacement().incrementerCompteurPas();
						if(env.getLink().getDeplacement().getCompteurPas()%6==0 || env.getLink().getDeplacement().getCompteurPas()%6==1 || env.getLink().getDeplacement().getCompteurPas()%6==2){
		            		viewperso.setImage(pers_gauche_marche1);
		            	}
		            	else{
		            		viewperso.setImage(pers_gauche_marche2);
		            	}
	            
	                 break;
						
				}
			}
			
		}
				);
		//viewperso.translateXProperty().addListener();
		
	}
	
    public void deplacement(KeyEvent key) {
		KeyCode codeDeLaTouche = key.getCode();
		
		if(!invent.isVisible()) {
		switch (codeDeLaTouche) 
        {
		
			
            case UP:
            	monterOK=true;
                break;
            case LEFT:
            	gaucheOK=true;
                break;
            case RIGHT:
            	droiteOK=true;
                break;
            case DOWN:
            	descendreOK=true;
                break;
            case I:
        		invent.setVisible(true);
        		break;
           case SPACE:
        	   if(env.getLink().getArme().getNom().equals("epee")) {
	            	if(env.getLink().getDeplacement().getDetecteurPerso().testCollisionBas(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx())!=-1 && this.attaquePossible==false){
	            		this.attaquePossible=true;
	            		indicePerso=env.getLink().getDeplacement().getDetecteurPerso().testCollisionBas(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx());
	            	}
	            	else if(env.getLink().getDeplacement().getDetecteurPerso().testCollisionHaut(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx())!=-1 && this.attaquePossible==false){
	            		this.attaquePossible=true;
	            		indicePerso=env.getLink().getDeplacement().getDetecteurPerso().testCollisionHaut(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx());
	            	}
	            	else if(env.getLink().getDeplacement().getDetecteurPerso().testCollisionDroit(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx())!=-1 && this.attaquePossible==false){
	            		this.attaquePossible=true;
	            		indicePerso=env.getLink().getDeplacement().getDetecteurPerso().testCollisionDroit(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx());
	            	}
	            	else if(env.getLink().getDeplacement().getDetecteurPerso().testCollisionGauche(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx())!=-1 && this.attaquePossible==false){
	            		this.attaquePossible=true;
	            		indicePerso=env.getLink().getDeplacement().getDetecteurPerso().testCollisionGauche(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosx());
	            	}
	            	else{
	            		this.attaquePossible=false;
	            	}
        	   }
            	
            	//Attaque arc
            	if(env.getLink().getArme().getNom().equals("arc")) {
            		System.out.println("arc");
            		if(this.attaqueArcPossible==false) {
            			this.attaqueArcPossible=true;
            			viewfleche.relocate(env.getLink().getDeplacement().getPosx(), env.getLink().getDeplacement().getPosy());
            			fleche = new Fleche(env.getLink().getDeplacement().getPosx(), env.getLink().getDeplacement().getPosy(),env.getLink().getArme(),env.getLink().getDeplacement().getOrientation().get(),env.getListePers());
            			if(env.getLink().getDeplacement().getOrientation().get()==0) {//descendre
            				viewfleche.setImage(imgflechebas);
            			}
            			if(env.getLink().getDeplacement().getOrientation().get()==1) {//monter
            				viewfleche.setImage(imgflechehaut);
            			}
            			if(env.getLink().getDeplacement().getOrientation().get()==2) {//droite
            				viewfleche.setImage(imgflechedroit);
            			}
            			if(env.getLink().getDeplacement().getOrientation().get()==3) {//gauche
            				viewfleche.setImage(imgflechegauche);
            			}
            		}
            		
            	}
            	//event.add(new Evenement("Attaque de link",2,0));
            	break;
            case ENTER :
            	//link.ajouterObjet(obj);
            	break;
            case G:
            	
            	env.getObjetsPoussables().setLink(env.getLink());
            	if((env.getLink().getDeplacement().getDetecteurObjetsPoussables().testCollisionBas(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosy())!=-1 || env.getLink().getDeplacement().getDetecteurObjetsPoussables().testCollisionHaut(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosy())!=-1|| env.getLink().getDeplacement().getDetecteurObjetsPoussables().testCollisionDroit(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosy())!=-1|| env.getLink().getDeplacement().getDetecteurObjetsPoussables().testCollisionGauche(env.getLink().getDeplacement().getPosy(), env.getLink().getDeplacement().getPosy())!=-1) && this.attraperObjetPoussable==false){
            		this.attraperObjetPoussable=true;
            	}
            	else if(this.attraperObjetPoussable==true){
            		this.attraperObjetPoussable=false;
            	}
            	break;
            case S:
            	if(env.getLink().getArme().getNom().equals("arc")) {
            		System.out.println("jai un arc");
            		env.getLink().setArme(new Epee());
            	}
            	else {
            		System.out.println("jai une épéé");
            		env.getLink().setArme(new Arc());
            	}
        }
		}
		else {
			switch(codeDeLaTouche) {
			
			//affichage de linventaire
            case I:
            	//setvisiblefalse -> rendre invisible le pane 
            	//creer un pane et lenlever a la pression de la touche remove
            	//pane new pane 
            	if (invent.isVisible()) {
            		invent.setVisible(false);
            	}
            	else {
            		invent.setVisible(true);
            	}
            	
            	
            	break;
			}
		}
		
    }
    
    private void initAnimation() {
    	gameLoop = new Timeline();
    	temps=0;
    	gameLoop.setCycleCount(Timeline.INDEFINITE);
    	KeyFrame kf = new KeyFrame(
				Duration.seconds(0.01),(ev ->{
					if(env.getLink().getPDV()==0) {
						System.out.println("WASTED");
						gameLoop.stop();
					}
					else {
						if(env.getMonstre1().getPDV()<=0){
							env.getMonstre1().setDeplacement(null);
							env.supprimerMonstreListe(env.getMonstre1());
							viewmonstre.setImage(null);
						}
						if(env.getMonstre2().getPDV()<=0){
							env.getMonstre2().setDeplacement(null);
							env.supprimerMonstreListe(env.getMonstre2());
							viewmonstre2.setImage(null);
							
						}
						if(temps%5==0){
							if(env.getMonstre1().getDeplacement()!=null) {
								env.getMonstre1().getDeplacement().agir();
								if(env.getMonstre1().getDeplacement().getDetecteurPerso().testCollisionBas(env.getMonstre1().getDeplacement().getPosy(), env.getMonstre1().getDeplacement().getPosx())==0){
									env.getMonstre1().attaque(env.getLink());
								}
								if(env.getMonstre1().getDeplacement().getDetecteurPerso().testCollisionHaut(env.getMonstre1().getDeplacement().getPosy(), env.getMonstre1().getDeplacement().getPosx())==0){
									env.getMonstre1().attaque(env.getLink());
								}
								if(env.getMonstre1().getDeplacement().getDetecteurPerso().testCollisionDroit(env.getMonstre1().getDeplacement().getPosy(), env.getMonstre1().getDeplacement().getPosx())==0){
									env.getMonstre1().attaque(env.getLink());
								}
								if(env.getMonstre1().getDeplacement().getDetecteurPerso().testCollisionGauche(env.getMonstre1().getDeplacement().getPosy(), env.getMonstre1().getDeplacement().getPosx())==0){
									env.getMonstre1().attaque(env.getLink());
								}
							}
							if(env.getMonstre2().getDeplacement()!=null) {
								env.getMonstre2().getDeplacement().agir();
								if(env.getMonstre2().getDeplacement().getDetecteurPerso().testCollisionBas(env.getMonstre2().getDeplacement().getPosy(), env.getMonstre2().getDeplacement().getPosx())==0){
									env.getMonstre2().attaque(env.getLink());
								}
								if(env.getMonstre2().getDeplacement().getDetecteurPerso().testCollisionHaut(env.getMonstre2().getDeplacement().getPosy(), env.getMonstre2().getDeplacement().getPosx())==0){
									env.getMonstre2().attaque(env.getLink());
								}
								if(env.getMonstre2().getDeplacement().getDetecteurPerso().testCollisionDroit(env.getMonstre2().getDeplacement().getPosy(), env.getMonstre2().getDeplacement().getPosx())==0){
									env.getMonstre2().attaque(env.getLink());
								}
								if(env.getMonstre2().getDeplacement().getDetecteurPerso().testCollisionGauche(env.getMonstre2().getDeplacement().getPosy(), env.getMonstre2().getDeplacement().getPosx())==0){
									env.getMonstre2().attaque(env.getLink());
								}
							}
						}
						if(temps%3==0 && monterOK==true){
							if(env.getLink().getDeplacement().monter()==true) {
			            		env.getScroll().setPosYFenetre();
			            		scrolling.relocate(-env.getScroll().getPosXFenetre(), -env.getScroll().getPosYFenetre());
			            		mvt.set(mvt.get()+1);
			        		}
						}
						if(temps%3==0 && descendreOK==true){
							if(env.getLink().getDeplacement().descendre()==true) {
			            		env.getScroll().setPosYFenetre();
			            		scrolling.relocate(-env.getScroll().getPosXFenetre(), -env.getScroll().getPosYFenetre());
			            		mvt.set(mvt.get()+1);
			        		}
						}
						if(temps%3==0 && droiteOK==true){
								if(env.getLink().getDeplacement().droite()==true) {
			            		env.getScroll().setPosXFenetre();
			            		scrolling.relocate(-env.getScroll().getPosXFenetre(), -env.getScroll().getPosYFenetre());
			            		mvt.set(mvt.get()+1);
			            	}
			            }
						if(temps%3==0 && gaucheOK==true){
							if(env.getLink().getDeplacement().gauche()==true) {
			            		env.getScroll().setPosXFenetre();
			            		scrolling.relocate(-env.getScroll().getPosXFenetre(), -env.getScroll().getPosYFenetre());
			            		mvt.set(mvt.get()+1); 
			        		}
						}
						if(temps%3==0 && this.attraperObjetPoussable==true){
							env.getLink().attraperObjetPoussable(indiceObjet);
						}
						if(temps%2==0 && this.attaquePossible==true) {
							viewperso.setImage(null);
						}
						if(temps%2==1 && this.attaquePossible==true) {
							viewperso.setImage(pers_face);
						}
						if(temps%4==0 && this.attaquePossible==true) {
							env.getLink().attaque(env.getListePers().get(indicePerso));
						}
						if(this.attaqueArcPossible==true && fleche.getPortee()>0) {
            				fleche.agir();
            				viewfleche.relocate(fleche.getX(), fleche.getY());
            				if(fleche.getPortee()<=0) {
            					this.attaqueArcPossible=false;
            					viewfleche.setImage(null);
            				}
            			}
						//Potion invincibilité mdr
						/*if(temps%2==0) {
							viewperso.setImage(null);
						}
						if(temps%2==1) {
							viewperso.setImage(pers_face);
						}*/
					}
					temps++;
				})
				);
    	gameLoop.getKeyFrames().add(kf);
    }
    
  //quand le personage ne bouge plus 
  	public void touheRelache(KeyEvent event) {
  		switch(env.getLink().getDeplacement().getOrientation().get()) {
  		case 0:
  			viewperso.setImage(pers_face);
  			break;
  		case 1:
  			viewperso.setImage(pers_dos);
  			break;
  		case 2:
  			viewperso.setImage(pers_droite);
  		break;
  		case 3 :
  			viewperso.setImage(pers_gauche);
  			break;	
  		}
  		
  		KeyCode codeDeLaTouche2 = event.getCode();
		
		switch (codeDeLaTouche2) {
		case UP:
			monterOK=false;
			break;
		case DOWN:
			descendreOK=false;
			break;
		case RIGHT:
			droiteOK=false;
			break;
		case LEFT:
			gaucheOK=false;
			break;
		case SPACE:
			attaquePossible=false;
		}
  	}
}
