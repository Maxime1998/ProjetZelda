package controleur;

import java.util.ArrayList;

import modele.ObjetsPoussables;

public class DetecteurCollisionObjetsPoussables {
	
	private ArrayList<ObjetsPoussables> listeObjetsPoussables;
	private boolean collision;

	public DetecteurCollisionObjetsPoussables(ArrayList<ObjetsPoussables> liste) {
		this.listeObjetsPoussables=liste;
		this.collision=false;
	}
	
	public ArrayList<ObjetsPoussables> getListe(){
		return this.listeObjetsPoussables;
	}
	
	public int testCollisionBas(int posY, int posX) {
		int i=0;
		collision=false;
		while(i<listeObjetsPoussables.size() && collision==false){
			if((posX>=listeObjetsPoussables.get(i).getCase().getX() && posX<=listeObjetsPoussables.get(i).getCase().getX()+32) || (posX+32>=listeObjetsPoussables.get(i).getCase().getX() && posX+32<=listeObjetsPoussables.get(i).getCase().getX()+32)) {
				if(posY+32>=listeObjetsPoussables.get(i).getCase().getY() && posY+32<=listeObjetsPoussables.get(i).getCase().getY()+32) {
					collision=true;
					return i;
				}
			}
			i++;
			
		}
		return -1;
	}
	
	public int testCollisionHaut(int posY, int posX) {
		int i=0;
		collision=false;
		while(i<listeObjetsPoussables.size() && collision==false){
			if((posX>=listeObjetsPoussables.get(i).getCase().getX() && posX<=listeObjetsPoussables.get(i).getCase().getX()+32) || (posX+32>=listeObjetsPoussables.get(i).getCase().getX() && posX+32<=listeObjetsPoussables.get(i).getCase().getX()+32)) {
				if(posY<=listeObjetsPoussables.get(i).getCase().getY()+32 && posY>=listeObjetsPoussables.get(i).getCase().getY()) {
					collision=true;
					return i;
				}
			}
			i++;
		}
		return -1;
	}
	
	public int testCollisionGauche(int posY, int posX) {
		int i=0;
		collision=false;
		while(i<listeObjetsPoussables.size() && collision==false){
			if((posY>=listeObjetsPoussables.get(i).getCase().getY() && posY<=listeObjetsPoussables.get(i).getCase().getY()+32) || (posY+32>=listeObjetsPoussables.get(i).getCase().getY() && posY+32<=listeObjetsPoussables.get(i).getCase().getY()+32)) {
				if(posX<=listeObjetsPoussables.get(i).getCase().getX()+32 && posX>=listeObjetsPoussables.get(i).getCase().getX()) {
					collision=true;
					return i;
				}
			}
			i++;
		}
		return -1;
	}
	
	public int testCollisionDroit(int posY, int posX) {
		int i=0;
		collision=false;
		while(i<listeObjetsPoussables.size() && collision==false){
			if((posY>=listeObjetsPoussables.get(i).getCase().getY() && posY<=listeObjetsPoussables.get(i).getCase().getY()+32) || (posY+32>=listeObjetsPoussables.get(i).getCase().getY() && posY+32<=listeObjetsPoussables.get(i).getCase().getY()+32)) {
				if(posX+32>=listeObjetsPoussables.get(i).getCase().getX() && posX+32<=listeObjetsPoussables.get(i).getCase().getX()+32) {
					collision=true;
					return i;
				}
			}
			i++;
		}
		return -1;
	}
}
