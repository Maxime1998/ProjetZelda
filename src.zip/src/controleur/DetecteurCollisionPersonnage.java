package controleur;

import java.util.ArrayList;

public class DetecteurCollisionPersonnage {

	private boolean collision;
	private ArrayList<Case> listePos;
	
	public DetecteurCollisionPersonnage(ArrayList<Case> liste){
		this.collision=false;
		this.listePos=liste;
	}
	
	public boolean testCollisionHaut(int posX, int posY) {
		int i=0;
	
		while(i<listePos.size() && collision==false){
			if((posX+32>=listePos.get(i).getX() && posX<=listePos.get(i).getX()+32) && (posY<=listePos.get(i).getY()+32 && posY>=listePos.get(i).getY())) {
				collision=true;
			}
			
		}
		return collision;
	}
	
	public boolean testCollisionBas(int posX, int posY) {
		int i=0;
		while(i<listePos.size() && collision==false){
			if((posX>=listePos.get(i).getX() && posX+32<=listePos.get(i).getX()+32) && ( posY+32>=listePos.get(i).getY() && posY>=listePos.get(i).getY()+32)) {
				collision=true;
				
			}
		}
		return collision;
	}
	
	public boolean testCollisionDroit(int posX, int posY) {
		int i=0;
		while(i<listePos.size() && collision==false){
			if((posX+32>=listePos.get(i).getX() && posX+32<=listePos.get(i).getX()) && (posY<=listePos.get(i).getY() && posY+32<=listePos.get(i).getY()+32)) {
				collision=true;
			}
			
		}
		return collision;
	}
	
	public boolean testCollisionGauche(int posX, int posY) {
		int i=0;
		while(i<listePos.size() && collision==false){
			if((posX<=listePos.get(i).getX()+32 && posX+32<=listePos.get(i).getX() ) || (posY>=listePos.get(i).getY() && posY+32<=listePos.get(i).getY()+32)){
				collision=true;
			}
			
		}
		return collision;
	}
}
