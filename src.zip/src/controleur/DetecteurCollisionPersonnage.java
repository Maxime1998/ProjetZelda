package controleur;

import java.util.ArrayList;

import modele.Personnage;

public class DetecteurCollisionPersonnage {

	private boolean collision;
	private ArrayList<Personnage> listePos;
	
	public DetecteurCollisionPersonnage(ArrayList<Personnage> liste){
		this.collision=false;
		this.listePos=liste;
	}

public void setListe(ArrayList<Personnage> c) {
        this.listePos=c;
    }
	
	public int testCollisionBas(int posY, int posX) {
		int i=0;
		collision=false;
		while(i<listePos.size() && collision==false){
			if(posX==listePos.get(i).getDeplacement().getPosx() && posY==listePos.get(i).getDeplacement().getPosy()){
			}
			else if((posX>=listePos.get(i).getDeplacement().getPosx() && posX<=listePos.get(i).getDeplacement().getPosx()+32) || (posX+32>=listePos.get(i).getDeplacement().getPosx() && posX+32<=listePos.get(i).getDeplacement().getPosx()+32)) {
				if(posY+32>=listePos.get(i).getDeplacement().getPosy() && posY+32<=listePos.get(i).getDeplacement().getPosy()+32) {
					return i;
				}
			}
			i++;
			
		}
		return -1;
	}
	
	public int testCollisionHaut(int posY, int posX) {
		int i=0;
		collision=false;
		while(i<listePos.size() && collision==false){
			if(posX==listePos.get(i).getDeplacement().getPosx() && posY==listePos.get(i).getDeplacement().getPosy()){
			}
			else if((posX>=listePos.get(i).getDeplacement().getPosx() && posX<=listePos.get(i).getDeplacement().getPosx()+32) || (posX+32>=listePos.get(i).getDeplacement().getPosx() && posX+32<=listePos.get(i).getDeplacement().getPosx()+32)) {
				if(posY<=listePos.get(i).getDeplacement().getPosy()+32 && posY>=listePos.get(i).getDeplacement().getPosy()) {
					return i;
				}
			}
			i++;
		}
		return -1;
	}
	
	public int testCollisionGauche(int posY, int posX) {
		int i=0;
		collision=false;
		while(i<listePos.size() && collision==false){
			if(posX==listePos.get(i).getDeplacement().getPosx() && posY==listePos.get(i).getDeplacement().getPosy()){
			}
			else if((posY>=listePos.get(i).getDeplacement().getPosy() && posY<=listePos.get(i).getDeplacement().getPosy()+32) || (posY+32>=listePos.get(i).getDeplacement().getPosy() && posY+32<=listePos.get(i).getDeplacement().getPosy()+32)) {
				if(posX<=listePos.get(i).getDeplacement().getPosx()+32 && posX>=listePos.get(i).getDeplacement().getPosx()) {
					return i;
				}
			}
			i++;
		}
		return -1;
	}
	
	public int testCollisionDroit(int posY, int posX) {
		int i=0;
		collision=false;
		while(i<listePos.size() && collision==false){
			if(posX==listePos.get(i).getDeplacement().getPosx() && posY==listePos.get(i).getDeplacement().getPosy()){
			}
			else if((posY>=listePos.get(i).getDeplacement().getPosy() && posY<=listePos.get(i).getDeplacement().getPosy()+32) || (posY+32>=listePos.get(i).getDeplacement().getPosy() && posY+32<=listePos.get(i).getDeplacement().getPosy()+32)) {
				if(posX+32>=listePos.get(i).getDeplacement().getPosx() && posX+32<=listePos.get(i).getDeplacement().getPosx()+32) {
					return i;
				}
			}
			i++;
		}
		return -1;
	}
}