package controleur;

import java.util.ArrayList;

import modele.Objets;

public class DetecteurRamasserObjet {

	private ArrayList<Objets> listeObj;
	private boolean colisision;
	
	public DetecteurRamasserObjet(ArrayList<Objets> o) {
		this.listeObj=o;
		this.colisision=false;
	}
	
	public void setListe(ArrayList<Objets> o) {
		this.listeObj=o;
	}
	
	public Objets testCollisionBas(int posY, int posX){
		for(int i=0; i<listeObj.size(); i++){
			if((posX>=listeObj.get(i).getCase().getX() && posX<=listeObj.get(i).getCase().getX() +20) || (posX+20>=listeObj.get(i).getCase().getX()  && posX+20<=listeObj.get(i).getCase().getX()+20)) {
                if(posY+20>=listeObj.get(i).getCase().getY()  && posY+20<=listeObj.get(i).getCase().getY() +20) {
                	System.out.println(listeObj.get(i));
                	return listeObj.get(i);
                }
			}    
		}
		return null;
	}
	
	public Objets testCollisionHaut(int posY, int posX) {
		for(int i=0; i<listeObj.size(); i++){
			if((posX>=listeObj.get(i).getCase().getX() && posX<=listeObj.get(i).getCase().getX()+20) || (posX+20>=listeObj.get(i).getCase().getX() && posX+20<=listeObj.get(i).getCase().getX()+20)) {
                if(posY<=listeObj.get(i).getCase().getY()+20 && posY>=listeObj.get(i).getCase().getY()) {
                	System.out.println(listeObj.get(i));
                	return listeObj.get(i);
                }
			}    
		}
		return null;
	}
	
	public Objets testCollisionGauche(int posY, int posX) {
		for(int i=0; i<listeObj.size(); i++){
			if((posY>=listeObj.get(i).getCase().getY() && posY<=listeObj.get(i).getCase().getY()+20) || (posY+20>=listeObj.get(i).getCase().getY() && posY+20<=listeObj.get(i).getCase().getY()+20)) {
                if(posX<=listeObj.get(i).getCase().getX()+20 && posX>=listeObj.get(i).getCase().getX()) {
                  System.out.println(listeObj.get(i));
                	return listeObj.get(i);
                }
			}    
		}
		return null;
	}
	
	public Objets testCollisionDroite(int posY, int posX) {
		for(int i=0; i<listeObj.size(); i++){
			if((posY>=listeObj.get(i).getCase().getY() && posY<=listeObj.get(i).getCase().getY()+20) || (posY+20>=listeObj.get(i).getCase().getY() && posY+20<=listeObj.get(i).getCase().getY()+20)) {
				if(posX+20>=listeObj.get(i).getCase().getX() && posX+20<=listeObj.get(i).getCase().getX()+20) {
					System.out.println(listeObj.get(i));
					return listeObj.get(i);
				}
			}    
		}
		return null;
	}
}
