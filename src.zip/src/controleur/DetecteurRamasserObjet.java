package controleur;

import java.util.ArrayList;

import modele.Objets;

public class DetecteurRamasserObjet {

	private ArrayList<Objets> listeObj;
	private boolean colisision;
	
	public DetecteurRamasserObjet(ArrayList<Objets> o) {
		this.listeObj=o;
		this.colisision=false;
	}
	
	public void setListe(ArrayList<Objets> o) {
		this.listeObj=o;
	}
	
	public Object testCollisionBas(int posY, int posX){
		for(int i=0; i<listeObj.size(); i++){
			if((//listeObj.get(i).getCase().getX()<=posX && listeObj.get(i).getCase().getY()>=posY+32) || ){
				return listeObj.get(i);
			}
		}
		return null;
	}

}
