package controleur;

public class Evenement {

	private String nom;
	private int nbFrame;
	private int frameActuelle;
	private boolean bloqueAutresActions;
	
	public Evenement(String n,int nb, int f){
		this.nom=n;
		this.nbFrame=nb;
		this.frameActuelle=f;
		this.bloqueAutresActions=false;
	}
	
	public String getNom(){
		return this.nom;
	}
	
	public boolean getBloqueAction(){
		return this.bloqueAutresActions;
	}
	
	public void setBloqueAction(boolean b){
		this.bloqueAutresActions=b;
	}
	
	public int getNbFrame(){
		return this.nbFrame;
	}
	
	public int getFrameActuelle(){
		return this.frameActuelle;
	}
	
	public void setframeActuelle(int f){
		this.frameActuelle=f;
	}
}
