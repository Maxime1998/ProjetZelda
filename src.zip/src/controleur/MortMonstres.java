package controleur;

import java.util.ArrayList;

import javafx.scene.image.ImageView;
import modele.Environnement;

public class MortMonstres {

	private Environnement env;
	
	public MortMonstres(Environnement e) {
		this.env=e;
	}
	
	public void setEnvironnement(Environnement ee) {
		this.env=ee;
	}
	
	public int monstreMort(int i,ArrayList<ImageView> listeView) {
		if(env.getListePers().get(i+2).getPDV()<=0) {
			env.getListePers().get(i+2).getDeplacement().setPosX(0);
			env.getListePers().get(i+2).getDeplacement().setPosY(0);
			listeView.get(i).setImage(null);
			return i;
		}
		return -1;
	}
}