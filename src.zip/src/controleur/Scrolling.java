package controleur;
import modele.Link;
import modele.Personnage;

public class Scrolling {

	private int posXFenetre,posYFenetre;
	//private int posXLink,posYLink;
	private Link link;
	
	public Scrolling(Link l) {
		/*this.posXLink=xlink;
		this.posYLink=ylink;*/
		this.posXFenetre=0;
		this.posYFenetre=0;
		this.link=l;
	}
	
	public void setPosXFenetre() {
		this.posXFenetre=link.getPosx()-150;
	}
	
	public void setPosYFenetre() {
		this.posYFenetre=link.getPosy()-150;
	}
	
	public int getPosXFenetre() {
		return this.posXFenetre;
	}
	
	public int getPosYFenetre() {
		return this.posYFenetre;
	}
	/*public int PosXInterieur() {
		
	}
	
	public int PosYInterieur() {
		
	}*/

}
