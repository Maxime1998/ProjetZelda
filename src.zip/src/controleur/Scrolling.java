package controleur;
import modele.Link;
import modele.Personnage;

public class Scrolling {

	private int posXFenetre,posYFenetre;
	private Link link;
	
	public Scrolling(Link l) {
		this.posXFenetre=0;
		this.posYFenetre=0;
		this.link=l;
	}
	
	public void setPosXFenetre() {
		this.posXFenetre=link.getDeplacement().getPosx()-280;
		if(posXFenetre<0) {
			posXFenetre=0;
		}
		if(posXFenetre>680) {
			posXFenetre=680;
		}
	}
	
	public void setPosYFenetre() {
		this.posYFenetre=link.getDeplacement().getPosy()-280;
		if(posYFenetre<0) {
			posYFenetre=0;
		}
		if(posYFenetre>1320) {
			posYFenetre=1320;
		}
	}
	
	public int getPosXFenetre() {
		return this.posXFenetre;
	}
	
	public int getPosYFenetre() {
		return this.posYFenetre;
	}

}
