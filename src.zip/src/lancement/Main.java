package lancement;


import java.io.File;
import java.io.IOException;

import controleur.Map;
import javafx.application.Application;

import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
//import javafx.scene.layout.GridPane;
import javafx.scene.layout.TilePane;
import javafx.stage.Stage;

public class Main extends Application{
	

	
	
	public static void main(String[] args) throws IOException {
		launch(args);
		
	}


	@Override
	public void start(Stage primaryStage) throws Exception {
		Map mapLogique = new Map("src/map.txt");//dans modele
		mapLogique.initMapLogique();
		int[][] map = mapLogique.getMapLogique();
		
		/*deuxieme couche*/
		Map map2ecouche = new Map("src/map2.txt");
		map2ecouche.initMapLogique();
		int[][] map2 = map2ecouche.getMapLogique();
		
		
		AnchorPane panel = new AnchorPane(); //doit etre un pane -> creation fxml
		//mzin launch
		Scene scene = new Scene(panel,160,320);
		primaryStage.setScene(scene);
		primaryStage.show();
		
		//link
		Pane personnage = new Pane();
		File image=new File("src/img/link.png");
		Image perso = new Image(image.toURI().toString(),32,32,false,false);
		ImageView viewperso = new ImageView();
		viewperso.setImage(perso);
		personnage.getChildren().add(viewperso);
		viewperso.relocate(60, 50);	
		 
		//parcourir le tableau
		Pane baseTerrain= new Pane(); //faire avec fxml -> creation des pane dans fxml
		//baseTerrain.setPrefColumns(5);
		//baseTerrain.setPrefRows(10);
		
		Pane deuxiemeCouche = new Pane();
		//deuxiemeCouche.setPrefColumns(5);
		//deuxiemeCouche.setPrefRows(10);*/
		

		//initialize
		for ( int x = 0 ; x < map.length ; x++ ) {
			for ( int y = 0 ; y < map[x].length ; y ++) {
				if (map[x][y]==2){
					
					//ouvre une image terre
				
					File f=new File("src/img/herbe.png");
					Image herbe = new Image(f.toURI().toString(),32,32,false,false);
					ImageView viewHerbe = new ImageView();
					viewHerbe.setImage(herbe);
					baseTerrain.getChildren().add(viewHerbe);
					viewHerbe.relocate(y*32, x*32);
					
				}
				else if(map[x][y]==3){
					File g=new File("src/img/chemin.png");
					Image chemin = new Image(g.toURI().toString(),32,32,false,false);
					ImageView viewchemin = new ImageView();
					viewchemin.setImage(chemin);
					baseTerrain.getChildren().add(viewchemin);
					viewchemin.relocate(y*32, x*32);
				}
				/*else if(map[x][y]==1){
					File h=new File("src/img/hautes_herbes.png");
					Image hautes_herbes = new Image(h.toURI().toString(),32,32,false,false);
					ImageView viewhautes_herbes = new ImageView();
					viewhautes_herbes.setImage(hautes_herbes);
					baseTerrain.getChildren().add(viewhautes_herbes);
				}*/
				
				
			}
		}
		//deuxieme tilepane test
		for ( int x = 0 ; x < map2.length ; x++ ) {
			for ( int y = 0 ; y < map2[x].length ; y ++) {
				
				 if(map2[x][y]==1){
					File h=new File("src/img/hautes_herbes.png");
					Image hautes_herbes = new Image(h.toURI().toString(),32,32,false,false);
					ImageView viewhautes_herbes = new ImageView();
					viewhautes_herbes.setImage(hautes_herbes);
					deuxiemeCouche.getChildren().add(viewhautes_herbes);
					viewhautes_herbes.relocate(y*32, x*32);
				}
				
				
			}
		}
			
		 // AJOUT DE TOUT LES ELEMENTS AU PANEL
		 
		panel.getChildren().add(baseTerrain);
		panel.getChildren().add(deuxiemeCouche);
		panel.getChildren().add(personnage);
			

			
		
			
			
			
			
			

			

		}

	}

