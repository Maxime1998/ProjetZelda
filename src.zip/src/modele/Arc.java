package modele;


public class Arc implements Arme {

	private int degats;
	private String nom;
	
	public Arc() {
		this.degats=100;
		this.nom="arc";
	}

	@Override
	public int getDegats() {
		return this.degats;
	}
	
	@Override
	public String getNom() {
		return this.nom;
	}
}
