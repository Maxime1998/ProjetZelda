package modele;


public class Arc implements Arme {

	private int degats;
	
	public Arc() {
		this.degats=5;
	}

	@Override
	public int getDegats() {
		return this.degats;
	}
}
