package modele;

public class Archer extends Personnage{
	
	
	public Archer(int abs, int ord,int[][] m) {
		
		super(abs,ord,50,m,new Arc(7));
	}
	

}