package modele;

public class Archer extends Personnage{
	
	
	public Archer(Deplacement d) {
		
		super(50,new Arc(),d);
	}
	

}