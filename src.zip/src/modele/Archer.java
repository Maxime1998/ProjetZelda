package modele;

public class Archer extends Personnage{
	
	
	public Archer(Deplacement d,Environnement e) {
		
		super(10,new Arc(),d,e);
	}
	

}