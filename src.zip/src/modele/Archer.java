package modele;

import java.util.ArrayList;

public class Archer extends Personnage{
	
	
	public Archer(Deplacement d,Environnement e) {
		
		super(50,new Arc(),d,e);
	}
	

}