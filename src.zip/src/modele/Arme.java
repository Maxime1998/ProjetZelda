package modele;

public interface Arme  {
	
	public int getDegats();
	

}