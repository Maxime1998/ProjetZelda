package modele;

import controleur.DetecteurCollision;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class Deplacement {

	private IntegerProperty posX,posY;
	private IntegerProperty posXMax,posYMax;
	private DetecteurCollision collision;
	private int[][] map;
	private int compteurpas;
	private IntegerProperty orientation;//1==Haut; 0==Bas, 2==Droite; 3==Gauche
	private boolean deplacementG;
	
	public Deplacement(int abs, int ord,int[][] m) {
		this.posX= new SimpleIntegerProperty();
		this.posX.set(abs);
		this.posY= new SimpleIntegerProperty();
		this.posY.set(ord);
		this.posXMax= new SimpleIntegerProperty();
		this.posXMax.set(abs+30);
		this.posYMax= new SimpleIntegerProperty();
		this.posYMax.set(ord+32);
		this.map=m;
		this.compteurpas=0;
		this.collision=new DetecteurCollision(map);
		this.orientation=new SimpleIntegerProperty();
		this.orientation.set(0);
		this.deplacementG=true;
	}
	
	public void agirHorizontale() {
		if(this.deplacementG==true) {
			if(this.gauche()==true) {
			}
			else {
				this.setDeplacement(false);	}
		}
		else {
			if(this.droite()==true) {
			}
			else {
				this.setDeplacement(true);
			}
		}
	
	}
	
	public void agirVerticale() {
		if(this.deplacementG==true) {
			if(this.monter()==true) {
			}
			else {
				this.setDeplacement(false);	}
		}
		else {
			if(this.descendre()==true) {
			}
			else {
				this.setDeplacement(true);
			}
		}
	
	}
	
	public boolean getDeplacement() {
		return this.deplacementG;
	}
	
	public void setDeplacement(boolean b) {
		this.deplacementG=b;
	}
	
	public IntegerProperty getOrientation() {
		return orientation;
	}
	
	
	public IntegerProperty getPosX() {
		return posX;
	}
	
	public IntegerProperty getPosY() {
		return posY;
	}
	
	public IntegerProperty getPosXMax() {
		return posXMax;
	}
	
	public IntegerProperty getPosYMax() {
		return posYMax;
	}
	
	public int getPosx() {
		return this.posX.get();
	}
	
	public int getPosy() {
		return this.posY.get();
	}
	
	public void setPosX(int x) {
		this.posX.set(x);
	}
	
	public void setPosY(int y) {
		this.posY.set(y);
	}
	
	public void setPosXMax(int xMax) {
		this.posXMax.set(xMax);
	}
	
	public void setPosYMax(int yMax) {
		this.posYMax.set(yMax);
	}
	
	public boolean monter() {
		this.orientation.set(1);
		if(collision.testCollisionHaut(posY.get(),posX.get(),posXMax.get())==false) {
			if(this.posY.get()>0) {
				this.posY.set(posY.get()-1);
				setPosYMax(posYMax.get()-1);
				return true;
			}
		}
		return false;
	}
	
	public boolean descendre() {
		this.orientation.set(0);
		if(collision.testCollisionBas(posYMax.get(),posX.get(),posXMax.get())==false) {
			if(this.posYMax.get()<640) {
				this.posY.set(posY.get()+1);
				this.posYMax.set(posYMax.get()+1);
				return true;
			}	
		}
		return false;
	}
	
	public boolean droite() {
		this.orientation.set(2);
		if(collision.testCollisionDroit(posY.get(),posXMax.get(),posYMax.get())==false) {
			if(this.posXMax.get()<640) {
				this.posX.set(posX.get()+1);
				this.posXMax.set(posXMax.get()+1);
				return true;
			}
		}
		return false;
	}
	
	public boolean gauche() {
		this.orientation.set(3);
		if(collision.testCollisionGauche(posY.get(),posX.get(),posYMax.get())==false) {
			if(this.posX.get()>0) {
				this.posX.set(posX.get()-1);
				this.posXMax.set(posXMax.get()-1);
				return true;
			}
		}
		return false;
	}
	
	public int getCompteurPas(){
		return this.compteurpas;
	}
	public void incrementerCompteurPas(){
		this.compteurpas++;
	}
	
	
}
