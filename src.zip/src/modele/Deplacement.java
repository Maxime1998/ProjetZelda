package modele;

import java.util.ArrayList;

import controleur.Case;
import controleur.DetecteurCollision;
import controleur.DetecteurCollisionObjetsPoussables;
import controleur.DetecteurCollisionPersonnage;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class Deplacement {

	private Case posXY;
	private Case posXYMax;
	private DetecteurCollision collision;
	private DetecteurCollisionPersonnage collisionperso;
	private DetecteurCollisionObjetsPoussables dcObjPoussables;
	private ArrayList<ObjetsPoussables> listeObjetsPoussables;
	private int[][] map;
	private int compteurpas;
	private IntegerProperty orientation;//1==Haut; 0==Bas, 2==Droite; 3==Gauche
	protected boolean deplacementG;
	
	public Deplacement(Case c,int[][] m,ArrayList<Personnage> listePos,ArrayList<ObjetsPoussables> listeobjPoussables) {
		this.posXY= c;
		this.posXYMax = new Case(c.getX()+32, c.getY()+32);
		this.map=m;
		this.compteurpas=0;
		this.collision=new DetecteurCollision(map);
		this.orientation=new SimpleIntegerProperty();
		this.orientation.set(0);
		this.deplacementG=true;
		this.collisionperso=new DetecteurCollisionPersonnage(listePos);
		this.listeObjetsPoussables=listeobjPoussables;
		this.dcObjPoussables=new DetecteurCollisionObjetsPoussables(this.listeObjetsPoussables);
	}
	
	public void agir() {
	}
	
	public ArrayList<ObjetsPoussables> getListeObjetsPoussables(){
		return this.listeObjetsPoussables;
	}
	
	public DetecteurCollisionObjetsPoussables getDetecteurObjetsPoussables(){
		return this.dcObjPoussables;
	}
	
	public DetecteurCollisionPersonnage getDetecteurPerso(){
		return this.collisionperso;
	}
	
	public boolean getDeplacement() {
		return this.deplacementG;
	}
	
	public Case getCase() {
		return posXY;
	}
	
	public void setDeplacement(boolean b) {
		this.deplacementG=b;
	}
	
	public IntegerProperty getOrientation() {
		return orientation;
	}
	
	public IntegerProperty getPosX() {
		return posXY.getXProperty();
	}
	
	public IntegerProperty getPosY() {
		return posXY.getYProperty();
	}
	
	public IntegerProperty getPosXMax() {
		return posXYMax.getXProperty();
	}
	
	public IntegerProperty getPosYMax() {
		return posXYMax.getYProperty();
	}
	
	public int getPosx() {
		return this.posXY.getX();
	}
	
	public int getPosy() {
		return this.posXY.getY();
	}
	
	public void setPosX(int x) {
		this.posXY.setX(x);
	}
	
	public void setPosY(int y) {
		this.posXY.setY(y);
	}
	
	public void setPosXMax(int xMax) {
		this.posXYMax.setX(xMax);
	}
	
	public void setPosYMax(int yMax) {
		this.posXYMax.setY(yMax);
	}

	public boolean monter() {
		this.orientation.set(1);
		if((collision.testCollisionHaut(posXY.getY(),posXY.getX(),posXYMax.getX())==false) && (collisionperso.testCollisionHaut(posXY.getY(), posXY.getX())==-1)) {
			if(dcObjPoussables.testCollisionHaut(posXY.getY(), posXY.getX())!=-1) {
				if(dcObjPoussables.getListe().get(dcObjPoussables.testCollisionHaut(posXY.getY(), posXY.getX())).monter()==true) {
					if(this.posXY.getY()>0) {
						this.posXY.setY(posXY.getY()-2);
						this.posXYMax.setY(posXYMax.getY()-2);
						return true;
					}
				}
			}
			else {
				if(this.posXY.getY()>0) {
					this.posXY.setY(posXY.getY()-2);
					this.posXYMax.setY(posXYMax.getY()-2);
					return true;
				}
			}
			
			
		}
		return false;
	}
	
	public boolean descendre() {
		this.orientation.set(0);
		if(collision.testCollisionBas(posXYMax.getY(),posXY.getX(),posXYMax.getX())==false && (collisionperso.testCollisionBas(posXY.getY(), posXY.getX())==-1)) {
			if(dcObjPoussables.testCollisionBas(posXY.getY(), posXY.getX())!=-1) {
				if(dcObjPoussables.getListe().get(dcObjPoussables.testCollisionBas(posXY.getY(), posXY.getX())).descendre()==true) {
					if(this.posXYMax.getY()<1918) {
						this.posXY.setY(posXY.getY()+2);
						this.posXYMax.setY(posXYMax.getY()+2);
						return true;
					}
				}
			}
			else {
				if(this.posXYMax.getY()<1918) {
					this.posXY.setY(posXY.getY()+2);
					this.posXYMax.setY(posXYMax.getY()+2);
					return true;
				}
			}
		}
		return false;
	}
	
	public boolean droite() {
		this.orientation.set(2);
		if(collision.testCollisionDroit(posXY.getY(),posXYMax.getX(),posXYMax.getY())==false && (collisionperso.testCollisionDroit(posXY.getY(), posXY.getX())==-1)) {
			if(dcObjPoussables.testCollisionDroit(posXY.getY(), posXY.getX())!=-1) {
				if(dcObjPoussables.getListe().get(dcObjPoussables.testCollisionDroit(posXY.getY(), posXY.getX())).droite()==true) {
					if(this.posXYMax.getX()<1278) {
						this.posXY.setX(posXY.getX()+2);
						this.posXYMax.setX(posXYMax.getX()+2);
						return true;
					}
				}
			}
			else {
				if(this.posXYMax.getX()<1278) {
					this.posXY.setX(posXY.getX()+2);
					this.posXYMax.setX(posXYMax.getX()+2);
					return true;
				}
			}
		}
		return false;
	}
	
	public boolean gauche() {
		this.orientation.set(3);
		if(collision.testCollisionGauche(posXY.getY(),posXY.getX(),posXYMax.getY())==false && (collisionperso.testCollisionGauche(posXY.getY(), posXY.getX())==-1)) {
			if(dcObjPoussables.testCollisionGauche(posXY.getY(), posXY.getX())!=-1) {
				if(dcObjPoussables.getListe().get(dcObjPoussables.testCollisionGauche(posXY.getY(), posXY.getX())).gauche()==true) {
					if(this.posXY.getX()>0) {
						this.posXY.setX(posXY.getX()-2);
						this.posXYMax.setX(posXYMax.getX()-2);
						return true;
					}
				}
			}
			else {
				if(this.posXY.getX()>0) {
					this.posXY.setX(posXY.getX()-2);
					this.posXYMax.setX(posXYMax.getX()-2);
					return true;
				}
			}
		}
		return false;
	}
	
	public int getCompteurPas(){
		return this.compteurpas;
	}
	public void incrementerCompteurPas(){
		this.compteurpas++;
	}
	
	
}
