package modele;

import java.util.ArrayList;

import controleur.Case;

public class DeplacementAleatoire extends Deplacement{

	private int b;
	
	public DeplacementAleatoire(Case c, int[][]m,ArrayList<Personnage> listePers,ArrayList<ObjetsPoussables> l) {
		super(c,m,listePers,l);
		this.b= (int) (Math.random() * 4);
	}
	
	public void agir() {
		if(this.deplacementG==true) {
			switch(b) {
			case 0:
				if(this.monter()==true) {}
				else {
					this.setDeplacement(false);
				}
				break;
			case 1:
				if(this.droite()==true) {}
				else {
					this.setDeplacement(false);
				}
				break;
			case 2:
				if(this.descendre()==true) {}
				else {
					this.setDeplacement(false);
				}
				break;
			case 3:
				if(this.gauche()==true) {}
				else {
					this.setDeplacement(false);
				}
				break;
			}
		}
		else {
			int c = (int) (Math.random() * 4);
			this.b=c;
			this.deplacementG=true;
		}
	}
}
