package modele;

import java.util.ArrayList;

import controleur.Case;

public class DeplacementAleatoire extends Deplacement{

	private int b;
	
	public DeplacementAleatoire(Case c, int[][]m,ArrayList<Personnage> listePos) {
		super(c,m,listePos);
		this.b= (int) (Math.random() * 4);
	}
	
	public void agir() {
		if(this.deplacementG==true) {
			switch(b) {
			case 0:
				if(this.monter()==true) {}
				else {
					this.descendre();
					this.setDeplacement(false);
				}
				break;
			case 1:
				if(this.droite()==true) {}
				else {
					this.gauche();
					this.setDeplacement(false);
				}
				break;
			case 2:
				if(this.descendre()==true) {}
				else {
					this.monter();
					this.setDeplacement(false);
				}
				break;
			case 3:
				if(this.gauche()==true) {}
				else {
					this.droite();
					this.setDeplacement(false);
				}
				break;
			}
		}
		else {
			int c = (int) (Math.random() * 4);
			this.b=c;
			this.deplacementG=true;
		}
	}
}
