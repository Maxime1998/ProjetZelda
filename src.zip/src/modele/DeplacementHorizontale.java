package modele;

public class DeplacementHorizontale extends Deplacement{

	public DeplacementHorizontale(int abs, int ord,int[][] m) {
		super(abs, ord, m);
	}
	
	public void agir() {
		if(this.deplacementG==true) {
			if(this.gauche()==true) {
			}
			else {
				this.setDeplacement(false);	}
		}
		else {
			if(this.droite()==true) {
			}
			else {
				this.setDeplacement(true);
			}
		}
	
	}
}
