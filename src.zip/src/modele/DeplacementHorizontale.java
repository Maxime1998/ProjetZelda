package modele;

import java.util.ArrayList;

import controleur.Case;

public class DeplacementHorizontale extends Deplacement{

	public DeplacementHorizontale(Case c,int[][] m,ArrayList<Personnage> listePers) {
		super(c, m,listePers);
	}
	
	public void agir() {
		if(this.deplacementG==true) {
			if(this.gauche()==true) {
			}
			else {
				this.setDeplacement(false);	}
		}
		else {
			if(this.droite()==true) {
			}
			else {
				this.setDeplacement(true);
			}
		}
	
	}
}
