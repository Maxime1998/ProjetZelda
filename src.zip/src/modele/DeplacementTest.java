package modele;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import controleur.Case;

public class DeplacementTest {

	/*private Map map2ecouche;
	private Archer archer1;
	private int[][] map2;
	private ArrayList<Personnage> listePers;
	private ArrayList<ObjetsPoussables> listeObjetsPoussables;
	private ArrayList<Objets> listeObj;
	private ObjetsPoussables objetPoussable;
	private Objets potion_vie;
	private env.getLink() env.getLink()= new env.getLink()(new Deplacement(new Case(70,98), this.map2, listePers, listeObj,listeObjetsPoussables),null);
	
	public DeplacementTest() {
		this.map2ecouche = new Map("src/app/matrice_ville_depart2.txt", new int[60][40]);
		this.map2ecouche.initMapLogique();
		this.map2 = map2ecouche.getMapLogique();
		this.objetPoussable=new ObjetsPoussables(new Case(300,300),this.map2,null);
		this.potion_vie=new PotionVie("potion_vie", new Case(300,1000));
		
		this.archer1= new Archer(new DeplacementHorizontale(new Case(150,150), this.map2, listePers, listeObj,listeObjetsPoussables),null);
		this.objetPoussable.setenv.getLink()(env.getLink());
		this.listePers=new ArrayList<Personnage>();
		this.listeObj= new ArrayList<Objets>();
		this.listeObjetsPoussables= new ArrayList<ObjetsPoussables>();
		this.listePers.add(env.getLink());
		this.listePers.add(env.getLink());
		this.listePers.add(2,archer1);
		this.listeObj.add(potion_vie);
		this.listeObjetsPoussables.add(objetPoussable);
		this.env.getLink()=new env.getLink()(new Deplacement(new Case(64,98), this.map2, listePers, listeObj,listeObjetsPoussables),null);
	}*/
	private Environnement env;
	@Before
	public final void initialiserJeu() {
		this.env=new Environnement();
	}
	
	@Test
	public final void TestMonter() {
		env.getLink().getDeplacement().getCase().setX(70);
		env.getLink().getDeplacement().getCase().setY(100);
		env.getLink().getDeplacement().getCaseMax().setX(102);
		env.getLink().getDeplacement().getCaseMax().setY(132);
		env.getLink().getDeplacement().monter();
		assertEquals("monterOK", 98, env.getLink().getDeplacement().getCase().getY());
	}
	
	@Test
	public final void TestMonterObstacle() {
		env.getLink().getDeplacement().getCase().setX(70);
		env.getLink().getDeplacement().getCase().setY(94);
		env.getLink().getDeplacement().getCaseMax().setX(102);
		env.getLink().getDeplacement().getCaseMax().setY(126);
		env.getLink().getDeplacement().monter();
		assertEquals("monterOK", 94, env.getLink().getDeplacement().getCase().getY());
	}
	
	@Test
	public final void TestDroite() {
		env.getLink().getDeplacement().getCase().setX(70);
		env.getLink().getDeplacement().getCase().setY(100);
		env.getLink().getDeplacement().getCaseMax().setX(102);
		env.getLink().getDeplacement().getCaseMax().setY(132);
		env.getLink().getDeplacement().droite();
		assertEquals("monterOK", 72, env.getLink().getDeplacement().getCase().getX());
	}
	
	@Test
	public final void TestDroiteObstacle() {
		env.getLink().getDeplacement().getCase().setX(70);
		env.getLink().getDeplacement().getCase().setY(68);
		env.getLink().getDeplacement().getCaseMax().setX(102);
		env.getLink().getDeplacement().getCaseMax().setY(100);
		env.getLink().getDeplacement().droite();
		assertEquals("monterOK", 70, env.getLink().getDeplacement().getCase().getX());
	}

}
