package modele;

import java.util.ArrayList;

import controleur.Case;

public class DeplacementVerticale extends Deplacement{

	public DeplacementVerticale(Case c, int[][]m, ArrayList<Case> liste) {
		super(c, m, liste);
	}
	
	public void agir() {
		if(this.deplacementG==true) {
			if(this.monter()==true) {
			}
			else {
				this.setDeplacement(false);	}
		}
		else {
			if(this.descendre()==true) {
			}
			else {
				this.setDeplacement(true);
			}
		}
	
	}
}
