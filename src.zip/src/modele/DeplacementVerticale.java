package modele;

public class DeplacementVerticale extends Deplacement{

	public DeplacementVerticale(int abs, int ord,int[][] m) {
		super(abs, ord, m);
	}
	
	public void agir() {
		if(this.deplacementG==true) {
			if(this.monter()==true) {
			}
			else {
				this.setDeplacement(false);	}
		}
		else {
			if(this.descendre()==true) {
			}
			else {
				this.setDeplacement(true);
			}
		}
	
	}
}
