package modele;

import java.util.ArrayList;

import controleur.Case;

public class DeplacementVerticale extends Deplacement{

	public DeplacementVerticale(Case c,int[][] m,ArrayList<Personnage> listePos ,ArrayList<Objets> listeObj,ArrayList<ObjetsPoussables> listeObjPoussables) {
		super(c, m,listePos, listeObj,listeObjPoussables);
	}
	
	public void agir() {
		if(this.deplacementG==true) {
			if(this.monter()==true) {
			}
			else {
				this.setDeplacement(false);	}
		}
		else {
			if(this.descendre()==true) {
			}
			else {
				this.setDeplacement(true);
			}
		}
	
	}
}
