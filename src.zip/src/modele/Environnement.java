package modele;

import java.util.ArrayList;

import controleur.Case;
import controleur.Scrolling;

public class Environnement {

	private Map mapLogique;
	private Map map2ecouche;
	private Link link;
	private ArrayList<Personnage> listePers;
	private ArrayList<ObjetsPoussables> listeObjetsPoussables;
	private ArrayList<Objets> listeObj;
	private Archer archer1;
	private Archer archer2;
	private ObjetsPoussables objetPoussable;
	private ObjetsPoussables objetPoussable2;
	private Objets potion_vie;
	private Scrolling sc;
	private int[][] map;
	private int[][] map2;
	
	
	public Environnement() {
		this.mapLogique= new Map("src/app/matrice_ville_depart1.txt");
		mapLogique.initMapLogique();
		this.map = mapLogique.getMapLogique();
		this.map2ecouche = new Map("src/app/matrice_ville_depart2.txt");
		this.map2ecouche.initMapLogique();
		this.map2 = map2ecouche.getMapLogique();
		this.potion_vie = new PotionVie("potion_vie", new Case(20,20));
		this.listePers= new ArrayList<Personnage>();
		this.listeObj = new ArrayList<Objets>();
		this.listeObjetsPoussables=new ArrayList<ObjetsPoussables>();
		this.archer1= new Archer(new DeplacementHorizontale(new Case(100,100), this.map2, listePers,listeObjetsPoussables),null);
		this.archer2= new Archer(new DeplacementAleatoire(new Case(140,140), this.map2, listePers,listeObjetsPoussables),null);
		this.link= new Link(new Deplacement(new Case(250,250), this.map2, listePers,listeObjetsPoussables),null);
		this.objetPoussable=new ObjetsPoussables(new Case(300,300),this.map2,null);
		this.objetPoussable2=new ObjetsPoussables(new Case(400,400),this.map2,null);
		this.listeObj.add(potion_vie);
		this.listePers.add(link);
		this.listePers.add(archer1);
		this.listePers.add(archer2);
		this.listeObjetsPoussables.add(objetPoussable);
		this.listeObjetsPoussables.add(objetPoussable2);
		this.sc=new Scrolling(link);
		this.setEnvironnement();
		
	}
	
	public void setEnvironnement(){
		this.link.setEnv(this);
		this.archer1.setEnv(this);
		this.archer2.setEnv(this);
		this.objetPoussable.setLink(this.link);
		this.objetPoussable2.setLink(this.link);
		this.objetPoussable.setEnv(this);
		this.objetPoussable2.setEnv(this);
		
	}
	
	public void supprimerMonstreListe(Personnage o) {
		this.listePers.remove(o);
	}
	
	public Personnage getMonstre1(){
		return this.archer1;
	}
	
	public Personnage getMonstre2(){
		return this.archer2;
	}
	
	public ObjetsPoussables getObjetsPoussables(){
		return this.objetPoussable;
	}
	
	public int[][] getMap(){
		return this.map;
	}
	
	public int[][] getMap2(){
		return this.map2;
	}
	
	public Link getLink() {
		return link;
	}
	
	public ArrayList<Personnage> getListePers(){
		return listePers;
	}
	
	public ArrayList<Objets> getListeObj(){
		return listeObj;
	}
	
	public ArrayList<ObjetsPoussables> getListeObjetsPoussables(){
		return this.listeObjetsPoussables;
	}
	
	public Scrolling getScroll() {
		return sc;
	}


}
