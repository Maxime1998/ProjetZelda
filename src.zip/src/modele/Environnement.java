package modele;

import java.util.ArrayList;

import controleur.Case;
import controleur.MortMonstres;
import controleur.Scrolling;
import javafx.scene.image.ImageView;

public class Environnement {

	private Map mapLogique;
	private Map map2ecouche;
	
	//map test grotte
	private Map grotte1;
	private Map grotte2;
	private int[][] mapgrotte1;
	private int[][] mapgrotte2;
	
	private Link link;
	private ArrayList<Personnage> listePers;
	private ArrayList<ObjetsPoussables> listeObjetsPoussables;
	private ArrayList<Objets> listeObj;
	private Archer archer1;
	private Archer archer2;
	private Archer archer3;
	private Archer archer4;
	private Archer archer5;
	private Archer archer6;
	private Archer archer7;
	private Archer archer8;
	private Archer archer9;
	private Archer archer10;
	private MortMonstres monstresmorts;
	
	private ObjetsPoussables objetPoussable;
	private ObjetsPoussables objetPoussable2;
	private PNJ petitVieux;
	private Objets potion_vie;
	private Scrolling sc;
	private int[][] map;
	private int[][] map2;
	private String txt;
	
	//coordonne affichage objet inventaire
	private Case coordCarre;
	private Case coordPotionVie;
	
	private ArrayList<Case> listeCoord;
	
	
	
	
	public Environnement() {
		//initialisation test map grotte
		this.grotte1= new Map("src/app/map-test.txt", new int[20][20]);
		this.grotte1.initMapLogique();
		this.grotte2= new Map("src/app/map-test2.txt", new int[20][20]);
		this.grotte2.initMapLogique();
		
		
		this.txt= new String("Bonjour, mon enfant");
		this.mapLogique= new Map("src/app/matrice_ville_depart1.txt", new int[60][40]);
		mapLogique.initMapLogique();
		this.map = mapLogique.getMapLogique();
		this.map2ecouche = new Map("src/app/matrice_ville_depart2.txt", new int[60][40]);
		this.map2ecouche.initMapLogique();
		this.map2 = map2ecouche.getMapLogique();
		this.potion_vie = new PotionVie("potion_vie", new Case(300,1000));
		this.listePers= new ArrayList<Personnage>();
		this.listeObj = new ArrayList<Objets>();
		this.listeObjetsPoussables=new ArrayList<ObjetsPoussables>();
		this.archer1= new Archer(new DeplacementHorizontale(new Case(150,150), this.map2, listePers, listeObj,listeObjetsPoussables),null);
		this.archer2= new Archer(new DeplacementAleatoire(new Case(200,220), this.map2, listePers, listeObj,listeObjetsPoussables),null);
		this.archer3= new Archer(new DeplacementAleatoire(new Case(180,180), this.map2, listePers,listeObj,listeObjetsPoussables),null);
		this.archer4= new Archer(new DeplacementAleatoire(new Case(720,720), this.map2, listePers,listeObj,listeObjetsPoussables),null);
		this.archer5= new Archer(new DeplacementAleatoire(new Case(960,960), this.map2, listePers,listeObj,listeObjetsPoussables),null);
		this.archer6= new Archer(new DeplacementAleatoire(new Case(800,800), this.map2, listePers,listeObj,listeObjetsPoussables),null);
		this.archer7= new Archer(new DeplacementAleatoire(new Case(340,340), this.map2, listePers,listeObj,listeObjetsPoussables),null);
		this.archer8= new Archer(new DeplacementAleatoire(new Case(340,600), this.map2, listePers,listeObj,listeObjetsPoussables),null);
		this.archer9= new Archer(new DeplacementAleatoire(new Case(420,420), this.map2, listePers,listeObj,listeObjetsPoussables),null);
		this.archer10= new Archer(new DeplacementAleatoire(new Case(460,460), this.map2, listePers,listeObj,listeObjetsPoussables),null);
		this.monstresmorts=new MortMonstres(null);
		
		this.link= new Link(new Deplacement(new Case(320,1600), this.map2, listePers, listeObj,listeObjetsPoussables),null);
		this.petitVieux = new PNJ(new Deplacement(new Case(220,1550), this.map2, listePers, listeObj,listeObjetsPoussables) , null, txt);
		this.listeObj.add(potion_vie);
		
		this.objetPoussable=new ObjetsPoussables(new Case(300,300),this.map2,null);
		this.objetPoussable2=new ObjetsPoussables(new Case(400,400),this.map2,null);
		this.listeObjetsPoussables.add(objetPoussable);
		this.listeObjetsPoussables.add(objetPoussable2);
		
		this.listePers.add(link);
		this.listePers.add(petitVieux);
		this.listePers.add(archer1);
		this.listePers.add(archer2);
		this.listePers.add(archer3);
		this.listePers.add(archer4);
		this.listePers.add(archer5);
		this.listePers.add(archer6);
		this.listePers.add(archer7);
		this.listePers.add(archer8);
		this.listePers.add(archer9);
		this.listePers.add(archer10);
		
		
		this.sc=new Scrolling(link);
		this.coordCarre= new Case(40,40);
		this.coordPotionVie= new Case(450,450);
		this.listeCoord=new ArrayList<>();
		this.listeCoord.add(coordPotionVie);
		
		this.setEnvironnement();
		
	}
	
	public void setEnvironnement(){
		System.out.println("Flèches clavier pour se déplacer");
		System.out.println("Espace pour attaquer/lancer des flèches");
		System.out.println("s pour changer d'arme");
		System.out.println("Entrée pour ramasser des potions et pour parler au petit vieux");
		this.link.setEnv(this);
		this.petitVieux.setEnv(this);
		this.archer1.setEnv(this);
		this.archer2.setEnv(this);
		this.archer3.setEnv(this);
		this.archer4.setEnv(this);
		this.archer5.setEnv(this);
		this.archer6.setEnv(this);
		this.archer7.setEnv(this);
		this.archer8.setEnv(this);
		this.archer9.setEnv(this);
		this.archer10.setEnv(this);
		this.monstresmorts.setEnvironnement(this);
		
		this.objetPoussable.setLink(this.link);
		this.objetPoussable2.setLink(this.link);
		this.objetPoussable.setEnv(this);
		this.objetPoussable2.setEnv(this);
	}
	
	public MortMonstres getMortMonstres() {
		return this.monstresmorts;
	}
	
	public void supprimerMonstreListe(Personnage o) {
		this.listePers.remove(o);
	}
	
	public Personnage getMonstre1(){
		return this.archer1;
	}
	
	public Personnage getMonstre2(){
		return this.archer2;
	}
	
	public Personnage getMonstre3(){
		return this.archer3;
	}
	
	public Personnage getMonstre4(){
		return this.archer4;
	}
	
	public Personnage getMonstre5(){
		return this.archer5;
	}
	
	public Personnage getMonstre6(){
		return this.archer6;
	}
	
	public Personnage getMonstre7(){
		return this.archer7;
	}
	
	public Personnage getMonstre8(){
		return this.archer8;
	}
	
	public Personnage getMonstre9(){
		return this.archer9;
	}
	
	public Personnage getMonstre10(){
		return this.archer10;
	}
	
	public int[][] getMap(){
		return this.map;
	}
	
	public int[][] getMap2(){
		return this.map2;
	}
	
	public Link getLink() {
		return link;
	}
	
	public ArrayList<Personnage> getListePers(){
		return listePers;
	}
	
	public ArrayList<ObjetsPoussables> getListeObjetsPoussables(){
		return this.listeObjetsPoussables;
	}
	
	public ArrayList<Objets> getListeObj(){
		return listeObj;
	}
	
	public Scrolling getScroll() {
		return sc;
	}
	
	public Case getCoordCarre() {
		return coordCarre;
	}
	public void setCoordCarre(int x, int y) {
		this.coordCarre.setX(x);
		this.coordCarre.setY(y);
	}
	
	public ArrayList<Case> getListeCoord() {
		return listeCoord;
	}
	


}
