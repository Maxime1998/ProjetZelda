package modele;

import java.util.ArrayList;

import controleur.Case;
import controleur.Scrolling;

public class Environnement {

	private Map mapLogique;
	private Map map2ecouche;
	private Link link;
	private ArrayList<Personnage> listePers;
	private ArrayList<Objets> listeObj;
	private Archer archer1;
	private Archer archer2;
	private PNJ petitVieux;
	private Objets potion_vie;
	private Scrolling sc;
	private int[][] map;
	private int[][] map2;
	
	//coordonne affichage objet inventaire
	private Case coordCarre;
	private Case coordPotionVie;
	
	private ArrayList<Case> listeCoord;
	
	
	
	
	public Environnement() {
		this.mapLogique= new Map("src/app/matrice_ville_depart1.txt");
		mapLogique.initMapLogique();
		this.map = mapLogique.getMapLogique();
		this.map2ecouche = new Map("src/app/matrice_ville_depart2.txt");
		this.map2ecouche.initMapLogique();
		this.map2 = map2ecouche.getMapLogique();
		this.potion_vie = new PotionVie("potion_vie", new Case(300,1000));
		this.listePers= new ArrayList<Personnage>();
		this.listeObj = new ArrayList<Objets>();
		this.archer1= new Archer(new DeplacementHorizontale(new Case(150,150), this.map2, listePers, listeObj),null);
		this.petitVieux = new PNJ(new Deplacement(new Case(220,1550), this.map2, listePers, listeObj ) , null);
		this.archer2= new Archer(new DeplacementAleatoire(new Case(200,220), this.map2, listePers, listeObj),null);
		this.link= new Link(new Deplacement(new Case(320,1600), this.map2, listePers, listeObj),null);
		this.listeObj.add(potion_vie);
		
		this.listePers.add(link);
		this.listePers.add(archer1);
		this.listePers.add(archer2);
		this.listePers.add(petitVieux);
		
		this.sc=new Scrolling(link);
		this.coordCarre= new Case(40,40);
		this.coordPotionVie= new Case(450,450);
		this.listeCoord=new ArrayList<>();
		this.listeCoord.add(coordPotionVie);
		
		
		this.link.getDeplacement().getDetecteur().setListe(listePers);
		this.archer1.getDeplacement().getDetecteur().setListe(listePers);
		this.setEnvironnement();
		
	}
	
	public void setEnvironnement(){
		this.link.setEnv(this);
		this.archer1.setEnv(this);
		this.archer2.setEnv(this);
		this.petitVieux.setEnv(this);
	}
	
	/*public Map getMapLogique() {
		return mapLogique;
	}
	
	public Map getMap2eCouche() {
		return map2ecouche;
	}*/
	
	public int[][] getMap(){
		return this.map;
	}
	
	public int[][] getMap2(){
		return this.map2;
	}
	
	public Link getLink() {
		return link;
	}
	
	public ArrayList<Personnage> getListePers(){
		return listePers;
	}
	
	public ArrayList<Objets> getListeObj(){
		return listeObj;
	}
	
	public Scrolling getScroll() {
		return sc;
	}
	
	public Case getCoordCarre() {
		return coordCarre;
	}
	public void setCoordCarre(int x, int y) {
		this.coordCarre.setX(x);
		this.coordCarre.setY(y);
	}
	
	public ArrayList<Case> getListeCoord() {
		return listeCoord;
	}
	


}
