package modele;

public class Epee implements Arme{

	private int degats;
	
	public Epee() {
		this.degats=3;
	}
	
	@Override
	public int getDegats() {
		return degats;
	}

}
