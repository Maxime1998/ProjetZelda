package modele;

public class Epee implements Arme{

	private int degats;
	private String nom;
	
	public Epee() {
		this.degats=3;
		this.nom="epee";
	}
	
	@Override
	public int getDegats() {
		return degats;
	}
	
	@Override
	public String getNom() {
		return this.nom;
	}

}
