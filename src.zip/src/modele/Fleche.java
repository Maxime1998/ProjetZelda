package modele;

import java.util.ArrayList;

import controleur.DetecteurCollision;
import controleur.DetecteurCollisionPersonnage;

public class Fleche {

	private int x;
	private int y;
	private int direction;//0:N//1:NE//2:E//3:SE//4:S//5:SW//6:W//7:NW
	private Arc arc;
	private int portee;
	private DetecteurCollisionPersonnage dcPerso;
	private DetecteurCollision dc;
	private ArrayList<Personnage> listee;
	private int[][] map;
	
	public Fleche(int xx, int yy,Arc a,int dir,ArrayList<Personnage> liste,int [][] m) {
		this.listee=liste;
		this.map=m;
		this.arc=a;
		this.direction=dir;
		this.portee=200;
		if(this.direction==0) {
			if(xx<1262 && yy<1886) {
				this.x=xx+16;
				this.y=yy+32;
			}
			else {
				this.x=xx;
				this.y=yy;
			}
		}
		else if(this.direction==1) {
			if(xx<1262 && yy>34) {
				this.x=xx+16;
				this.y=yy-32;
			}
			else {
				this.x=xx;
				this.y=yy;
			}
		}
		else if(this.direction==2) {
			if(xx<1262 && yy<1902) {
				this.x=xx+32;
				this.y=yy+16;
			}
			else {
				this.x=xx;
				this.y=yy;
			}
			
		}
		else {
			if(xx>34 && yy<1902) {
				this.x=xx-32;
				this.y=yy+16;
			}
			else {
				this.x=xx;
				this.y=yy;
			}
		}
		this.dcPerso=new DetecteurCollisionPersonnage(liste);
		this.dc=new DetecteurCollision(map);
	}
	
	public int getX() {
		return this.x;
	}
	
	public int getY() {
		return this.y;
	}
	
	public int getPortee() {
		return this.portee;
	}
	
	public void agir() {
		switch(this.direction) {
		case 1:
			if(dcPerso.testCollisionHaut(this.y, this.x)!=-1 && dcPerso.testCollisionHaut(this.y, this.x)!=0 && dcPerso.testCollisionHaut(this.y, this.x)!=1 ) {
				this.listee.get(dcPerso.testCollisionHaut(this.y, this.x)).recevoirDegat(this.arc.getDegats());
				this.portee=0;
			}
			else {
				if(dc.testCollisionHaut(this.y, this.x, this.x+10)==false && this.y>4) {
					this.y=y-2;
					
				}
				this.portee--;
			}
			break;
		case 2:
			if(dcPerso.testCollisionDroit(this.y, this.x)!=-1 && dcPerso.testCollisionDroit(this.y, this.x)!=0 && dcPerso.testCollisionDroit(this.y, this.x)!=1) {
				this.listee.get(dcPerso.testCollisionDroit(this.y, this.x)).recevoirDegat(this.arc.getDegats());
				this.portee=0;
			}
			else {
				if(dc.testCollisionDroit(this.y, this.x+32, this.y+10)==false && this.x<1246) {
					this.x=x+2;
				}
				this.portee--;
			}
			break;
		case 0:
			if(dcPerso.testCollisionBas(this.y, this.x)!=-1  && dcPerso.testCollisionBas(this.y, this.x)!=0 && dcPerso.testCollisionBas(this.y, this.x)!=1) {
				this.listee.get(dcPerso.testCollisionBas(this.y, this.x)).recevoirDegat(this.arc.getDegats());
				this.portee=0;
			}
			else {
				if(dc.testCollisionBas(this.y+32, this.x, this.x+10)==false && this.y<1886) {
					this.y=y+2;
				}
				this.portee--;
			}
			break;
		case 3:
			if(dcPerso.testCollisionGauche(this.y, this.x)!=-1 && dcPerso.testCollisionGauche(this.y, this.x)!=0 && dcPerso.testCollisionGauche(this.y, this.x)!=1) {
				this.listee.get(dcPerso.testCollisionGauche(this.y, this.x)).recevoirDegat(this.arc.getDegats());
				this.portee=0;
			}
			else {
				if(dc.testCollisionGauche(this.y, this.x, this.y+10)==false && this.x>4) {
					this.x=x-2;
				}
				this.portee--;
			}
			break;
		}
	}
}
