package modele;

import java.util.ArrayList;

public class Inventaire {

	ArrayList<Objets> liste;
	public Inventaire() {
		liste=new ArrayList<>();
	}
	
	public void ajouterObjet(Objets obj){
		liste.add(obj);
	}
	public void retirerObjet(Objets obj){
		liste.remove(obj);
	}

}
