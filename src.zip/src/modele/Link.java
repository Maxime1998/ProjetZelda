package modele;

import java.util.ArrayList;

public class Link extends Personnage {
	
	private Arme epee;
	private ArrayList<Objets> inventaire;
	private int argent;
	
	public Link(Deplacement d,Environnement e){
		super(10, new Epee(),d,e);
		this.inventaire= new ArrayList<Objets>();
		this.argent=10;
	}
	
	public void boirePotion(String n){
		for(int i=0;i<inventaire.size();i++){
			if(inventaire.get(i).getNom().equals(n)){
				((PotionVie) inventaire.get(i)).donnerPV(this);
			}
		}
	}
	

	public void ajouterObjet(Objets obj) {
		inventaire.add(obj);
		System.out.println(inventaire);
	}
	
	public Objets getObjet(int i) {
		return inventaire.get(i);
	}
	public ArrayList<Objets> getListeObj(){
		return inventaire;
	}
	
	

}