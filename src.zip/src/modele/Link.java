package modele;

import java.util.ArrayList;

public class Link extends Personnage {
	
	private Arme epee;
	private ArrayList<Objets> inventaire;
	private int argent;
	
	public Link(Deplacement d,ArrayList<ObjetsPoussables> listeObjets){
		super(10, new Epee(),d);
		this.inventaire= new ArrayList<Objets>();
		this.argent=10;
		//this.getDeplacement()
	}
	
	public void boirePotion(String n){
		for(int i=0;i<inventaire.size();i++){
			if(inventaire.get(i).getNom().equals(n)){
				((PotionVie) inventaire.get(i)).donnerPV(this);
			}
		}
	}
	

}