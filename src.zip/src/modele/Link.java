package modele;

import java.util.ArrayList;

public class Link extends Personnage {
	
	private Arme epee;
	private ArrayList<Objets> inventaire;
	private int argent;
	
	public Link(int abs,int ord, int[][]m,Deplacement d){
		super(abs,ord,10,m, new Epee(),d);
		this.inventaire= new ArrayList<Objets>();
		this.argent=10;
	}
	
	public void boirePotion(String n){
		for(int i=0;i<inventaire.size();i++){
			if(inventaire.get(i).getNom().equals(n)){
				((PotionVie) inventaire.get(i)).donnerPV(this);
			}
		}
	}
	

}