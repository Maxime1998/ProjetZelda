package modele;

public class Objets {

	private String nom;
	
	public Objets(String n) {
		this.nom=n;
	}
	
	public String getNom() {
		return this.nom;
	}
}
