package modele;

import controleur.Case;

public class Objets {

	private String nom;
	private Case coord;
	
	public Objets(String n,Case c) {
		this.nom=n;
		this.coord = c;
	}
	
	public String getNom() {
		return this.nom;
	}
	
	public Case getCase() {
		return coord;
	}
}
