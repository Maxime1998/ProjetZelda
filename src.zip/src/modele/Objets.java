package modele;

import controleur.Case;
import javafx.scene.image.ImageView;

public class Objets {

	private String nom;
	private Case coord;
	//private ImageView img;
	
	public Objets(String n,Case c) {
		this.nom=n;
		this.coord = c;
		
	}
	
	public String getNom() {
		return this.nom;
	}
	
	public Case getCase() {
		return coord;
	}
	/*
	public ImageView getImage() {
		return img;
	}*/
}
