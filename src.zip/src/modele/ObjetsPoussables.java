package modele;

import controleur.Case;
import controleur.DetecteurCollision;

public class ObjetsPoussables {
	
	private Case posXY;
	private Case posXYMax;
	private DetecteurCollision collision;
	private Environnement environnement;
	private Link link;
	private int ancienPosXLink;
	private int ancienPosYLink;
	
	public ObjetsPoussables(Case c, int [][]m,Environnement e) {
		this.posXY=c;
		this.posXYMax=new Case(c.getX()+32,c.getY()+32);
		this.collision=new DetecteurCollision(m);
		this.environnement=e;
	}
	
	public void setEnv(Environnement e){
		this.environnement=e;
	}
	
	public Case getCase() {
		return this.posXY;
	}
	
	public void setLink(Link l) {
		this.link=l;
		this.ancienPosXLink=link.getDeplacement().getPosx();
		this.ancienPosYLink=link.getDeplacement().getPosy();
	}
	
	public void suivreLink() {
		
			if(link.getDeplacement().getPosx()==ancienPosXLink+2) {
				this.droite();
			}
			if(link.getDeplacement().getPosx()==ancienPosXLink-2) {
				this.gauche();
			}
			if(link.getDeplacement().getPosy()==ancienPosYLink+2) {
				this.descendre();
			}
			if(link.getDeplacement().getPosy()==ancienPosYLink-2) {
				this.monter();
			}
			ancienPosXLink=link.getDeplacement().getPosx();
			ancienPosYLink=link.getDeplacement().getPosy();
	}
	
	public boolean monter() {
		if((collision.testCollisionHaut(posXY.getY(),posXY.getX(),posXYMax.getX())==false)) {
			if(this.posXY.getY()>0) {
				this.posXY.setY(posXY.getY()-2);
				this.posXYMax.setY(posXYMax.getY()-2);
				return true;
			}
		}
		return false;
	}
	
	public boolean descendre() {
		if(collision.testCollisionBas(posXYMax.getY(),posXY.getX(),posXYMax.getX())==false) {
			if(this.posXYMax.getY()<1918) {
				this.posXY.setY(posXY.getY()+2);
				this.posXYMax.setY(posXYMax.getY()+2);
				return true;
			}	
		}
		return false;
	}
	
	public boolean droite() {
		if(collision.testCollisionDroit(posXY.getY(),posXYMax.getX(),posXYMax.getY())==false) {
			if(this.posXYMax.getX()<1248) {
				this.posXY.setX(posXY.getX()+2);
				this.posXYMax.setX(posXYMax.getX()+2);
				return true;
			}
		}
		return false;
	}
	
	public boolean gauche() {
		if(collision.testCollisionGauche(posXY.getY(),posXY.getX(),posXYMax.getY())==false) {
			if(this.posXY.getX()>0) {
				this.posXY.setX(posXY.getX()-2);
				this.posXYMax.setX(posXYMax.getX()-2);
				return true;
			}
		}
		return false;
	}
	
	
}
