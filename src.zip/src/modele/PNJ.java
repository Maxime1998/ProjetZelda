package modele;

import java.util.ArrayList;

import controleur.Case;

public class PNJ extends Personnage {
	
	private ArrayList<Objets> inventaire;
	private Case position;
	private String texte;
	
	
	
	public PNJ(Deplacement d, Environnement e) {
		super(10,null,d,e);
		this.inventaire= new ArrayList<Objets>();
		this.texte= new String();
	}
	
	

	public Case getPos() {
		return this.position;
	}
	
	
	
	

}
