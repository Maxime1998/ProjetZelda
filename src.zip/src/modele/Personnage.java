package modele;
import controleur.DetecteurCollision;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;


public class Personnage {

	private IntegerProperty posX,posY;
	private IntegerProperty posXMax,posYMax;
	private int pdv;
	private DetecteurCollision collision;
	private int[][] map;
	private Arme arme;

	public Personnage(int abs, int ord,int pv,int[][] m, Arme arme) {
		this.arme= arme;
		this.posX= new SimpleIntegerProperty();
		this.posX.set(abs);
		this.posY= new SimpleIntegerProperty();
		this.posY.set(ord);
		this.pdv=pv;
		this.posXMax= new SimpleIntegerProperty();
		this.posXMax.set(abs+30);
		this.posYMax= new SimpleIntegerProperty();
		this.posYMax.set(ord+30);
		this.map=m;
	this.collision=new DetecteurCollision(map,posX.get(),posY.get(),posXMax.get(),posYMax.get());
	}
	
	//Return property
	
	public IntegerProperty getPosX() {
		return posX;
	}
	
	public IntegerProperty getPosY() {
		return posY;
	}
	
	public IntegerProperty getPosXMax() {
		return posXMax;
	}
	
	public IntegerProperty getPosYMax() {
		return posYMax;
	}
	
	//Return int
	
	public int getPosx() {
		return this.posX.get();
	}
	
	public int getPosy() {
		return this.posY.get();
	}
	
	public int getPDV() {
		return this.pdv;
	}
	
	public void setPDV(int pv) {
		this.pdv=pv;
	}
	
	public void perdrePV() {
		this.pdv--;
	}
	
	public void gagnerPV() {
		this.pdv++;
	}
	
	public void setPosX(int x) {
		this.posX.set(x);
	}
	
	public void setPosY(int y) {
		this.posY.set(y);
	}
	
	public void setPosXMax(int xMax) {
		this.posXMax.set(xMax);
	}
	
	public void setPosYMax(int yMax) {
		this.posYMax.set(yMax);
	}
	
	public boolean monter() {
		if(collision.testCollisionHaut()==false) {
			this.posY.set(posY.get()-1);
			setPosYMax(posYMax.get()-1);
			collision.setPosY(posY.get());
			collision.setPosYMax(posYMax.get());
			return true;
		}
		return false;
	}
	
	public boolean descendre() {
		if(collision.testCollisionBas()==false) {
			this.posY.set(posY.get()+1);
			this.posYMax.set(posYMax.get()+1);
			collision.setPosY(posY.get());
			collision.setPosYMax(posYMax.get());
			return true;
		}
		return false;
	}
	
	public boolean droite() {
		if(collision.testCollisionDroit()==false) {
			//System.out.println("droite");
			this.posX.set(posX.get()+1);
			this.posXMax.set(posXMax.get()+1);
			collision.setPosX(posX.get());
			collision.setPosXMax(posXMax.get());
			return true;
		}
		return false;
	}
	
	public boolean gauche() {
		if(collision.testCollisionGauche()==false) {
			//System.out.println("left");
			this.posX.set(posX.get()-1);
			this.posXMax.set(posXMax.get()-1);
			collision.setPosX(posX.get());
			collision.setPosXMax(posXMax.get());
			return true;
		}
		return false;
	}
}
