package modele;
import controleur.DetecteurCollision;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;


public class Personnage {

	private IntegerProperty pdv;
	private Arme arme;
	private int degat;
	private Deplacement deplacement;

	public Personnage(int pv, Arme arme, Deplacement d) {
		this.arme= arme;
		this.pdv=new SimpleIntegerProperty(pv);
		this.deplacement = d;
		if(arme==null){
			this.degat=1;
		}
		else{
			this.degat=arme.getDegats();
		}
	}
	
	public void setDeplacement(Deplacement d) {
		this.deplacement=d;
	}
	
	public Deplacement getDeplacement() {
		return this.deplacement;
	}
	
	public int getPDV() {
		return this.pdv.get();
	}
	public IntegerProperty getPV() {
		return this.pdv;
	}
	
	public void setPDV(int pv) {
		if(pv<=10) {
			this.pdv.set(pv);
		}
		else {
			this.pdv.set(10);
		}
		
	}
	
	public void perdrePV() {
		if(pdv.get()>0) {
			pdv.set(pdv.get()-1);	
		}
	}
	
	public void recevoirDegat(int d) {
		this.pdv.set(pdv.get()-d);
	}
	
	public void gagnerPV(int pv) {
		if((pdv.get()+pv)<=10) {
			this.pdv.set(pdv.get()+pv);
		}
		else {
			this.pdv.set(10);
		}
	}
	
	public void attaque(Personnage p) {
		p.recevoirDegat(this.degat);
	}
}
