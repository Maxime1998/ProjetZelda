package modele;
import controleur.DetecteurCollision;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;


public class Personnage {

	private IntegerProperty pdv;
	private Arme arme;
	private Deplacement deplacement;

	public Personnage(int abs, int ord,int pv,int[][] m, Arme arme) {
		this.arme= arme;
		this.pdv=new SimpleIntegerProperty(pv);
		this.deplacement = new Deplacement(abs,ord,m);
	}
	
	public Deplacement getDeplacement() {
		return this.deplacement;
	}
	
	public int getPDV() {
		return this.pdv.get();
	}
	
	public void setPDV(int pv) {
		this.pdv.set(pv);
	}
	
	public void perdrePV() {
		this.pdv.set(pdv.get()-1);;
	}
	
	public void gagnerPV() {
		this.pdv.set(pdv.get()+1);;
	}
}
