package modele;
import controleur.DetecteurCollision;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;


public class Personnage {

	private IntegerProperty pdv;
	private Arme arme;
	private int degat;
	private Deplacement deplacement;

	public Personnage(int pv, Arme arme, Deplacement d) {
		this.arme= arme;
		this.pdv=new SimpleIntegerProperty(pv);
		this.deplacement = d;
		if(arme==null){
			this.degat=1;
		}
		else{
			this.degat=arme.getDegats();
		}
	}
	
	public void setDeplacement(Deplacement d) {
		this.deplacement=d;
	}
	
	public Deplacement getDeplacement() {
		return this.deplacement;
	}
	
	public int getPDV() {
		return this.pdv.get();
	}
	
	public void setPDV(int pv) {
		this.pdv.set(pv);
	}
	
	public void perdrePV() {
		this.pdv.set(pdv.get()-1);;
	}
	
	public void recevoirDegat(int d) {
		this.pdv.set(pdv.get()-d);
	}
	
	public void gagnerPV(int pv) {
		this.pdv.set(pdv.get()+pv);;
	}
	
	public void attaque(Personnage p) {
		p.recevoirDegat(this.degat);
	}
}
