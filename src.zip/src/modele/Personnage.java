package modele;
import controleur.DetecteurCollision;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;


public class Personnage {

	private IntegerProperty posX,posY;
	private IntegerProperty posXMax,posYMax;
	private IntegerProperty pdv;
	private DetecteurCollision collision;
	private int[][] map;
	private Arme arme;
	private int compteurpas;
	private IntegerProperty orientation;//1==Haut; 0==Bas, 2==Droite; 3==Gauche
	private boolean deplacementG;

	public Personnage(int abs, int ord,int pv,int[][] m, Arme arme) {
		this.arme= arme;
		this.posX= new SimpleIntegerProperty();
		this.posX.set(abs);
		this.posY= new SimpleIntegerProperty();
		this.posY.set(ord);
		this.pdv=new SimpleIntegerProperty(pv);
		this.posXMax= new SimpleIntegerProperty();
		this.posXMax.set(abs+30);
		this.posYMax= new SimpleIntegerProperty();
		this.posYMax.set(ord+32);
		this.map=m;
		this.compteurpas=0;
		this.collision=new DetecteurCollision(map);
		this.orientation=new SimpleIntegerProperty();
		this.orientation.set(0);
		this.deplacementG=true;
	}
	
	public void agir() {
		if(this.deplacementG==true) {
			if(this.gauche()==true) {
				System.out.println("gauche");
			}
			else {
				this.setDeplacement(false);	}
		}
		else {
			if(this.droite()==true) {
				System.out.println("droite");
			}
			else {
				this.setDeplacement(true);
			}
		}
	
	}
	
	public boolean getDeplacement() {
		return this.deplacementG;
	}
	
	public void setDeplacement(boolean b) {
		this.deplacementG=b;
	}
	
	public IntegerProperty getOrientation() {
		return orientation;
	}
	
	
	public IntegerProperty getPosX() {
		return posX;
	}
	
	public IntegerProperty getPosY() {
		return posY;
	}
	
	public IntegerProperty getPosXMax() {
		return posXMax;
	}
	
	public IntegerProperty getPosYMax() {
		return posYMax;
	}
	
	public int getPosx() {
		return this.posX.get();
	}
	
	public int getPosy() {
		return this.posY.get();
	}
	
	
	public IntegerProperty getPDV() {
		return this.pdv;
	}
	
	public void setPDV(int pv) {
		this.pdv.set(pv);
	}
	
	public void perdrePV() {
		this.pdv.set(pdv.get()-1);;
	}
	
	public void gagnerPV() {
		this.pdv.set(pdv.get()+1);;
	}
	
	public void setPosX(int x) {
		this.posX.set(x);
	}
	
	public void setPosY(int y) {
		this.posY.set(y);
	}
	
	public void setPosXMax(int xMax) {
		this.posXMax.set(xMax);
	}
	
	public void setPosYMax(int yMax) {
		this.posYMax.set(yMax);
	}
	
	public boolean monter() {
		this.orientation.set(1);
		if(collision.testCollisionHaut(posY.get(),posX.get(),posXMax.get())==false) {
			if(this.posY.get()>0) {
				this.posY.set(posY.get()-2);
				setPosYMax(posYMax.get()-2);
				return true;
			}
		}
		return false;
	}
	
	public boolean descendre() {
		this.orientation.set(0);
		if(collision.testCollisionBas(posYMax.get(),posX.get(),posXMax.get())==false) {
			if(this.posYMax.get()<1280) {
				this.posY.set(posY.get()+2);
				this.posYMax.set(posYMax.get()+2);
				return true;
			}	
		}
		return false;
	}
	
	public boolean droite() {
		this.orientation.set(2);
		if(collision.testCollisionDroit(posY.get(),posXMax.get(),posYMax.get())==false) {
			if(this.posXMax.get()<1280) {
				this.posX.set(posX.get()+2);
				this.posXMax.set(posXMax.get()+2);
				return true;
			}
		}
		return false;
	}
	
	public boolean gauche() {
		this.orientation.set(3);
		if(collision.testCollisionGauche(posY.get(),posX.get(),posYMax.get())==false) {
			if(this.posX.get()>0) {
				this.posX.set(posX.get()-2);
				this.posXMax.set(posXMax.get()-2);
				return true;
			}
		}
		return false;
	}
	
	public int getCompteurPas(){
		return this.compteurpas;
	}
	public void incrementerCompteurPas(){
		this.compteurpas++;
	}
}
