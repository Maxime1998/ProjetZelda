package modele;

import controleur.Case;

public class PotionVie extends Objets {
	
	public PotionVie(String n, Case c) {
		super(n,c);
	}
	
	public void donnerPV(Link l){
		l.gagnerPV(10);
	}
}
