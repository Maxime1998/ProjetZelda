package vue;

import java.io.File;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Vues {

	//petit vieux 
		 File image_vieux = new File("src/img/petit_vieux.png");
		 Image vieux = new Image(image_vieux.toURI().toString(),32,32,false,false);
		 ImageView viewvieux=new ImageView(vieux);
		
		
		//monte
			File image_link_dos=new File("src/link/link_dos.png");
			Image pers_dos= new Image(image_link_dos.toURI().toString(),32,32,false,false);
			File image_link_dos_marche1=new File("src/link/link_dos_marche1.png");
			Image pers_dos_marche1= new Image(image_link_dos_marche1.toURI().toString(),32,32,false,false);
			File image_link_dos_marche2=new File("src/link/link_dos_marche2.png");
			Image pers_dos_marche2= new Image(image_link_dos_marche2.toURI().toString(),32,32,false,false);
			
			//gauche
			File image_link_gauche=new File("src/link/link_profil_gauche.png");
			Image pers_gauche= new Image(image_link_gauche.toURI().toString(),32,32,false,false);
			File image_link_gauche_marche1=new File("src/link/link_profil_gauche_marche1.png");
			Image pers_gauche_marche1= new Image(image_link_gauche_marche1.toURI().toString(),32,32,false,false);
			File image_link_gauche_marche2=new File("src/link/link_profil_gauche_marche2.png");
			Image pers_gauche_marche2= new Image(image_link_gauche_marche2.toURI().toString(),32,32,false,false);
			//droite
			File image_link_droite=new File("src/link/link_profil_doite.png");
			Image pers_droite= new Image(image_link_droite.toURI().toString(),32,32,false,false);
			File image_link_droite_marche1=new File("src/link/link_profil_doite_marche1.png");
			Image pers_droite_marche1= new Image(image_link_droite_marche1.toURI().toString(),32,32,false,false);
			File image_link_droite_marche2=new File("src/link/link_profil_doite_marche2.png");
			Image pers_droite_marche2= new Image(image_link_droite_marche2.toURI().toString(),32,32,false,false);
			//descend
			File image_link_face=new File("src/link/link_face.png");
			Image pers_face = new Image(image_link_face.toURI().toString(),32,32,false,false);
			File image_link_face_marche1=new File("src/link/link_face_marche1.png");
			Image pers_face_marche1 = new Image(image_link_face_marche1.toURI().toString(),32,32,false,false);
			File image_link_face_marche2=new File("src/link/link_face_marche2.png");
			Image pers_face_marche2 = new Image(image_link_face_marche2.toURI().toString(),32,32,false,false);
			
			private ImageView viewperso = new ImageView();
			
			
			//image coeur pour les points de vie
		    File image_coeur=new File("src/img/barre_vie.png");
		    Image coeur = new Image(image_coeur.toURI().toString(),160,32,false,false);
		    ImageView viewcoeur=new ImageView(coeur);
		    
		    //potion vie sur map
		    File image_potion= new File("src/img/potion.png");
		    Image potion= new Image(image_potion.toURI().toString(),20,20,false,false);
		    private ImageView vuepotionmap = new ImageView(potion);
		    
		
		    
		    //vue test pour inventaire 
		    ImageView vuepotion = new ImageView(potion);
		    
		    File image_inv=new File("src/img/inventaire.png");
		    Image inv = new Image(image_inv.toURI().toString(),600,600,false,false);
		    ImageView vueinv = new ImageView(inv);
		    
		    //vue carr� blanc selection dans inventaire
		    File image_carre = new File("src/img/case_survole.png");
		    Image carre = new Image(image_carre.toURI().toString(),160,160,false,false);
		    ImageView viewcarre=new ImageView(carre);
	
		    //vue image gameover
		  //vue carr� blanc selection dans inventaire
		    File image_go = new File("src/img/gameover.png");
		    Image gameover = new Image(image_go.toURI().toString(),600,600,false,false);
		    ImageView viewgo=new ImageView(gameover);
	
	
	//view
	public ImageView getVuePotionMap() {
		return vuepotionmap;
	}
	public ImageView getVuePerso() {
		return viewperso;
	}
	
	public ImageView getVueVieux() {
		return viewvieux;
	}
	public ImageView getVueCarre() {
		return viewcarre;
	}
	public ImageView getVuePotion() {
		return vuepotion;
	}
	public ImageView getVueCoeur() {
		return this.viewcoeur;
	}
	public ImageView getVueInv() {
		return this.vueinv;
	}
	public ImageView getVueGameOver() {
		return this.viewgo;
	}
	
	
	
	//images
	public Image getPersFace() {
		return this.pers_face;
	}
	public Image getPersFaceMarche1() {
		return this.pers_face_marche1;
	}
	public Image getPersFaceMarche2() {
		return this.pers_face_marche2;
	}
	public Image getPersDos() {
		return this.pers_dos;
	}
	public Image getPersDosMarche1() {
		return this.pers_dos_marche1;
	}
	public Image getPersDosMarche2() {
		return this.pers_dos_marche2;
	}
	public Image getPersDroite() {
		return this.pers_droite;
	}
	public Image getPersDroiteMarche1() {
		return this.pers_droite_marche1;
	}
	public Image getPersDroiteMarche2() {
		return this.pers_droite_marche2;
	}
	public Image getPersGauche() {
		return this.pers_gauche;
	}
	public Image getPersGaucheMarche1() {
		return this.pers_gauche_marche1;
	}
	public Image getPersGaucheMarche2() {
		return this.pers_gauche_marche2;
	}
	public Image getPotion() {
		return this.potion;
	}
	public Image getVieux() {
		return this.vieux;
	}
	

}
