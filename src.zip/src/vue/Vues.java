package vue;

import java.io.File;
import java.util.ArrayList;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Vues {

		//petit vieux 
			private File image_vieux = new File("src/img/petit_vieux.png");
			private Image vieux = new Image(image_vieux.toURI().toString(),32,32,false,false);
			private ImageView viewvieux=new ImageView(vieux);
		
		
		//monte
			private File image_link_dos=new File("src/link/link_dos.png");
			private Image pers_dos= new Image(image_link_dos.toURI().toString(),32,32,false,false);
			private File image_link_dos_marche1=new File("src/link/link_dos_marche1.png");
			private Image pers_dos_marche1= new Image(image_link_dos_marche1.toURI().toString(),32,32,false,false);
			private File image_link_dos_marche2=new File("src/link/link_dos_marche2.png");
			private Image pers_dos_marche2= new Image(image_link_dos_marche2.toURI().toString(),32,32,false,false);
			
			//gauche
			private File image_link_gauche=new File("src/link/link_profil_gauche.png");
			private Image pers_gauche= new Image(image_link_gauche.toURI().toString(),32,32,false,false);
			private File image_link_gauche_marche1=new File("src/link/link_profil_gauche_marche1.png");
			private Image pers_gauche_marche1= new Image(image_link_gauche_marche1.toURI().toString(),32,32,false,false);
			private File image_link_gauche_marche2=new File("src/link/link_profil_gauche_marche2.png");
			private Image pers_gauche_marche2= new Image(image_link_gauche_marche2.toURI().toString(),32,32,false,false);
			//droite
			private File image_link_droite=new File("src/link/link_profil_doite.png");
			private Image pers_droite= new Image(image_link_droite.toURI().toString(),32,32,false,false);
			private File image_link_droite_marche1=new File("src/link/link_profil_doite_marche1.png");
			private Image pers_droite_marche1= new Image(image_link_droite_marche1.toURI().toString(),32,32,false,false);
			private File image_link_droite_marche2=new File("src/link/link_profil_doite_marche2.png");
			private Image pers_droite_marche2= new Image(image_link_droite_marche2.toURI().toString(),32,32,false,false);
			//descend
			private File image_link_face=new File("src/link/link_face.png");
			private Image pers_face = new Image(image_link_face.toURI().toString(),32,32,false,false);
			private File image_link_face_marche1=new File("src/link/link_face_marche1.png");
			private Image pers_face_marche1 = new Image(image_link_face_marche1.toURI().toString(),32,32,false,false);
			private File image_link_face_marche2=new File("src/link/link_face_marche2.png");
			private Image pers_face_marche2 = new Image(image_link_face_marche2.toURI().toString(),32,32,false,false);
			
			private ImageView viewperso = new ImageView(pers_face);
			
			
			//monstre
			private File image_monstre= new File("src/img/monstre_face.png");
			private Image monstre= new Image(image_monstre.toURI().toString(),30,32,false,false);
			private File image_archer= new File("src/img/archer_face.png");
			private Image archer= new Image(image_archer.toURI().toString(),30,32,false,false);
            
			//Monstres
			private ImageView viewmonstre = new ImageView(monstre);
			private ImageView viewmonstre2 = new ImageView(archer);
			private ImageView viewmonstre3 = new ImageView(monstre);
			private ImageView viewmonstre4 = new ImageView(archer);
			private ImageView viewmonstre5 = new ImageView(monstre);
			private ImageView viewmonstre6 = new ImageView(archer);
			private ImageView viewmonstre7 = new ImageView(monstre);
			private ImageView viewmonstre8 = new ImageView(archer);
			private ImageView viewmonstre9 = new ImageView(monstre);
			private ImageView viewmonstre10 = new ImageView(archer);
			
			
			//image coeur pour les points de vie
			private File image_coeur=new File("src/img/barre_vie.png");
			private Image coeur = new Image(image_coeur.toURI().toString(),160,32,false,false);
			private ImageView viewcoeur=new ImageView(coeur);
		    
		    //potion vie sur map
			private File image_potion= new File("src/img/potion.png");
			private Image potion= new Image(image_potion.toURI().toString(),20,20,false,false);
		    private ImageView vuepotionmap = new ImageView(potion);
		    
		
		    
		    //vue test pour inventaire 
		    private ImageView vuepotion = new ImageView(potion);
		    
		    private File image_inv=new File("src/img/inventaire.png");
		    private Image inv = new Image(image_inv.toURI().toString(),600,600,false,false);
		    private ImageView vueinv = new ImageView(inv);
		    
		    //vue carr� blanc selection dans inventaire
		    private File image_carre = new File("src/img/case_survole.png");
		    private Image carre = new Image(image_carre.toURI().toString(),160,160,false,false);
		    private ImageView viewcarre=new ImageView(carre);
	
		    //vue image gameover
		  //vue carr� blanc selection dans inventaire
		    private File image_go = new File("src/img/gameover.png");
		    private Image gameover = new Image(image_go.toURI().toString(),600,600,false,false);
		    private ImageView viewgo=new ImageView(gameover);
		    
		    //boite
		    private File g9=new File("src/img/grotte/cote_rocher2.png");
		    private Image cote_rocher2 = new Image(g9.toURI().toString(),32,32,false,false);
		    private ImageView vueboite = new ImageView(cote_rocher2);
			private ImageView vueboite2 = new ImageView(cote_rocher2);
			
			//fleche
			private File fileflechedroit=new File("src/img/Flèche-bombe-droite.png");
			private Image imgflechedroit = new Image(fileflechedroit.toURI().toString(),32,10,false,false);
			private File fileflechegauche=new File("src/img/Flèche-bombe-gauche.png");
			private Image imgflechegauche = new Image(fileflechegauche.toURI().toString(),32,10,false,false);
			private File fileflechehaut=new File("src/img/Flèche-bombe-haut.png");
			private Image imgflechehaut = new Image(fileflechehaut.toURI().toString(),10,32,false,false);
			private File fileflechebas=new File("src/img/Flèche-bombe-bas.png");
			private Image imgflechebas = new Image(fileflechebas.toURI().toString(),10,32,false,false);
			private ImageView viewfleche = new ImageView();
			
			private File image_arc=new File("src/img/arc.png");
            private Image arc = new Image(image_arc.toURI().toString(),32,64,false,false);
            private File image_epee=new File("src/img/epee.png");
            private Image epee = new Image(image_epee.toURI().toString(),64,32,false,false);
            private ImageView viewarme = new ImageView(epee);
			
			private ArrayList<ImageView> listeVueMonstre;
			
			public Vues() {
				this.listeVueMonstre=new ArrayList<ImageView>();
				this.listeVueMonstre.add(viewmonstre);
				this.listeVueMonstre.add(viewmonstre2);
				this.listeVueMonstre.add(viewmonstre3);
				this.listeVueMonstre.add(viewmonstre4);
				this.listeVueMonstre.add(viewmonstre5);
				this.listeVueMonstre.add(viewmonstre6);
				this.listeVueMonstre.add(viewmonstre7);
				this.listeVueMonstre.add(viewmonstre8);
				this.listeVueMonstre.add(viewmonstre9);
				this.listeVueMonstre.add(viewmonstre10);
			}
			
			public ArrayList<ImageView> getListeVueMonstre(){
				return this.listeVueMonstre;
			}
	
	
	//view
	public ImageView getVueMonstre1() {
		return this.viewmonstre;
	}
	public ImageView getVueMonstre2() {
		return this.viewmonstre2;
	}
	public ImageView getVueMonstre3() {
		return this.viewmonstre3;
	}
	public ImageView getVueMonstre4() {
		return this.viewmonstre4;
	}
	public ImageView getVueMonstre5() {
		return this.viewmonstre5;
	}
	public ImageView getVueMonstre6() {
		return this.viewmonstre6;
	}
	public ImageView getVueMonstre7() {
		return this.viewmonstre7;
	}
	public ImageView getVueMonstre8() {
		return this.viewmonstre8;
	}
	public ImageView getVueMonstre9() {
		return this.viewmonstre9;
	}
	public ImageView getVueMonstre10() {
		return this.viewmonstre10;
	}
	public ImageView getVuePotionMap() {
		return vuepotionmap;
	}
	public ImageView getVuePerso() {
		return viewperso;
	}
	public ImageView getVueVieux() {
		return viewvieux;
	}
	public ImageView getVueCarre() {
		return viewcarre;
	}
	public ImageView getVuePotion() {
		return vuepotion;
	}
	public ImageView getVueCoeur() {
		return this.viewcoeur;
	}
	public ImageView getVueInv() {
		return this.vueinv;
	}
	public ImageView getVueGameOver() {
		return this.viewgo;
	}
	public ImageView getVueBoite() {
		return this.vueboite;
	}
	public ImageView getVueBoite2() {
		return this.vueboite2;
	}
	public ImageView getVueFleche() {
		return this.viewfleche;
	}
	public ImageView getVueArme() {
		return this.viewarme;
	}
	
	
	
	
	//images
	public Image getimgflechebas() {
		return this.imgflechebas;
	}
	public Image getimgflechehaut() {
		return this.imgflechehaut;
	}
	public Image getimgflechedroit() {
		return this.imgflechedroit;
	}
	public Image getimgflechegauche() {
		return this.imgflechegauche;
	}
	public Image getPersFace() {
		return this.pers_face;
	}
	public Image getPersFaceMarche1() {
		return this.pers_face_marche1;
	}
	public Image getPersFaceMarche2() {
		return this.pers_face_marche2;
	}
	public Image getPersDos() {
		return this.pers_dos;
	}
	public Image getPersDosMarche1() {
		return this.pers_dos_marche1;
	}
	public Image getPersDosMarche2() {
		return this.pers_dos_marche2;
	}
	public Image getPersDroite() {
		return this.pers_droite;
	}
	public Image getPersDroiteMarche1() {
		return this.pers_droite_marche1;
	}
	public Image getPersDroiteMarche2() {
		return this.pers_droite_marche2;
	}
	public Image getPersGauche() {
		return this.pers_gauche;
	}
	public Image getPersGaucheMarche1() {
		return this.pers_gauche_marche1;
	}
	public Image getPersGaucheMarche2() {
		return this.pers_gauche_marche2;
	}
	public Image getPotion() {
		return this.potion;
	}
	public Image getVieux() {
		return this.vieux;
	}
	
	public Image getMonstre() {
		return this.monstre;
	}
	
	public Image getArcher() {
		return this.archer;
	}
	
	public Image getEpee() {
        return this.epee;
    }
    public Image getArc() {
        return this.arc;
    }
	

}
